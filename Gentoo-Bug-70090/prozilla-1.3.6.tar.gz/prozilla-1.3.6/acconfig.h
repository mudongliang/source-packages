/* Define this if you have the ncurses library and want to use it. */
#undef HAVE_LIBNCURSES

/* Define this if you have the curses library and want to use it. */
#undef HAVE_LIBCURSES

/* Define this if you have (n)curses and want to use it. */
#undef HAVE_CURSES

/*
Define this if you want to compile with GTK+ support.
*/
#undef HAVE_GTK

#undef HAVE_FUNC_GETHOSTBYNAME_R_6
#undef HAVE_FUNC_GETHOSTBYNAME_R_5
#undef HAVE_FUNC_GETHOSTBYNAME_R_3

#undef socklen_t
