<?php

echo "<h1>PHP Test page</h1>Sleeping for 5 sec ... <br><br>";
sleep(5);
for ($i = 0; $i < 10; $i++) echo "Number <b>$i</b> coming at you!<br>";

?>
