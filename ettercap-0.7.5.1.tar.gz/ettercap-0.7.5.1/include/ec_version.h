

#ifndef EC_VERS_H
#define EC_VERS_H

#define EC_VERSION            "0.7.5.1"
#define EC_VERSION_MAJOR      0
#define EC_VERSION_MINOR      7
#define EC_VERSION_REVISION   5 
#define EC_PROGRAM            "ettercap"
#define EC_COPYRIGHT          "2001-2013"
#define EC_AUTHORS            "Ettercap Development Team"

#endif

/* EOF */

