

#ifndef EC_SIGNAL_H
#define EC_SIGNAL_H

EC_API_EXTERN void signal_handler(void);

#endif

/* EOF */

// vim:ts=3:expandtab

