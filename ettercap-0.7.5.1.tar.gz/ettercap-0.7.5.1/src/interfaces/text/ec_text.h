

#ifndef EC_TEXT_H
#define EC_TEXT_H

extern int text_plugin(char *plugin);
extern void text_print_packet(struct packet_object *po);
extern void text_profiles(void);
extern void text_connections(void);

#endif

/* EOF */

// vim:ts=3:expandtab

