/*
 * Copyright 2003-2009 (C) Raster Software Vigo (Sergio Costas)
 * This file is part of FBZX
 *
 * FBZX is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * FBZX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

#ifndef H_TAPE
#define H_TAPE

inline void tape_read(FILE *, int);
inline void tape_read_tap(FILE *, int);
inline void tape_read_tzx(FILE *, int);
void rewind_tape(FILE *,unsigned char);
unsigned char file_empty(FILE *);
void fastload_block (FILE *);
void save_file(FILE *);

#endif
