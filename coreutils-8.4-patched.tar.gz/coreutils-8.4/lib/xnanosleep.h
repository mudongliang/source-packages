int xnanosleep (double);
