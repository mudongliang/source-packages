#include <stddef.h>
size_t xmemxfrm (char *restrict, size_t, char *restrict, size_t);
