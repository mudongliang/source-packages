int strintcmp (char const *, char const *);
int strnumcmp (char const *, char const *, int, int);
