#define inttostr offtostr
#define inttype off_t
#define inttype_is_signed 1
#include "inttostr.c"
