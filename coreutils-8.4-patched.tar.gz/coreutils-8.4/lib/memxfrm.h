#include <stddef.h>
size_t memxfrm (char *restrict, size_t, char *restrict, size_t);
