/*
 *
 * (c) Vladi Belperchinov-Shabanski "Cade" <cade@biscom.net> 1998-2003
 *
 * SEE `README',`LICENSE' OR `COPYING' FILE FOR LICENSE AND OTHER DETAILS!
 *
 * $Id: vslib.cpp,v 1.8 2003/01/21 19:56:35 cade Exp $
 *
 */

// eof vslib.cpp
