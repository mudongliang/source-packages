int cole_major_version = 2;
int cole_minor_version = 0;
int cole_micro_version = 1;
char * cole_version = "2.0.1";
char * cole_host_info = " (): , , ";
