#define SSH_VERSION	"OpenSSH_2.2.0p1"
