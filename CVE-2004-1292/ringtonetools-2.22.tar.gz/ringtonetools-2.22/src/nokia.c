#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

void write_nokia_header(FILE *out, struct note_t *note)
{
int l,t;

  bitptr=7;

  note->bytes=0;

  push(2,8);   /* ring tone commands */
  push(74,8);
  push(29,7);

  l=strlen(note->songname);
  push(1,3);   /* song type */
  push(l,4);   /* length of song name */

  for (t=0; t<l; t++)
  { push(note->songname[t],8); }

  push(1,8);   /* 1 song pattern */
  push(0,3);   /* pattern header id */
  push(0,2);   /* A-part */

  push(note->flats,4); /* looping  */

#ifdef DEBUG
  printf("stackptr=%d   bitptr=%d\n",stackptr,bitptr);
#endif

  note->marker=stackptr;
  note->mcc=bitptr;
  push(0,8);

  l=get_tempo(note->bpm);
  t=reverse_tempo(l);

  if (t!=note->bpm)
  {
    if (quiet==0)
    { printf("Warning:  Tempo has been adjusted to %d bpm due to Nokia limitations\n",t); }
  }
  push(4,3);       /* set tempo */
  push(l,5);
  note->bytes++;

  push(3,3);       /* set style */
  push(note->style,2);
  note->bytes++;

  push(5,3);       /* set volume */
  push(note->volume,4);
  note->bytes++;
}

void write_nokia_note(FILE *out, struct note_t *note)
{
  note->scale+=note->transpose;
  if (note->scale<0) note->scale=0;

  if (note->prev_scale!=note->scale)
  {
    note->prev_scale=note->scale;
    push(2,3);
    push(note->scale+1,2);
    note->bytes++;
  }

  push(1,3);
  push(note->tone,4);
  push(note->length,3);
  push(note->modifier,2);
  note->bytes++;
}

void write_nokia_style(FILE *out, struct note_t *note)
{
  push(3,3);       /* set style */
  push(note->style,2);
  note->bytes++;
}

void write_nokia_footer(FILE *out, struct note_t *note)
{
  if (bitptr!=7) stackptr++;
  push(0,8);

#ifdef DEBUG
  printf("commands: %d    a0=%d   b0=%d\n",note->bytes,note->marker,note->mcc);
#endif

  push_addr(note->bytes,8,note->marker,note->mcc);
  write_codes(out,"1581");
}


void write_nokia_logo_header(FILE *out, struct note_t *note)
{
int t,k,r;

  stackptr=0;
  bitptr=7;

  push(0x30,8);   /* Identifier for version */

  if (note->mcc!=-1 && note->mnc!=-1)
  {
    t=note->mcc%10;
    k=(note->mcc/10)%10;
    r=(note->mcc/100)%10;
    push((k<<4)+r,8);   /* MCC Mobile Country Code */
    push(0xf0+t,8);     /* MCC Mobile Country Code */
    t=note->mnc%10;
    k=(note->mnc/10)%10;
    push((t<<4)+k,8);   /* MNC Mobile Network Code */
    push(0x0A,8);       /* Line feed */
  }
    else
  if ((note->bmp_flags&2)==2)
  {
    push(0x06,8);
    k=((note->height*note->width)/8)+4;
    if (((note->height*note->width)%8)!=0) k++;
    push((k>>8),8);
    push((k&255),8);
  }
    else
  if (note->message!=0)
  {
    push(0x00,8);
    k=strlen(note->message);
    push((k>>8),8);
    push((k&255),8);

    for(t=0; t<k; t++)
    { push(note->message[t],8); }

    push(0x02,8);
    k=((note->height*note->width)/8)+4;
    if (((note->height*note->width)%8)!=0) k++;
    push((k>>8),8);
    push((k&255),8);
  }

  push(0x00,8);          /* Info Field? */
  push(note->width,8);   /* height and width DUH */
  push(note->height,8);
  push(0x01,8);          /* picture depth */
}

void write_nokia_logo_footer(FILE *out, struct note_t *note)
{
int x,y,c,ptr;

  ptr=0;
  for (y=0; y<note->height; y++)
  {
    for (x=0; x<note->width; x++)
    {
      c=note->picture[ptr++];
      c=((c&255)+((c>>8)&255)+((c>>16)&255))/3;
      if (c>COLOR_THRESHOLD)
      { push(1,1); }
        else
      { push(0,1); }
    }
  }

  stackptr++;

  if (note->mcc!=-1 && note->mnc!=-1)
  { write_codes(out,"1582"); }
    else
  if ((note->bmp_flags&2)==2)
  { write_codes(out,"158A"); }
    else
  { write_codes(out,"1583"); }
}

void write_nokia_bpm(FILE *out, struct note_t *note)
{
int t;

  t=get_tempo(note->bpm);
  push(4,3);
  push(t,5);
  note->bytes++;
}

void write_nokia_volume(FILE *out, struct note_t *note)
{
  push(5,3);       /* set volume */
  push(note->volume,4);
  note->bytes++;
}

void write_ngg_logo_header(FILE *out, struct note_t *note)
{
  if (note->ems==0)
  {
    fprintf(out,"NOL%c%c%c",0,1,0);
    write_word(out,note->mcc);
    write_word(out,note->mnc);
  }
    else
  {
    fprintf(out,"NGG%c%c%c",0,1,0);
  }

  write_word(out,note->width);
  write_word(out,note->height);
  write_word(out,1);
  write_word(out,1);
  write_word(out,0x53);
}

void write_ngg_logo_footer(FILE *out, struct note_t *note)
{
int x,y,c,ptr;

  ptr=0;
  for (y=0; y<note->height; y++)
  {
    for (x=0; x<note->width; x++)
    {
      c=note->picture[ptr++];
      c=((c&255)+((c>>8)&255)+((c>>16)&255))/3;
      if (c>COLOR_THRESHOLD)
      { putc('1',out); }
        else
      { putc('0',out); }
    }
  }

  fprintf(out,"Created by Michael Kohn's Ringtone Tools - http://ringtonetools.mikekohn.net/");
}


