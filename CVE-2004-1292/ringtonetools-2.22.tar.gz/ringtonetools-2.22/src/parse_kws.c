#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

int get_duration(float duration);

int parse_kws(FILE *in, FILE *out, int out_type, struct note_t *note)
{
char notes[2048];
int duration[2048];
int file_length,count;
int t,a,b,ch;
int quarter_note;

  t=0;
  if (note->songname[0]==0)
  {
    while(note->filename[t]!='.' && note->filename[t]!=0 && t<14)
    {
      note->songname[t]=note->filename[t];
      t++;
    }
    note->songname[t]=0;
  }

  file_length=read_long(in);
  file_length=file_length^0xffffffff;
  count=read_word(in);

  fseek(in,0,SEEK_END);

  if (ftell(in)!=file_length)
  {
    printf("This is not a KWS file.\n");
    return -1;
  }
  fseek(in,6,SEEK_SET);

  if (count>2040)
  {
    printf("This song is too long.\n");
    return -1;
  }

  for (t=0; t<count; t++)
  {
    ch=getc(in);
    notes[t]=ch;
    ch=getc(in);
    if (ch!=4) notes[t]=0;

    a=getc(in);
    b=getc(in);

    a=a^(b<<1);

    duration[t]=(b<<8)+a;

    if (t==0) quarter_note=duration[t];
  }

  t=0;
  while(t<8)
  {
    note->bpm=60000/quarter_note;
    if (note->bpm<250) break;

    quarter_note=quarter_note*2;
    t++;
  }

  t=0;
  while(t<8)
  {
    if (note->bpm>90) break;
    quarter_note=quarter_note/2;
    note->bpm=60000/quarter_note;

    t++;
  }

  header_route(out,note,6,out_type);

  for (t=0; t<count; t++)
  {
    if (notes[t]==0)
    {
      note->tone=0;
    }
      else
    {
      note->tone=(notes[t]-1)%12+1;
      note->scale=(notes[t]-1)/12;
    }

    a=get_duration((float)duration[t]/((float)quarter_note*4));
    note->length=a/2;
    note->modifier=(a%2)^1;

    if (t!=count-1 || note->tone!=0)
    {
      note_route(out,note,6,out_type);
    }
  }

  footer_route(out,note,6,out_type);

  return (0);
}



