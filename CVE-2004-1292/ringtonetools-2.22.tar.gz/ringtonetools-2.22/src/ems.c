#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* EMS */

void write_ems_header(FILE *out, struct note_t *note)
{

}

void write_ems(char *s)
{
int l,t;

  l=strlen(s);

  for (t=0; t<l; t++)
  {
    ring_stack[stackptr++]=s[t];
  }
}

void write_ems_footer(FILE *out, struct note_t *note)
{
int t;

  if (stackptr>128)
  {
    if (quiet==0)
    {
      printf("Error: EMS data exceeds 128 octets.  Message is truncated.\n");
      stackptr=128;
    }
  }

  fprintf(out,"%02X0C%02X00",stackptr+3,stackptr+1);

  for (t=0; t<stackptr; t++)
  {
    fprintf(out,"%02X",ring_stack[t]);
  }
}

void write_ems_logo_header(FILE *out, struct note_t *note)
{
  if (note->width==16 && note->height==16)
  {
    note->width=16;
    note->height=16;
    note->ems=0x11;
  }
    else
  if (note->width==32 && note->height==32)
  {
    note->width=32;
    note->height=32;
    note->ems=0x10;
  }
    else
  {
    note->ems=0x12;
  }
}

void write_ems_logo_footer(FILE *out, struct note_t *note)
{
int x,y,b,c,ptr;
int octets,k;

  ptr=0;
  octets=0;

  for (y=0; y<note->height; y++)
  {
    x=0;
    while (x<note->width)
    {
      k=0;

      for (b=7; b>=0; b--)
      {
        if (x<note->width)
        {
          c=note->picture[ptr++];
          c=((c&255)+((c>>8)&255)+((c>>16)&255))/3;

          if (c>COLOR_THRESHOLD)
          { k=k+(1<<b); }
        }
        x++;
      }

      note->picture[octets++]=k;
    }
  }

  if (octets>128)
  {
    if (quiet==0)
    {
      printf("Warning: EMS data exceeds 128 octets.  Message has been tructated.\n");
    }
    octets=128;
  }

  if (note->ems==0x12)
  {
    if ((note->width%8)!=0)
    {
      printf("Warning:  Width needs to be a multiple of 8 pixels.\n");
      note->width=note->width+(8-(note->width%8));
    }
    fprintf(out,"%02X%02X%02X00",octets+5,note->ems,octets+3);
    fprintf(out,"%02X%02X",note->width/8,note->height);
  }
    else
  { fprintf(out,"%02X%02X%02X00",octets+3,note->ems,octets+1); }

  for (k=0; k<octets; k++)
  {
    fprintf(out,"%02X",note->picture[k]);
  }
}



