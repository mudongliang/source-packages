
#define VERSION "2.22"
#define DATE_RELEASED "August 20, 2004"
#define VOLUME 7
#define SMS_SIZE 140
#define RINGSTACK_SIZE 8192
#define COPYRIGHT "Copyright 2001-2004 - Michael Kohn (mike@mikekohn.net)\n\n" \
                  "THIS MAY NOT BE USED IN COMMERCIAL ENVIRONMENTS WITHOUT\n" \
                  "PERMISSION OF THE AUTHOR.  PLEASE READ THE LICENSE.\n\n"

#define SONGNAME_LEN 64
#define MAX_WIDTH 640
#define MAX_HEIGHT 480
#define COLOR_THRESHOLD 50

extern short int ring_stack[RINGSTACK_SIZE];
extern int stackptr;
extern int bitptr;

extern int headers;
extern int full_sms_size;
extern int quiet;

int reverse_tempo(int l);
int get_tempo(int tempo);
void push(int data, int size);
void push_addr(int data, int size, int stackptr, int bitptr);
void print_hex(int t);
void write_codes(FILE *out, char *port);

void check_songname(FILE *in, char *songname);
int gettoken(FILE *fp, char *token, int flag);
int convcolor(char *s);

int color_distance(int c1, int c2);
int get_color(int col, int *palette, int palette_count);



