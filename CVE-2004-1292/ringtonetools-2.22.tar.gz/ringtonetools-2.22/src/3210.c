#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtonetools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* 3210 */

void write_3210_header(FILE *out, struct note_t *note)
{
  if (note->songname[0]==0)
  { strcpy(note->songname,"unamed"); }

  fprintf(out,"%s:Tempo=%d\n",note->songname,note->bpm);
}

void write_3210_note(FILE *out, struct note_t *note)
{
  if (note->note_count>0) fprintf(out," ");

  fprintf(out,"%d",(1<<(note->length)));

  if (note->modifier!=0) fprintf(out,".");

  if (note->tone==0) fprintf(out,"-");
    else
  if (note->tone==1) fprintf(out,"c");
    else
  if (note->tone==2) fprintf(out,"#c");
    else
  if (note->tone==3) fprintf(out,"d");
    else
  if (note->tone==4) fprintf(out,"#d");
    else
  if (note->tone==5) fprintf(out,"e");
    else
  if (note->tone==6) fprintf(out,"f");
    else
  if (note->tone==7) fprintf(out,"#f");
    else
  if (note->tone==8) fprintf(out,"g");
    else
  if (note->tone==9) fprintf(out,"#g");
    else
  if (note->tone==10) fprintf(out,"a");
    else
  if (note->tone==11) fprintf(out,"#a");
    else
  if (note->tone==12) fprintf(out,"b");
 /* if (note->tone==12) fprintf(out,"h"); */

  if (note->tone!=0)
  {
    fprintf(out,"%d",note->scale+1);
  }
}

void write_3210_footer(FILE *out, struct note_t *note)
{
  fprintf(out,"\n");
}

