#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#include "general.h"
#include "fileoutput.h"

/*

ringtonetools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

int full_sms_size=SMS_SIZE;
int headers=1;
int quiet=0;

int get_intype(char *param)
{
  if (strcasecmp(param,"rtttl")==0 || strcasecmp(param,"nokring")==0)
  { return 0; }
    else
  if (strcasecmp(param,"rtx")==0)
  { return -2; }
    else
  if (strcasecmp(param,"imelody")==0 || strcasecmp(param,"imy")==0)
  { return 1; }
    else
  if (strcasecmp(param,"wav")==0)
  { return 2; }
    else
  if (strcasecmp(param,"bmp")==0)
  { return 3; }
    else
  if (strcasecmp(param,"text")==0 || strcasecmp(param,"txt")==0)
  { return 4; }
    else
  if (strcasecmp(param,"midi")==0 || strcasecmp(param,"mid")==0)
  { return 5; }
    else
  if (strcasecmp(param,"kws")==0)
  { return 6; }
    else
  if (strcasecmp(param,"siemens")==0)
  { return 7; }
    else
  if (strcasecmp(param,"emelody")==0 || strcasecmp(param,"emy")==0)
  { return 8; }
    else
  if (strcasecmp(param,"3210")==0)
  { return 9; }
    else
  if (strcasecmp(param,"nok")==0 || strcasecmp(param,"nokia")==0 || strcasecmp(param,"sckl")==0)
  { return 10; }
    else
  if (strcasecmp(param,"morse")==0)
  { return 11; }
    else
  if (strcasecmp(param,"ems")==0)
  { return 12; }
    else
  if (strcasecmp(param,"nol")==0 || strcasecmp(param,"ngg")==0)
  { return 13; }
    else
  if (strcasecmp(param,"wbmp")==0)
  { return 14; }
    else
  if (strcasecmp(param,"ico")==0 || strcasecmp(param,"icon")==0)
  { return 15; }
    else
  if (strcasecmp(param,"gif")==0)
  { return 16; }

  return -1;
}

int get_outtype(char *param)
{
  if (strcasecmp(param,"wav")==0)
  { return 0; }
    else
  if (strcasecmp(param,"kws")==0)
  { return 1; }
    else
  if (strcasecmp(param,"mot")==0)
  { return 2; }
    else
  if (strcasecmp(param,"pdb")==0)
  { return 3; }
    else
  if (strcasecmp(param,"nok")==0 || strcasecmp(param,"nokia")==0 || strcasecmp(param,"sckl")==0)
  { return 4; }
    else
  if (strcasecmp(param,"rtttl")==0 || strcasecmp(param,"nokring")==0)
  { return 5; }
    else
  if (strcasecmp(param,"samsung1")==0)
  { return 6; }
    else
  if (strcasecmp(param,"samsung2")==0)
  { return 7; }
    else
  if (strcasecmp(param,"midi")==0 || strcasecmp(param,"mid")==0)
  { return 8; }
    else
  if (strcasecmp(param,"siemens")==0)
  { return 9; }
    else
  if (strcasecmp(param,"emelody")==0 || strcasecmp(param,"emy")==0)
  { return 11; }
    else
  if (strcasecmp(param,"imelody")==0 || strcasecmp(param,"imy")==0)
  { return 12; }
    else
  if (strcasecmp(param,"rtx")==0)
  { return 13; }
    else
  if (strcasecmp(param,"ems")==0)
  { return 14; }
    else
  if (strcasecmp(param,"3210")==0)
  { return 15; }
    else
  if (strcasecmp(param,"seo")==0)
  { return 16; }
    else
  if (strcasecmp(param,"bmp")==0)
  { return 17; }
    else
  if (strcasecmp(param,"text")==0 || strcasecmp(param,"txt")==0)
  { return 18; }
    else
  if (strcasecmp(param,"dsp")==0)
  { return 19; }
    else
  if (strcasecmp(param,"nol")==0)
  { return 20; }
    else
  if (strcasecmp(param,"ngg")==0)
  { return 21; }
    else
  if (strcasecmp(param,"wbmp")==0)
  { return 22; }
    else
  if (strcasecmp(param,"ico")==0 || strcasecmp(param,"icon")==0)
  { return 23; }
    else
  if (strcasecmp(param,"gif")==0)
  { return 24; }

  return -1;
}

int main (int argc, char *argv[])
{
FILE *in, *out;
char message[1024];
int t,n,flag=0;
struct note_t note;
int out_type,in_type;

  memset(&note, 0, sizeof(struct note_t));

  note.sample_rate=44100;
  note.bytes=2;
  note.bpm=140;
  note.a440=5;
  note.ats=1;
  note.volume=7;
  note.loop=0;

  note.width=72;
  note.height=14;
  note.mcc=-1;
  note.mnc=-1;
  note.trans=-1;

  note.pause=2;
  note.picture=0;
  note.message=0;
  note.bmp_flags=0;

  out_type=-1;
  in_type=-1;

  note.outname[0]=0;
  note.filename[0]=0;
  message[0]=0;
  stackptr=0;
  bitptr=0;

  if (argc<2)
  {
    printf("\nringtonetools "VERSION" - Convert and create ringtones/logos for mobile phones.\n");
    printf(COPYRIGHT);
    printf("Usage: ringtonetools [ options ] <input filename> <output filename>\n");
    printf("       -intype <input type> [ 3210/bmp/emelody,emy/ems/gif/ico,icon/imelody,imy/kws/midi,mid/morse/nol,ngg/nokia,sckl/rtttl/rtx/siemens/text,txt/wav/wbmp ]\n");
    printf("       -outtype <output type> [ 3210/bmp/dsp/emelody,emy/ems/gif/ico,icon/imelody,imy/kws/midi,mid/mot/nol,ngg/nokia,sckl/pdb/rtttl/rtx/samsung1/samsung2/siemens/seo/text,txt/wav/wbmp ]\n");
    printf("       -name <song name>\n");
    printf("       -t <tempo [default: %d]>\n",note.bpm);
    printf("       -quiet\n");
    printf("   iMelody options:\n");
    printf("       -noheaders [ no headers ]\n");
    printf("       -melheaders [ melody header only <default> ]\n");
    printf("       -lessheaders [ begin,melody,end headers only ]\n");
    printf("       -mostheaders [ begin,melody,end,name,tempo headers on iMelody ]\n");
    printf("       -stdheaders [ begin,melody,end,name,tempo,style headers on iMelody ]\n");
    printf("       -fullheaders [ full headers on iMelody ]\n");
    printf("       -ems [ force EMS ]\n");
    printf("   Kyeocera KWS options:\n");
    printf("       -pause <number of quarter notes added to end of song [ default: 2 ]>\n");
    printf("   Motorola options:\n");
    printf("       -keypress [ Make keypress sequence for phones like v60t ]\n");
    printf("   wav output options:\n");
    printf("       -b <bits 8 or 16 for wav only [default: 16]>\n");
    printf("       -f <sampling frequency for wav only [default: 44100]>\n");
    printf("   graphics options:\n");
    printf("       -h <height> [ Height of Logo (default %d) ]\n",note.height);
    printf("       -w <width> [ Width of Logo (default %d) ]\n",note.width);
    printf("       -l <MCC> <MNC> [ Operator Logo (requires MCC and MNC) ]\n");
    printf("       -m <message> [ Send a picture message ]\n");
    printf("       -r [ reverse black n white ]\n");
    printf("       -c [ use full color if possible ]\n");
    printf("       -trans <0xrrggbb> [ make this hex code a transparent color  ]\n");
    printf("       -bmptrans [ Use BMP's transparency ]\n");
    printf("   nokia options:\n");
    printf("       -x [ exclude //SCKL header ]\n");
    printf("       -u [ only user-data-header (8bit) ]\n");
    printf("       -k [ include user-data-header and //SCKL ]\n");
    printf("       -s <sms size> [ Maximum size of SMS message (default %d)\n",SMS_SIZE);
    printf("       -transpose <pos or neg num > [ raise or lower song by n octaves ]\n");
    printf("       -ss Send as screensaver\n");
    printf("   midi options:\n");
    printf("       -channel [ channel ]\n");
    printf("       -track [ track ]\n");
#ifdef DSP
    printf("   sound output:\n");
    printf("       -dsp (write out to the sound device)\n");
#endif

    exit(0);
  }

  n=0;

  for (t=1; t<argc; t++)
  {
    if (strcmp(argv[t],"-a")==0)
    { note.ats=0; }
      else
    if (strcmp(argv[t],"-t")==0)
    { note.bpm=atoi(argv[++t]); }
      else
    if (strcmp(argv[t],"-f")==0)
    { note.sample_rate=atoi(argv[++t]); }
      else
    if (strcmp(argv[t],"-r")==0)
    { note.bmp_flags^=1; }
      else
    if (strcmp(argv[t],"-c")==0)
    { note.bmp_flags^=4; }
      else
    if (strcmp(argv[t],"-trans")==0)
    { note.trans=convcolor(argv[++t]); }
      else
    if (strcmp(argv[t],"-bmptrans")==0)
    { note.trans=-2; }
      else
    if (strcmp(argv[t],"-h")==0)
    {
      if (t+1<argc)
      {
        note.height=atoi(argv[++t]);
        if (note.height>MAX_WIDTH) note.height=MAX_WIDTH;
      }
    }
      else
    if (strcmp(argv[t],"-w")==0)
    {
      note.width=atoi(argv[++t]);
      if (note.width>MAX_WIDTH) note.width=MAX_WIDTH;
    }
      else
    if (strcmp(argv[t],"-ems")==0)
    { note.ems=1; }
      else
    if (strcmp(argv[t],"-noheaders")==0)
    { headers=0; }
      else
    if (strcmp(argv[t],"-melheaders")==0)
    {
      headers=1;
      printf("\nThe -melheaders option is default.  Don't use it!\n\n");
      exit(0);
    }
      else
    if (strcmp(argv[t],"-lessheaders")==0)
    { headers=2; }
      else
    if (strcmp(argv[t],"-mostheaders")==0)
    { headers=3; }
      else
    if (strcmp(argv[t],"-stdheaders")==0)
    { headers=4; }
      else
    if (strcmp(argv[t],"-fullheaders")==0)
    { headers=5; }
      else
    if (strcmp(argv[t],"-quiet")==0)
    { quiet=1; }
      else
    if (strcmp(argv[t],"-x")==0)
    { headers=0; }
      else
    if (strcmp(argv[t],"-k")==0)
    { headers=2; }
      else
    if (strcmp(argv[t],"-u")==0)
    { headers=3; }
      else
    if (strcmp(argv[t],"-ss")==0)
    { note.bmp_flags^=2; }
      else
    if (strcmp(argv[t],"-pause")==0)
    { note.pause=atoi(argv[++t]); }
      else
    if (strcmp(argv[t],"-keypress")==0)
    { flag=1; }
      else
    if (strcmp(argv[t],"-s")==0)
    { full_sms_size=atoi(argv[++t]); }
      else
    if (strcmp(argv[t],"-channel")==0)
    { note.mcc=atoi(argv[++t]); }
      else
    if (strcmp(argv[t],"-track")==0)
    { note.mnc=atoi(argv[++t]); }
      else
    if (strcmp(argv[t],"-b")==0)
    { 
      note.bytes=atoi(argv[++t]);
      if (note.bytes==16)
      { note.bytes=2; }
        else
      { note.bytes=1; }
    }
      else
    if (strcmp(argv[t],"-l")==0)
    {
      note.mcc=atoi(argv[++t]);
      note.mnc=atoi(argv[++t]);
    }
      else
    if (strcmp(argv[t],"-transpose")==0)
    {
      note.transpose=atoi(argv[++t]);
    }
      else
    if (strcmp(argv[t],"-m")==0)
    { 
      strcpy(message,argv[++t]);
      note.message=message;
    }
      else
    if (strcmp(argv[t],"-name")==0)
    { 
      strncpy(note.songname,argv[++t],SONGNAME_LEN);
      note.songname[SONGNAME_LEN-1]=0;
    }
      else
#ifdef DSP
    if (strcmp(argv[t],"-dsp")==0)
    {
      out_type=19;
      strcpy(note.outname,"/dev/dsp");
    }
      else
#endif
    if (strcmp(argv[t],"-outtype")==0)
    {
      t++;
      out_type=get_outtype(argv[t]);
    }
      else
    if (strcmp(argv[t],"-intype")==0)
    {
      t++;
      in_type=get_intype(argv[t]);

      if (in_type==0) note.a440=5;
        else
      if (in_type==-2)
      {
        note.a440=4;
        in_type=0;
      }
    }
      else
    if (argv[t][0]=='-' && !(argv[t][1]=='.' || argv[t][1]==0))
    {
      printf("Unknown option %s.  Exiting...\n",argv[t]);
      exit(1);
    }
      else
    if (n==0)
    { strncpy(note.filename,argv[t],1023); n++; }
      else
    { strcpy(note.outname,argv[t]); }
  }

  if (in_type==-1)
  {
    t=strlen(note.filename);
    while(t>0 && note.filename[t]!='.') t--;

    if (note.filename[t]=='.')
    {
      t++;
      in_type=get_intype(&note.filename[t]);

      if (in_type==0) note.a440=5;
        else
      if (in_type==-2)
      {
        note.a440=4;
        in_type=0;
      }
    }

    if (in_type==-1) in_type=0;
  }

  if (out_type==-1 && note.outname[0]!=0)
  {
    t=strlen(note.outname);
    while(t>0 && note.outname[t]!='.') t--;

    if (note.outname[t]=='.')
    {
      t++;
      out_type=get_outtype(&note.outname[t]);
    }
  }

  if (out_type==-1) out_type=0;

#ifdef DSP
  if (strncmp(note.outname,"/dev/dsp",sizeof("/dev/dsp"))==0) out_type=19;
#endif

#ifndef DSP
  if (out_type==19) { printf("No DSP support compiled in\n"); exit(1); }
#endif

  if (note.outname[0]==0)
  {
    strcpy(note.outname,note.filename);

    t=strlen(note.outname);

    while(t>0)
    {
      if (note.outname[t]=='.')
      {
        note.outname[t+1]=0;
        break;
      }
      t--;
    }

    if (out_type==0)
    { strcat(note.outname,"wav"); }
      else
    if (out_type==1)
    { strcat(note.outname,"kws"); }
      else
    if (out_type==2)
    { strcat(note.outname,"mot"); }
      else
    if (out_type==3)
    { strcat(note.outname,"pdb"); }
      else
    if (out_type==4)
    { strcat(note.outname,"nokia"); }
      else
    if (out_type==5)
    { strcat(note.outname,"rtttl"); }
      else
    if (out_type==6)
    { strcat(note.outname,"samsung1"); }
      else
    if (out_type==7)
    { strcat(note.outname,"samsung2"); }
      else
    if (out_type==8)
    { strcat(note.outname,"midi"); }
      else
    if (out_type==9)
    { strcat(note.outname,"siemens"); }
      else
    if (out_type==11)
    { strcat(note.outname,"emelody"); }
      else
    if (out_type==12)
    { strcat(note.outname,"imy"); }
      else
    if (out_type==13)
    { strcat(note.outname,"rtx"); }
      else
    if (out_type==14)
    { strcat(note.outname,"ems"); }
      else
    if (out_type==15)
    { strcat(note.outname,"3210"); }
      else
    if (out_type==16)
    { strcat(note.outname,"seo"); }
      else
    if (out_type==17)
    { strcat(note.outname,"bmp"); }
      else
    if (out_type==18)
    { strcat(note.outname,"txt"); }
      else
    if (out_type==20)
    { strcat(note.outname,"nol"); }
      else
    if (out_type==21)
    { strcat(note.outname,"ngg"); }
      else
    if (out_type==22)
    { strcat(note.outname,"wbmp"); }
      else
    if (out_type==23)
    { strcat(note.outname,"ico"); }
  }

  if (quiet==0)
  {
    printf("\nRingtonetools "VERSION" ("DATE_RELEASED")\n");
    printf(COPYRIGHT);

    printf(" Infile: %s\n",note.filename);
    printf("Outfile: %s\n",note.outname);
  }

  if (out_type==2 && (flag&1)==1) out_type=10;
  if (out_type==13) { out_type=5; note.channels=1; }
  if (!(in_type==3 || in_type==4) && out_type==14)
  {
    out_type=12;
    note.ems=1;
  }

  if (note.filename[0]!='-')
  {
    in=fopen(note.filename,"rb");
    if (in==0)
    {
      printf("Could not open file for reading: %s\n",note.filename);
      exit(1);
    }
  }
    else
  { in=fdopen(STDIN_FILENO,"r"); }

  if (note.outname[0]!='-')
  {
    if (out_type!=19)
    {
      out=fopen(note.outname,"wb+");
      if (out==0)
      {
        printf("Could not open file for writing: %s\n",note.outname);
        fclose(in);
        exit(1);
      }
    }
      else
    { out=0; }
  }
    else
  { out=fdopen(STDOUT_FILENO,"wb+"); }

  if (out_type==21) note.ems=1;

  if (out_type==3 && in_type==5)
  { write_treo_pdb(in, out, &note); }
    else
  if (out_type==16)
  {
    if (in_type==3 || in_type==5)
    { write_seo(in, out, in_type, &note); }
      else
    { printf("SEO format only supports BMP and MIDI\n"); }
  }
    else
  if (in_type==0)
  { parse_rtttl(in,out,out_type,&note); }
    else
  if (in_type==1)
  { parse_imelody(in,out,out_type,&note); }
    else
  if (in_type==2)
  {
    if (out_type==3)
    { wav2pdb(in,out,&note); }
      else
    { 
      printf("Wav's can only be converted to pdb's.\n");
      parse_wav(in,out,out_type,&note);
    }
  }
    else
  if (in_type==3)
  { parse_bmp(in,out,out_type,&note); }
    else
  if (in_type==4)
  { parse_text(in,out,out_type,&note); }
    else
  if (in_type==13)
  { parse_ngg(in,out,out_type,&note); }
    else
  if (in_type==14)
  { parse_wbmp(in,out,out_type,&note); }
    else
  if (in_type==15)
  { parse_icon(in,out,out_type,&note); }
    else
  if (in_type==16)
  { parse_gif(in,out,out_type,&note); }
    else
  if (in_type==5)
  { parse_midi(in,out,out_type,&note); }
    else
  if (in_type==6)
  { parse_kws(in,out,out_type,&note); }
    else
  if (in_type==7)
  { parse_siemens(in,out,out_type,&note); }
    else
  if (in_type==8)
  { parse_emelody(in,out,out_type,&note); }
    else
  if (in_type==9)
  { parse_3210(in,out,out_type,&note); }
    else
  if (in_type==10)
  { parse_sckl(in,out,out_type,&note); }
    else
  if (in_type==11)
  { parse_morsecode(in,out,out_type,&note); }
    else
  if (in_type==12)
  { parse_ems(in,out,out_type,&note); }

  if (note.outname[0]=='-') fprintf(out,"\n");

  fclose(in);
  if (out!=0) fclose(out);

  return (0);
}


