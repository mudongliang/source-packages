#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "general.h"
#include "fileoutput.h"

#define COLOR_BMP 1

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

int parse_text(FILE *in, FILE *out, int out_type, struct note_t *note)
{
int x,y,lastch,ch;

  logo_header_route(out,note,out_type);

  x=0; y=0; lastch=0;
  while ((ch=getc(in))!=EOF)
  {
    if (ch=='\n' || ch=='\r')
    {
      if ((lastch=='\r' || lastch=='\n') && (ch!=lastch && lastch!=0))
      { continue; }

      x=0; y++;
      lastch=ch;
      continue;
    }

    if (x<note->width)
    {
      if (ch==' ')
      { note->picture[x+(y*note->width)]=0; }
        else
      { note->picture[x+(y*note->width)]=0xffffff; }
    }

    x++;
  }

  logo_footer_route(out,note,out_type);

  return 0;
}

int parse_ngg(FILE *in, FILE *out, int out_type, struct note_t *note)
{
char temp[7];
int t,ptr,count,ch;

  read_chars(in,temp,6);
  temp[3]=0;

  if (strcasecmp(temp,"nol")==0)
  {
    note->mcc=read_word(in);
    note->mnc=read_word(in);
  }

  note->width=read_word(in);
  note->height=read_word(in);
  read_chars(in,temp,6);

  count=note->width*note->height;

  logo_header_route(out,note,out_type);

  ptr=0;
  for (t=0; t<count; t++)
  {
    ch=(getc(in));
    if (ch=='0')
    { note->picture[ptr++]=0; }
      else
    { note->picture[ptr++]=0xffffff; }
  }

  logo_footer_route(out,note,out_type);

  return 0;
}

/*
int parse_logo(FILE *in, FILE *out, int in_type, int out_type, struct note_t *note, char *message)
{
int x,y,reverse;
char picture[8192];

  bitptr=7;

  if ((note->bmp_flags&1)==1)
  { reverse=0; }
    else
  { reverse=1; }

#ifdef DEBUG
  printf("         Width: %d\n",note->width);
  printf("        Height: %d\n",note->height);
  printf("      SMS Size: %d\n",full_sms_size);

  if (note->mcc!=-1 && note->mnc!=-1)
  {
    printf("       MCC MNC: %d %d\n",note->mcc,note->mnc);
  }
#endif

  logo_header_route(out,note,out_type,message);

  if (in_type==3)
  {
    if (parse_bitmap(in,note->width,note->height,picture)==-1)
    {
      printf("Could not read BMP.\n");
      return -1; 
    }

    for (y=note->height-1; y>=0; y--)
    {
      for (x=0; x<note->width; x++)
      {
        if (picture[(y*note->width)+x]==' ')
        {
          push(1^reverse,1);
        }
          else
        {
          push(0^reverse,1);
        }
      }
    }
  }
    else
  if (in_type==4)
  {
    parse_text(in,note,picture);

    for (y=0; y<note->height; y++)
    {
      for (x=0; x<note->width; x++)
      {
        if (picture[(y*note->width)+x]==' ')
        {
          push(1^reverse,1);
        }
          else
        {
          push(0^reverse,1);
        }
      }
    }
  }

#ifdef DEBUG

  printf("\n");
  for (y=note->height-1; y>=0; y--)
  {
    for (x=0; x<note->width; x++)
    {
      if (picture[(y*note->width)+x]==' ')
      {
        printf("_");
      }
        else
      {
        printf("*");
      }
    }
    printf("\n");
  }
#endif

  logo_footer_route(out,note,out_type);

  return (0);
}
*/

#ifdef DEBUG
void debug_logo(struct note_t *note)
{
int x,y,c,ptr;

  printf("%d x %d\n",note->width,note->height);

  ptr=0;
  for (y=0; y<note->height; y++)
  {
    for (x=0; x<note->width; x++)
    {
      c=note->picture[ptr++];
      c=((c&255)+((c>>8)&255)+((c>>16)&255))/3;

      if (COLOR_BMP==1)
      {
        if (c<20)
        { printf(" "); }
          else
        if (c<40)
        { printf("."); }
          else
        if (c<60)
        { printf(","); }
          else
        if (c<80)
        { printf(":"); }
          else
        if (c<100)
        { printf("|"); }
          else
        if (c<120)
        { printf("&"); }
          else
        if (c<180)
        { printf("@"); }
          else
        if (c<210)
        { printf("*"); }
          else
        { printf("#"); }
      }
        else
      {
        if (c>COLOR_THRESHOLD)
        { printf("*"); }
          else
        { printf(" "); }
      }
    }
    printf("|\n");
  }

}
#endif
