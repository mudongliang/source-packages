#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* eMelody for older Ericsson */

void write_emelody_header(FILE *out, struct note_t *note)
{

}

void write_emelody_note(FILE *out, struct note_t *note)
{
char outchars[5];

  if (note->scale==1)
  { fprintf(out,"+"); }
    else
  if (note->scale>=2)
  { fprintf(out,"++"); }

  if (note->tone==0) strcpy(outchars,"P");
    else
  if (note->tone==1) strcpy(outchars,"C");
    else
  if (note->tone==2) strcpy(outchars,"C#");
    else
  if (note->tone==3) strcpy(outchars,"D");
    else
  if (note->tone==4) strcpy(outchars,"D#");
    else
  if (note->tone==5) strcpy(outchars,"E");
    else
  if (note->tone==6) strcpy(outchars,"F");
    else
  if (note->tone==7) strcpy(outchars,"F#");
    else
  if (note->tone==8) strcpy(outchars,"G");
    else
  if (note->tone==9) strcpy(outchars,"G#");
    else
  if (note->tone==10) strcpy(outchars,"A");
    else
  if (note->tone==11) strcpy(outchars,"A#");
    else
  if (note->tone==12) strcpy(outchars,"B");
    else
  { strcpy(outchars,"C"); }

  if (note->length>=3) outchars[0]=tolower(outchars[0]);

  if (note->modifier>0) strcat(outchars,".");

  fprintf(out,"%s",outchars);
}

void write_emelody_footer(FILE *out, struct note_t *note)
{

}


