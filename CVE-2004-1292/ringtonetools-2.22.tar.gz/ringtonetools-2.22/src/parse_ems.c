#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

int parse_ems(FILE *in, FILE *out, int out_type, struct note_t *note)
{
unsigned char buffer[8192];
int s,t,ch,c,ptr,k;

  ptr=0;
  t=0; c=0;
  while((ch=getc(in))!=EOF)
  {
    ch=tolower(ch);
    if ((ch>='0' && ch<='9') || (ch>='a' && ch<='f')) 
    {
      if (ch>='0' && ch<='9')
      { t=(t<<4)+(ch-'0'); }
        else
      { t=(t<<4)+(ch-'a')+10; }
      c++;

      if ((c%2)==0)
      {
        buffer[ptr++]=t;
        t=0;
      }
    }
  }

  s=4;
  if (buffer[1]==0x11)
  {
    note->width=16;
    note->height=16;
  }
    else
  if (buffer[1]==0x10)
  {
    note->width=32;
    note->height=32;
  }
    else
  if (buffer[1]==0x12)
  {
    note->width=buffer[4];
    note->height=buffer[5];
    s=s+2;
  }
    else
  {
    printf("Unknown or unsupported EMS type\n");
    return 1;
  }

  logo_header_route(out,note,out_type);

  k=0;
  for (c=s; c<ptr; c++)
  {
    /* ring_stack[stackptr++]=buffer[t]; */
    for (t=7; t>=0; t--)
    {
      if (((buffer[c]>>t)&1)==0)
      { note->picture[k++]=0; }
        else
      { note->picture[k++]=0xffffff; }
    }
  }

  logo_footer_route(out,note,out_type);

  return (0);
}



