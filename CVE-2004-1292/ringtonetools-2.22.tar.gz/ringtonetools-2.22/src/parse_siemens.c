#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

int getnext(FILE *in)
{
int ch;

  while(1)
  {
    ch=getc(in);

    if (ch==' ' || ch=='\t' || ch=='\n' || ch=='\r')
    { continue; }
      else
    { return tolower(ch); }
  }

  return 0;
}

int parse_siemens(FILE *in, FILE *out, int out_type, struct note_t *note)
{
char token[16];
int t,ch,ptr;

  check_songname(in,note->songname);

#ifdef DEBUG
  printf("\n       Song Name: %s\n",note->songname);
#endif

  header_route(out,note,7,out_type);
  note->modifier=0;

  while(1)
  {
    note->tone=-1;
    note->scale=0;
    note->length=2;

    ch=getnext(in);
    if (ch==EOF) break;

    if (ch=='p') note->tone=0;
      else
    if (ch=='c') note->tone=1;
      else
    if (ch=='d') note->tone=3;
      else
    if (ch=='e') note->tone=5;
      else
    if (ch=='f') note->tone=6;
      else
    if (ch=='g') note->tone=8;
      else
    if (ch=='a') note->tone=10;
      else
    if (ch=='b' || ch=='h') note->tone=12;

    ch=getnext(in);
    if (note->tone!=0)
    {
      if (ch==EOF) break;

      if (ch=='i')
      {
        ch=getnext(in);
        if (ch==EOF) break;
        if (ch!='s') printf("Error:  expecting 's'\n"); 
        note->tone++;

        ch=getnext(in);
        if (ch==EOF) break;
      }

      if (ch>='0' && ch<='9')
      {
        note->scale=(ch-'0');
        ch=getnext(in);
        if (ch==EOF) break;
      }
        else
      { note->scale=0; }
    }

    if (ch=='(')
    {
      ptr=0;

      while(1)
      {
        ch=getnext(in);
        if (ch==EOF) break;
        if (ch=='/' || ch==')') break;
      }
      if (ch==EOF) break;

      ptr=0;
      while(1)
      {
        ch=getnext(in);
        if (ch==EOF) break;
        if (ch==')') break;
        if (ch>='0' && ch<='9') token[ptr++]=ch;
        if (ptr>2) break;
      }
      token[ptr]=0;

      t=atoi(token);
      if (t>32) t=32;

      if (t==1) note->length=0;
        else
      if (t==2) note->length=1;
        else
      if (t==4) note->length=2;
        else
      if (t==8) note->length=3;
        else
      if (t==16) note->length=4;
        else
      if (t==32) note->length=5;

      if (ch==EOF) break;
    }
      else
    {
      ungetc(ch,in);
    }

    note_route(out,note,7,out_type);
  }

  if (note->tone!=-1) note_route(out,note,0,out_type);

  footer_route(out,note,7,out_type);

  return (0);
}



