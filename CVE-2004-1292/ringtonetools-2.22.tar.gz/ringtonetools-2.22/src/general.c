#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

short int ring_stack[RINGSTACK_SIZE];
int stackptr;
int bitptr;

int reverse_tempo(int l)
{
short int tempo_code[32]={ 25,28,31,35,40,45,50,56,63,70,80,90,100,
                           112,125,140,160,180,200,225,250,285,320,
                           355,400,450,500,565,635,715,800,900 };

  return tempo_code[l];
}

int get_tempo(int tempo)
{
int t;
short int tempo_code[32]={ 25,28,31,35,40,45,50,56,63,70,80,90,100,
                           112,125,140,160,180,200,225,250,285,320,
                           355,400,450,500,565,635,715,800,900 };

  if (tempo>900) tempo=900;

  for (t=0; t<30; t++)
  {
    if (tempo_code[t]==tempo) return t;
    if (tempo_code[t]<tempo && tempo_code[t+1]>tempo)
    {
      if (tempo-tempo_code[t]<tempo_code[t+1]-tempo)
      { return t; }
        else
      { return t+1; }
    }
  }

  return t;
}

void push(int data, int size)
{
int d,t;

  d=data;
/*
#ifdef DEBUG
printf("%d: ",stackptr);
#endif
*/

  for (t=size-1; t>=0; t--)
  {
    d=(data>>t)&1;
/*
#ifdef DEBUG
printf("%d",d);
#endif
*/

    ring_stack[stackptr]&=255-(1<<bitptr);
    ring_stack[stackptr]+=(d<<bitptr);

    bitptr--;

    if (bitptr==-1)
    {
      bitptr=7;
      stackptr++;
      ring_stack[stackptr]=0;
    }
  }

/*
#ifdef DEBUG
printf("\n");
#endif
*/
}

void push_addr(int data, int size, int stackptr, int bitptr)
{
int d,t;

  d=data;

  for (t=size-1; t>=0; t--)
  {
    d=(data>>t)&1;
    ring_stack[stackptr]&=255-(1<<bitptr);
    ring_stack[stackptr]+=(d<<bitptr);

    bitptr--;

    if (bitptr==-1)
    {
      bitptr=7;
      stackptr++;
    }
  }
}

void write_codes(FILE *out, char *port)
{
int t;
int count,part,total_parts;
int sms_size;

  if (headers==1)
  { 
    if (((stackptr*2)+strlen("//SCKL1581 "))<=full_sms_size)
    {
      count=strlen("//SCKL1581 ");
      full_sms_size=1000;
      headers=5;
    }
     else
    { count=strlen("//SCKL15810000010101 "); }
  }
    else
  if (headers==2)
  { count=strlen("//SCKL1582 0B0504158200000003010202"); }
    else
  if (headers==3)
  { 
    if (((stackptr*2)+14)<=full_sms_size)
    {
      count=strlen("06050415830000");
      headers=4;
    }
      else
    { count=strlen("0B0504158200000003010202"); }
  }
    else
  { count=0; }


  sms_size=(full_sms_size-count)/2;

#ifdef DEBUG
printf("sms_size=%d\n",sms_size);
#endif

  count=1000;
  part=1;
  total_parts=(stackptr/sms_size)+1;
  if ((stackptr%sms_size)==0) total_parts--;

  for (t=0; t<stackptr; t++)
  {
    if (count>=sms_size)
    {
      /* GIMME HEADers */

      if (part!=1) fprintf(out,"\n\n");

      if (headers==1)
      {
        fprintf(out,"//SCKL%s000001%02X%02X ",port,total_parts,part);
      }
        else
      if (headers==2)
      {
        fprintf(out,"//SCKL%s 0B0504%s0000000301%02X%02X",port,port,total_parts,part);
      }
        else
      if (headers==3)
      {
        fprintf(out,"0B0504%s0000000301%02X%02X",port,total_parts,part);
      }
        else
      if (headers==4)
      {
        fprintf(out,"060504%s0000",port);
      }
        else
      if (headers==5)
      {
        fprintf(out,"//SCKL%s ",port);
      }

      count=0;
      part++;
    }

    fprintf(out,"%02X",ring_stack[t]); 
    count++;
  }

  fprintf(out,"\n\n");

  if (total_parts>3)
  {
    printf("\nWarning: Song exceeds 3 SMS messages.  This might cause a problem.\n");
  }
}

void check_songname(FILE *in, char *songname)
{
char buffer[1024];
int ch,ptr;

  ptr=0;
  while (1)
  {
    ch=getc(in);
    if (ch==EOF || ptr==1023)
    {
      ptr=0;
      fseek(in,0,SEEK_SET);
      break;
    }

    if (ch==':')
    { break; }

    buffer[ptr++]=ch;
  }

  buffer[ptr]=0;

  if (songname[0]==0) strncpy(songname,buffer,SONGNAME_LEN);
  songname[SONGNAME_LEN-1]=0;
}

int convcolor(char *s)
{
int t,c,b;

  if (s[0]!='0' || s[1]!='x' || strlen(s)!=8)
  {
    printf("\n%s is an invalid color. Colors are made by the format of \n"
           "0xrrggbb where rr,gg,bb are replaced with a hex number\n"
           "representing the color you want to use.  For example 0x000000\n"
           "would be black and 0xffffff would be white.\n\n",s);
    exit(0);
    return -1;
  }

  c=0;
  b=20;

  for (t=2; t<8; t++)
  {
    if (s[t]>='0' && s[t]<='9')
    { c=c+((s[t]-'0')<<b); }
      else
    if (tolower(s[t])>='a' && tolower(s[t])<='f')
    { c=c+((s[t]-'a'+10)<<b); }

    b=b-4;
  } 

  return c;
}



