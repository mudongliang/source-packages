#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

int get_next(FILE *in)
{
int ch;

  while(1)
  {
    ch=getc(in);

    if (ch==' ' || ch=='\t')
    { continue; }
      else
    if (ch=='\n' || ch=='\r')
    {
      ch=getc(in);
      if (ch!='\r' && ch!='\n') ungetc(ch,in);
      return '\n';
    }
      else
    if (ch==EOF)
    { return EOF; }
      else
    { return tolower(ch); }
  }

  return 0;
}

int get_field(FILE *in, char *field_name, char *field_value)
{
int ch,ptr,p;
char *buffer;
int marker;

  buffer=field_name;
  marker=ftell(in);

  field_name[0]=0;
  field_value[0]=0;

  ptr=0; p=0;
  while(1)
  {
    ch=getc(in);

    if (ptr==0 && p==0)
    {
      if (ch=='\r' || ch=='\n') continue;
      if (ch==EOF) return -1;
    }

    if (ch==':' && p==0)
    {
      buffer[ptr]=0;
      if (strcasecmp(buffer,"melody")==0) return 2;

      buffer=field_value;
      ptr=0;
      p++;
      continue;
    }

    if (ch=='\n' || ch=='\r' || ch==EOF || ptr==1023)
    {
      if (p==0)
      {
        fseek(in,marker,SEEK_SET);
        return 1;
      }

      buffer[ptr]=0;
      return 0;
    }

    buffer[ptr++]=ch;
  }

  return 0;
}

int parse_num(FILE *in)
{
int ch,i;

  i=0;

  while(1)
  {
    ch=getc(in);
    if (ch>='0' && ch<='9')
    {
      i=(i*10)+(ch-'0');
    }
      else
    { ungetc(ch,in); return i; }
  }
}

void parse_melody(FILE *in, FILE *out, struct note_t *note, int out_type)
{
int ch,t;
int tone_modifier;
int repeat,repeat_count=0;
unsigned char default_octave;
char token[255];

  default_octave=4;
  tone_modifier=0;
  repeat=ftell(in);

  header_route(out,note,1,out_type);

  while(1)
  {
    ch=get_next(in);
    if (ch==EOF || ch=='\n') break;

    if (ch=='*')
    {
      ch=get_next(in);
      if (ch==EOF || ch=='\n') break;

      default_octave=ch-'0';
      if (default_octave>8) default_octave=4;
      continue;
    }

    if (ch=='{')
    {
      repeat=ftell(in);

      continue;
    }

    if (ch=='}')
    {
      ch=get_next(in);
      if (ch==EOF || ch=='\n') break;
      if (ch=='@')
      {
        gettoken(in,token,2);
        t=atoi(token);
#ifdef DEBUG
        printf("%d\n",t);
#endif
        if (repeat_count<t)
        { fseek(in,repeat,SEEK_SET); }

        repeat_count++;

        continue;
      }

      break;
    }

    if (ch=='v')
    {
      ch=get_next(in);
      if (ch==EOF || ch=='\n') break;

      if (ch=='-') { note->volume--; }
        else
      if (ch=='+') { note->volume++; }
        else
      if (ch>='0' && ch<='9') note->volume=parse_num(in);

      if (note->volume<0) note->volume=0;
        else
      if (note->volume>15) note->volume=15;

      volume_route(out,note,1,out_type);

      continue;
    }

    if (ch=='#')
    {
      tone_modifier=1;
      continue;
    }

    if (ch=='&')
    {
      tone_modifier=-1;
      continue;
    }

    if (ch=='a') note->tone=10;
      else
    if (ch=='h' || ch=='b') note->tone=12;
      else
    if (ch=='c') note->tone=1;
      else
    if (ch=='d') note->tone=3;
      else
    if (ch=='e') note->tone=5;
      else
    if (ch=='f') note->tone=6;
      else
    if (ch=='g') note->tone=8;
      else
    if (ch=='p' || ch=='r') note->tone=0;

    note->tone=note->tone+tone_modifier;
    if (note->tone<1 && ch!='r' && ch!='p')
    {
      note->tone=12;
      note->scale--;
    }
      else
    if (note->tone>12)
    {
      note->tone=1;
      note->scale++;
    }

    ch=get_next(in);
    /* if (ch==EOF || ch=='\n') break; */

    note->length=2;
    if (ch>='0' && ch<='5')
    {
      note->length=ch-'0';
      ch=get_next(in);
    }

    if (ch=='.') note->modifier=1;
      else
    if (ch==':') note->modifier=2;
      else
    if (ch==';') note->modifier=3;
      else
    {
      ungetc(ch,in);
      note->modifier=0;
    }

    note->scale=default_octave-3;
    if (note->scale<0) note->scale=0;

    note_route(out,note,1,out_type);

    if (ch==EOF || ch=='\n') break;

    tone_modifier=0;
  }

  footer_route(out,note,1,out_type);
}

int parse_imelody(FILE *in, FILE *out, int out_type, struct note_t *note)
{
char field_name[1024],field_value[1024];
int i;

  note->bpm=120;

  while(1)
  {
    i=get_field(in,field_name,field_value);

    if (i==1 || i==2)
    {
      parse_melody(in,out,note,out_type);
      break;
    }
      else
    if (i==-1)
    { break; }

    if (strcasecmp(field_name,"name")==0)
    {
      strncpy(note->songname,field_value,SONGNAME_LEN);
      note->songname[SONGNAME_LEN-1]=0;
    }
      else
    if (strcasecmp(field_name,"beat")==0)
    {
      note->bpm=atoi(field_value);
      if (note->bpm==0) note->bpm=120;
    }
      else
    if (strcasecmp(field_name,"volume")==0)
    {
      note->volume=atoi(field_value);
      if (note->volume<=0 || note->volume>15) note->volume=7;
    }
      else
    if (strcasecmp(field_name,"style")==0 && strlen(field_value)==2)
    {
      note->style=field_value[1]-'0';
      if (note->style<0 || note->style>2) note->style=0;
    }
  }

  return (0);
}



