#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* Samsung Older Models */

void write_samsung_header(FILE *out, struct note_t *note)
{
  note->bytes=0;
}

void write_samsung1_note(FILE *out, struct note_t *note)
{
char outchars[20];

  outchars[0]=0;

  if (note->tone==0) strcpy(outchars,"0");
    else
  if (note->tone==1) strcpy(outchars,"1");
    else
  if (note->tone==2) strcpy(outchars,"1#");
    else
  if (note->tone==3) strcpy(outchars,"2");
    else
  if (note->tone==4) strcpy(outchars,"2#");
    else
  if (note->tone==5) strcpy(outchars,"3");
    else
  if (note->tone==6) strcpy(outchars,"4");
    else
  if (note->tone==7) strcpy(outchars,"4#");
    else
  if (note->tone==8) strcpy(outchars,"5");
    else
  if (note->tone==9) strcpy(outchars,"5#");
    else
  if (note->tone==10) strcpy(outchars,"6");
    else
  if (note->tone==11) strcpy(outchars,"6#");
    else
  if (note->tone==12) strcpy(outchars,"7");
    else
  { strcpy(outchars,"0"); }

  if (note->tone!=0)
  {
    if (note->transpose==-1)
    {
      if (note->scale==0) strcat(outchars,"88");
        else
      if (note->scale==2) strcat(outchars,"8");
    }
      else
    {
      if (note->scale==1) strcat(outchars,"8");
    }
  }

  if (note->length==0) strcat(outchars,"**");
    else
  if (note->length==1) strcat(outchars,"*");
    else
  if (note->length==3) strcat(outchars,"****");
    else
  if (note->length==4) strcat(outchars,"***");
    else
  if (note->length==5) strcat(outchars,"***");

  if (note->modifier!=0)
  {
    if (note->length==0) strcat(outchars," 0*");
      else
    if (note->length==1) strcat(outchars," 0");
      else
    if (note->length==2) strcat(outchars," 0****");
      else
    if (note->length==3) strcat(outchars," 0***");
      else
    if (note->length==4) strcat(outchars," 0***");
      else
    if (note->length==5) strcat(outchars," 0***");
  }

  strcat(outchars," ");
  fprintf(out,"%s",outchars);

  note->bytes=note->bytes+strlen(outchars);

  if (note->bytes>70)
  {
    fprintf(out,"\n");
    note->bytes=0;
  }
}

void write_samsung2_note(FILE *out, struct note_t *note)
{
char outchars[20];

  outchars[0]=0;

  if (note->tone==1) strcpy(outchars,"1");
    else
  if (note->tone==2) strcpy(outchars,"1^");
    else
  if (note->tone==3) strcpy(outchars,"2");
    else
  if (note->tone==4) strcpy(outchars,"2^");
    else
  if (note->tone==5) strcpy(outchars,"3");
    else
  if (note->tone==6) strcpy(outchars,"4");
    else
  if (note->tone==7) strcpy(outchars,"4^");
    else
  if (note->tone==8) strcpy(outchars,"5");
    else
  if (note->tone==9) strcpy(outchars,"5^");
    else
  if (note->tone==10) strcpy(outchars,"6");
    else
  if (note->tone==11) strcpy(outchars,"6^");
    else
  if (note->tone==12) strcpy(outchars,"7");
    else
  if (note->tone!=0)
  { strcpy(outchars,"1"); note->tone=1; }

  if (note->tone!=0)
  {
    if (note->transpose==-1)
    {
      if (note->scale==0) strcat(outchars,"88");
        else
      if (note->scale==2) strcat(outchars,"8");
    }
      else
    {
      if (note->scale==1) strcat(outchars,"8");
    }

    if (note->length==0) strcat(outchars,"<<<<");
      else
    if (note->length==1) strcat(outchars,"<<<");
      else
    if (note->length==3) strcat(outchars,"<");
      else
    if (note->length==4) strcat(outchars,"<<");
      else
    if (note->length==5) strcat(outchars,"<<");

    if (note->modifier!=0)
    {
      if (note->length==0) strcat(outchars," >>>");
        else
      if (note->length==1) strcat(outchars," 0");
        else
      if (note->length==2) strcat(outchars," >");
        else
      if (note->length==3) strcat(outchars," >>");
        else
      if (note->length==4) strcat(outchars," >>");
        else
      if (note->length==5) strcat(outchars," >>");
    }
  }
    else
  {
    if (note->length==0) strcat(outchars,">>>>");
      else
    if (note->length==1) strcat(outchars,">>>");
      else
    if (note->length==2) strcat(outchars,"0");
      else
    if (note->length==3) strcat(outchars,">");
      else
    if (note->length==4) strcat(outchars,">>");
      else
    if (note->length==5) strcat(outchars,">>");
  }
  strcat(outchars," ");
  fprintf(out,"%s",outchars);

  note->bytes=note->bytes+strlen(outchars);

  if (note->bytes>70)
  {
    fprintf(out,"\n");
    note->bytes=0;
  }
}

void write_samsung_footer(FILE *out, struct note_t *note)
{
  fprintf(out,"\n");
}


