#include <stdio.h>
#include <stdlib.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* Kyocera KWS */

void write_kws_header(FILE *out, struct note_t *note)
{

}

void write_kws_note(FILE *out, struct note_t *note)
{
int d,a,b;

  ring_stack[stackptr++]=note->tone+(note->scale*12);

  if (note->tone!=0)
  { ring_stack[stackptr++]=0x04; }
    else
  { ring_stack[stackptr++]=0x00; }

  d=(int)(((float)60000/(float)note->bpm)*(float)((float)4/(float)(1<<note->length)));

  if (note->modifier==1)
  { d=d+(d/2); }
    else
  if (note->modifier==2)
  { d=d+(d/2)+(d/4); }

  a=d&255;
  b=(d>>8)&255;

  a=a^(b<<1);

  ring_stack[stackptr++]=a;
  ring_stack[stackptr++]=b;
}

void write_kws_footer(FILE *out, struct note_t *note)
{
int data_length;
int a,b,d;

  if (note->pause!=0)
  {
    ring_stack[stackptr++]=0;
    ring_stack[stackptr++]=0;

    d=(int)(((float)60000/(float)note->bpm)*(float)((float)4/(float)(1<<2)));
    d=d*note->pause;

    a=d&255;
    b=(d>>8)&255;

    a=a^(b<<1);

    ring_stack[stackptr++]=a;
    ring_stack[stackptr++]=b;

    note->note_count++;
  }

  data_length=stackptr+10;
  write_long(out,(data_length^0xffffffff));
  write_word(out,note->note_count);

  for (d=0; d<stackptr; d++) putc(ring_stack[d],out);

  write_long(out,(data_length^0xffffffff));
}



