#include <stdio.h>
#include <stdlib.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* Motorola */

void write_mot_header(FILE *out, struct note_t *note)
{
char outchars[10];
int tempo;

  tempo=3;
  sprintf(outchars,"L35&%d ",tempo);
  write_chars(out,outchars);

  note->mcc=0;
}

void write_mot_note(FILE *out, struct note_t *note)
{
char outnote[10];
char notes[]={ 'R','C','C','D','D','E','F','F','G','G','A','A','B' };
char flats[]={  0 , 0,  1,  0,  1, -1,  0,  1,  0,  1,  0,  1, -1  };
char flmap[]={  0 , 1,  1,  2,  2, -1,  4,  4,  8,  8, 16, 16, -1  };
int t,d;

  t=0;

  if (note->note_count<35)
  {
    outnote[t++]=notes[note->tone];
    if (flats[note->tone]!=-1)
    {
      if (((note->flats&flmap[note->tone])==0 && flats[note->tone]==1) ||
          ((note->flats&flmap[note->tone])!=0 && flats[note->tone]==0))
      {
        outnote[t++]='#';
        note->flats^=flmap[note->tone];
      }
    }

    if (note->scale!=0)
    { outnote[t++]='+'; }

    d=5-note->length;
    outnote[t++]=d+'0';

    outnote[t]=0;

#ifdef DEBUG
printf("%s",outnote);
#endif

    fprintf(out,"%s",outnote);
    for (d=0; d<t; d++) note->mcc=note->mcc^outnote[d];
  }
}

void write_mot_footer(FILE *out, struct note_t *note)
{
char outchars[20];

  sprintf(outchars,"&&%c%c",((note->mcc>>4)+0x30),((note->mcc&15)+0x30));
  write_chars(out,outchars);

  if (note->note_count>35)
  {
    if (quiet==0)
    {
      printf("Warning: Motorola's format only supports 35 notes.\n");
      printf("         This song has been truncated.\n");
    }
  }
}

void write_mot_key_header(FILE *out, struct note_t *note)
{
  if (note->songname[0]!=0)
  {
#ifdef DEBUG
    fprintf(out,"%s:",note->songname);
#endif
  }
}

void write_mot_key_note(FILE *out, struct note_t *note)
{
  if (note->note_count!=0) fprintf(out," ");

  if (note->tone!=0)
  {
    if (note->scale==0)
    { fprintf(out,"1"); }
      else
    if (note->scale==1)
    { fprintf(out,"11"); }
      else
    { fprintf(out,"111"); }
  }

  if (note->tone==0) fprintf(out,"44");
    else
  if (note->tone==1) fprintf(out,"222");
    else
  if (note->tone==2) fprintf(out,"2227");
    else
  if (note->tone==3) fprintf(out,"3");
    else
  if (note->tone==4) fprintf(out,"37");
    else
  if (note->tone==5) fprintf(out,"33");
    else
  if (note->tone==6) fprintf(out,"333");
    else
  if (note->tone==7) fprintf(out,"3337");
    else
  if (note->tone==8) fprintf(out,"4");
    else
  if (note->tone==9) fprintf(out,"47");
    else
  if (note->tone==10) fprintf(out,"2");
    else
  if (note->tone==11) fprintf(out,"27");
    else
  if (note->tone==12) fprintf(out,"22");

  if (note->length<2) fprintf(out,"w");
    else
  if (note->length==2) fprintf(out,"h");
    else
  { fprintf(out,"q"); }
}

void write_mot_key_footer(FILE *out, struct note_t *note)
{

}


