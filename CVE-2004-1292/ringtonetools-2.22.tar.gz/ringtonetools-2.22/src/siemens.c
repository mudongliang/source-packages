#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* Samsung Older Models */

void write_siemens_header(FILE *out, struct note_t *note)
{
  note->bytes=0;
}

void write_siemens_note(FILE *out, struct note_t *note)
{
char outchars[20];
char temp[20];

  outchars[0]=0;

  if (note->tone==0) strcpy(outchars,"P");
    else
  if (note->tone==1) strcpy(outchars,"C");
    else
  if (note->tone==2) strcpy(outchars,"Cis");
    else
  if (note->tone==3) strcpy(outchars,"D");
    else
  if (note->tone==4) strcpy(outchars,"Dis");
    else
  if (note->tone==5) strcpy(outchars,"E");
    else
  if (note->tone==6) strcpy(outchars,"F");
    else
  if (note->tone==7) strcpy(outchars,"Fis");
    else
  if (note->tone==8) strcpy(outchars,"G");
    else
  if (note->tone==9) strcpy(outchars,"Gis");
    else
  if (note->tone==10) strcpy(outchars,"A");
    else
  if (note->tone==11) strcpy(outchars,"Ais");
    else
  if (note->tone==12) strcpy(outchars,"H");
    else
  { strcpy(outchars,"0"); }

  if (note->tone!=0)
  {
    sprintf(temp,"%d",(note->scale+1));
    strcat(outchars,temp);
  }

  sprintf(temp,"(1/%d) ",1<<note->length);
  strcat(outchars,temp);

  fprintf(out,"%s",outchars);

  note->bytes=note->bytes+strlen(outchars);

  if (note->bytes>70)
  {
    fprintf(out,"\n");
    note->bytes=0;
  }
}

void write_siemens_footer(FILE *out, struct note_t *note)
{
  fprintf(out,"\n");
}


