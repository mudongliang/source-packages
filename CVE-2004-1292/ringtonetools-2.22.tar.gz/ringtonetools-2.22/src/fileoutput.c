#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

int write_long(FILE *out, int n)
{
  putc((n&255),out);
  putc(((n>>8)&255),out);
  putc(((n>>16)&255),out);
  putc(((n>>24)&255),out);

  return 0;
}

int write_word(FILE *out, int n)
{
  putc((n&255),out);
  putc(((n>>8)&255),out);

  return 0;
}

int read_long(FILE *in)
{
int c;

  c=getc(in);
  c=c+(getc(in)<<8);
  c=c+(getc(in)<<16);
  c=c+(getc(in)<<24);

  return c;
}

int read_word(FILE *in)
{
int c;

  c=getc(in);
  c=c+(getc(in)<<8);

  return c;
}

int write_long_b(FILE *out, int n)
{
  putc(((n>>24)&255),out);
  putc(((n>>16)&255),out);
  putc(((n>>8)&255),out);
  putc((n&255),out);

  return 0;
}

int write_word_b(FILE *out, int n)
{
  putc(((n>>8)&255),out);
  putc((n&255),out);

  return 0;
}

int read_long_b(FILE *in)
{
int c;

  c=getc(in);
  c=(c<<8)+getc(in);
  c=(c<<8)+getc(in);
  c=(c<<8)+getc(in);

  return c;
}

int read_word_b(FILE *in)
{
int c;

  c=getc(in);
  c=(c<<8)+getc(in);

  return c;
}

int read_chars(FILE *in, char *s, int count)
{
int t;

  for (t=0; t<count; t++)
  {
    s[t]=getc(in);
  }

  s[t]=0;

  return 0;
}

int write_chars(FILE *out, char *s)
{
int t;

  t=0;
  while(s[t]!=0 && t<255)
  {
    putc(s[t++],out);
  }

  return 0;
}

/* Routing */

int header_route(FILE *out, struct note_t *note, int in_type, int out_type)
{
  if (out_type==0)
  { write_wav_header(out,note); }
    else
  if (out_type==1)
  { write_kws_header(out,note); }
    else
  if (out_type==2)
  { write_mot_header(out,note); }
    else
  if (out_type==4)
  { write_nokia_header(out,note); }
    else
  if (out_type==5)
  { write_rtttl_header(out,note); }
    else
  if (out_type==6 || out_type==7)
  { write_samsung_header(out,note); }
    else
  if (out_type==8)
  { write_midi_header(out,note); }
    else
  if (out_type==9)
  { write_siemens_header(out,note); }
    else
  if (out_type==10)
  { write_mot_key_header(out,note); }
    else
  if (out_type==11)
  { write_emelody_header(out,note); }
    else
  if (out_type==12)
  { write_imelody_header(out,note); }
    else
  if (out_type==15)
  { write_3210_header(out,note); }
#ifdef DSP
    else
  if (out_type==19)
  { write_dsp_header(out,note); }
#endif

  return 0;
}

int note_route(FILE *out, struct note_t *note, int in_type, int out_type)
{
  if (out_type==0)
  { write_wav_note(out,note); }
    else
  if (out_type==1)
  { write_kws_note(out,note); }
    else
  if (out_type==2)
  { write_mot_note(out,note); }
    else
  if (out_type==4)
  { write_nokia_note(out,note); }
    else
  if (out_type==5)
  { write_rtttl_note(out,note); }
    else
  if (out_type==6)
  { write_samsung1_note(out,note); }
    else
  if (out_type==7)
  { write_samsung2_note(out,note); }
    else
  if (out_type==8)
  { write_midi_note(out,note); }
    else
  if (out_type==9)
  { write_siemens_note(out,note); }
    else
  if (out_type==10)
  { write_mot_key_note(out,note); }
    else
  if (out_type==11)
  { write_emelody_note(out,note); }
    else
  if (out_type==12)
  { write_imelody_note(out,note); }
    else
  if (out_type==15)
  { write_3210_note(out,note); }
#ifdef DSP
    else
  if (out_type==19)
  { write_dsp_note(out,note); }
#endif

  note->note_count++;

  return 0;
}

int footer_route(FILE *out, struct note_t *note, int in_type, int out_type)
{
  if (out_type==0)
  { write_wav_footer(out,note); }
    else
  if (out_type==1)
  { write_kws_footer(out,note); }
    else
  if (out_type==2)
  { write_mot_footer(out,note); }
    else
  if (out_type==4)
  { write_nokia_footer(out,note); }
    else
  if (out_type==5)
  { write_rtttl_footer(out,note); }
    else
  if (out_type==6 || out_type==7)
  { write_samsung_footer(out,note); }
    else
  if (out_type==8)
  { write_midi_footer(out,note); }
    else
  if (out_type==9)
  { write_siemens_footer(out,note); }
    else
  if (out_type==10)
  { write_mot_key_footer(out,note); }
    else
  if (out_type==11)
  { write_emelody_footer(out,note); }
    else
  if (out_type==12)
  { write_imelody_footer(out,note); }
    else
  if (out_type==15)
  { write_3210_footer(out,note); }
#ifdef DSP
    else
  if (out_type==19)
  { write_dsp_footer(out,note); }
#endif

  return 0;
}

int logo_header_route(FILE *out, struct note_t *note, int out_type)
{
  if (note->width>MAX_WIDTH || note->height>MAX_HEIGHT)
  {
    printf("Logos are limited to %d x %d.  Image is too big.\n",MAX_WIDTH,MAX_HEIGHT);
    return -1;
  }

  note->picture=malloc(note->width*note->height*sizeof(int));
  memset(note->picture,0,note->width*note->height*sizeof(int));

  if (out_type==4) write_nokia_logo_header(out,note);
    else
  if (out_type==14) write_ems_logo_header(out,note);
    else
  if (out_type==17) write_bmp_header(out,note);
    else
  if (out_type==18) { }
    else
  if (out_type==20 || out_type==21) write_ngg_logo_header(out,note);
    else
  if (out_type==22) write_wbmp_header(out,note);
    else
  if (out_type==23) write_icon_header(out,note);
    else
  if (out_type==24) write_gif_header(out,note);
    else
  { 
    printf("This file cannot be converted to this output file type\n");
    return -1;
  }

  return 0;
}

int logo_footer_route(FILE *out, struct note_t *note, int out_type)
{
int f,u,c;

  if ((note->bmp_flags&1)==1)
  {
    f=note->width*note->height;

    for(u=0; u<f; u++)
    {
      c=note->picture[u];
      c=(255-(c&255))+((255-((c>>8)&255))<<8)+((255-((c>>16)&255))<<16);
      note->picture[u]=c;
    }
  }

#ifdef DEBUG
debug_logo(note);
#endif

  if (out_type==4) write_nokia_logo_footer(out,note);
    else
  if (out_type==14) write_ems_logo_footer(out,note);
    else
  if (out_type==17) write_bmp_footer(out,note);
    else
  if (out_type==18) write_text_footer(out,note);
    else
  if (out_type==20 || out_type==21) write_ngg_logo_footer(out,note);
    else
  if (out_type==22) write_wbmp_footer(out,note);
    else
  if (out_type==23) write_icon_footer(out,note);
    else
  if (out_type==24) write_gif_footer(out,note);

  free(note->picture);

  return 0;
}

int tempo_route(FILE *out, struct note_t *note, int in_type, int out_type)
{
  if (out_type==4)
  { write_nokia_bpm(out,note); }
    else
  if (out_type==8)
  { write_midi_bpm(out,note); }
    else
  if (out_type==5 && note->channels==1)
  { write_rtx_bpm(out,note); }

  return 0;
}

int volume_route(FILE *out, struct note_t *note, int in_type, int out_type)
{
  if (out_type==4)
  { write_nokia_volume(out,note); }

  return 0;
}



