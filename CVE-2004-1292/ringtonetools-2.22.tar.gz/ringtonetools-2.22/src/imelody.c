#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "general.h"
#include "fileoutput.h"

/*

Ringtone Tools - Copyright 2001-2004 Michael Kohn (mike@mikekohn.net)
This falls under the Kohnian license.  Please read
it at http://ringtonetools.mikekohn.net/

This program is NOT opensourced.  You may not use any part
of this program for your own software.

*/

/* iMelody for newer Ericsson, Motorola, Siemens and others */

void write_imelody_header(FILE *out, struct note_t *note)
{
char header[2048];
char temp[128];

  header[0]=0;

  if (headers>=2)
  {
    strcat(header,"BEGIN:IMELODY\r\n");
  }

  if (headers>=5)
  {
    strcat(header,"VERSION:1.0\r\n");
    strcat(header,"FORMAT:CLASS 1.0\r\n");
  }

  if (headers>=3)
  {
    sprintf(temp,"NAME:%s\r\n",note->songname);
    strcat(header,temp);
    sprintf(temp,"BEAT:%d\r\n",note->bpm);
    strcat(header,temp);
  }

  if (headers>=4)
  {
    sprintf(temp,"STYLE:S%d\r\n",note->style);
    strcat(header,temp);
  }

  if (headers>=1)
  {
    strcat(header,"MELODY:");
  }

  if (note->ems==0)
  { fprintf(out,header); }
    else
  {
    write_ems(header);
  }

  note->prev_scale=1;
}

void write_imelody_note(FILE *out, struct note_t *note)
{
char outchars[16];
char temp[16];

  outchars[0]=0;

  /* if (note->prev_scale!=note->scale) */

  if (note->tone!=0)
  {
    sprintf(outchars,"*%d",note->scale+3);
    note->prev_scale=note->scale;
  }

  if (note->tone==0) strcat(outchars,"r");
    else
  if (note->tone==1) strcat(outchars,"c");
    else
  if (note->tone==2) strcat(outchars,"#c");
    else
  if (note->tone==3) strcat(outchars,"d");
    else
  if (note->tone==4) strcat(outchars,"#d");
    else
  if (note->tone==5) strcat(outchars,"e");
    else
  if (note->tone==6) strcat(outchars,"f");
    else
  if (note->tone==7) strcat(outchars,"#f");
    else
  if (note->tone==8) strcat(outchars,"g");
    else
  if (note->tone==9) strcat(outchars,"#g");
    else
  if (note->tone==10) strcat(outchars,"a");
    else
  if (note->tone==11) strcat(outchars,"#a");
    else
  if (note->tone==12) strcat(outchars,"b");
    else
  { strcat(outchars,"c"); }

  if (note->length<6)
  { sprintf(temp,"%d",note->length); }
    else
  { sprintf(temp,"5"); }
  strcat(outchars,temp);

  if (note->modifier==1) strcat(outchars,".");
    else
  if (note->modifier==2) strcat(outchars,":");
    else
  if (note->modifier==3) strcat(outchars,";");

  if (note->ems==0)
  { fprintf(out,"%s",outchars); }
    else
  { write_ems(outchars); }
}

void write_imelody_footer(FILE *out, struct note_t *note)
{
char header[64];

  header[0]=0;

  strcat(header,"\r\n");

  if (headers>=2)
  {
    strcat(header,"END:IMELODY\r\n");
  }

  if (note->ems==0)
  { fprintf(out,"%s",header); }
    else
  {
    write_ems(header);
    write_ems_footer(out,note);
  }
}


