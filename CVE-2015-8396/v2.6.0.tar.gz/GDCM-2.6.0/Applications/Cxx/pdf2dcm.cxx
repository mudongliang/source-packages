/*
Provide a mapping for:

Title:          ITK Software Guide
Subject:        Medical Image Segmentation and Registration Toolkit
Keywords:       Registration,Segmentation,Guide
Author:         Luis Ibanez and Will Schroeder
Creator:        LaTeX with hyperref package
Producer:       dvips + GPL Ghostscript 8.15
CreationDate:   Mon Nov 21 19:34:28 2005
ModDate:        Mon Nov 21 19:34:28 2005
Tagged:         no
Pages:          836
Encrypted:      no
Page size:      522 x 675 pts
File size:      5580502 bytes
Optimized:      no
PDF version:    1.4

into DICOM elements...
*/
