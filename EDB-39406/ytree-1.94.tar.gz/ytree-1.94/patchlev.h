/***************************************************************************
 *
 * $Header: /usr/local/cvsroot/utils/ytree/patchlev.h,v 1.46 2010/02/28 13:11:53 werner Exp $
 *
 * Patchlevel-Definitionen
 *
 ***************************************************************************/


#define	VERSION		"1.94"
#define	PATCHLEVEL	0
#define VERSIONDATE	"Feb 28 2010"
