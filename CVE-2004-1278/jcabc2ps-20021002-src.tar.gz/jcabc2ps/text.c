#include "jcabc2ps.h"
#include "text.h"
#include "misc.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*/
char* TextStr(
	Text* tp)
{
	if (tp == 0)    return "[nil]";
	if (tp->t == 0) return "[null]";
	if (tp->l == 0) return "";
	return tp->t;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*/
int TextAppend(
	Text* tp,
	char* st)
{	int   sl = strlen(st);
	int   tl = tp->l + sl;
	char* p;
	if (!tp) {
		V1 "### Called with tp NULL ###\n" V;
		return 0;
	}
	if (!tp->t) {
		if (!TextInit(&tp)) {
			return 0;
		}
	}
	if (tl >= tp->m) {
		if (!(p = (char*)Malloc(tl+1,"txt+txt"))) {
			V1 "### Can't enlarge text string from %d to %d bytes ###\n",tp->m,tl+1 V;
			return 0;
		}
		bcopy(tp->t,p,tp->l+1);	// Copy old initial value
		Free(tp->t,"txt+txt");	// Free old value
		tp->t = p;				// Plug in new value
		V3 "--- Realloc Text string from %d to %d bytes\n",tp->m,tl+1 V;
		tp->m = tl+1;			// Note new allocated size
	}
	V6 "  Text changed from \"%s\"",tp->t V;
	strcpy(tp->t + tp->l, st);	// Append new string.
	V6 " to \"%s\" (%d bytes)\n",tp->t,tl V;
	tp->l = tl;					// Note new length.
	return tl;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
* Initialize a Text pointer.  We get a pointer to the pointer.  Our job is  to *
* put  it  into  a  known  initial  state.   This  entails  mallocing space if *
* necessary, and zeroing things out. The return value is 1 if we succeed and 0 *
* if we can't get space.                                                       *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
int TextInit(
	Text** tpp)
{	char*  F = "TextInit";
	Text*  tp = *tpp;	/* Local copy of pointer */
	if (!tp) {			/* Does the Text struct exist yet? */
		if (!(tp = (Text*)Malloc(sizeof(Text),"Text"))) {
			V1 "### Can't get %d bytes for Text structure ###\n",sizeof(Text) V;
			return 0;
		}
		V5 "%s: Malloc %d bytes at %X for Text struct.\n",F,sizeof(Text),tp V;
		*tpp = tp;		/* Save the struct's address in the pointer */
	}
	if (!(tp->t)) {		/* Does it have a text string? */
		if (!(tp->t = (char*)Malloc(64,"text"))) {
			V1 "### Can't get %d bytes for initial Text string ###\n",32 V;
			return 0;
		}
		V5 "%s: Malloc 64 bytes at %X for Text string.\n",F,tp->t V;
		tp->m = 32;	/* Initial size */
	}
	tp->t[0] = 0;	/* Make sure that the string is null */
	tp->l = 0;		/* Its length must also be zero */
	return 1;		/* Success */
}
