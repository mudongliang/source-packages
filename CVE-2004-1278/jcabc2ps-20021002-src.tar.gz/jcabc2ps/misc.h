#ifndef _misc_h_
#define _misc_h_

void Free(
	void *p,	/* Pointer to block of memory */
	char* d);	/* Description, for messages */

void *Malloc(
	int   n,	/* Number of bytes */
	char* d);	/* Description, for messages */

#endif
