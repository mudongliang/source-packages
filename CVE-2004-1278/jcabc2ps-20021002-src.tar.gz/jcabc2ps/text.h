#ifndef _text_h_
#define _text_h_

char* TextStr(
	Text* tp);

int TextAppend(
	Text* tp,
	char* st);

int TextInit(
	Text** tpp);


#endif
