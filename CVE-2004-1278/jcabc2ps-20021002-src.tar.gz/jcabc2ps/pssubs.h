#ifndef _pssubsH
#define _pssubsH

/*
 *  This file is part of jcabc2ps,
 *  Copyright (C) 1996,1997,1998  Michael Methfessel
 *  See file jcabc2ps.c for details.
 */

/*  subroutines for postscript output  */

void level1_fix (FILE *fp);

void init_ps (FILE *fp, char str[], int is_epsf, float bx1, float by1, float bx2, float by2);

void close_ps (FILE *fp);

void init_page (FILE *fp);

void init_index_page (FILE *fp);

void init_index_file (void);

void close_index_page (FILE *fp);

void close_page (FILE *fp);

void init_epsf (FILE *fp);

void close_epsf (FILE *fp);

void write_pagebreak (FILE *fp);

#endif _pssubsH
