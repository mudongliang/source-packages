# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
# Shorten a URL in various ways.
sub URLtrim {
	local($url) = @_;
	local($org) = @_ if $V>3;
	$url =~ s"/*\#.*"";					# Strip off name references.
#	$url =~ s"/*\?.*"";					# Strip off qualifiers.
#	$url =~ s"/*\%.*"";					# What are these?
	while ($url =~ s"/\./"/") {}		# Strip out /./ self-references.
	while ($url =~ s"/[^/]+/\.\./"/") {}	# Strip out /foo/../ up-references.
	print V "URLtrim <= \"$org\"\n   => \"$url\"\n" if (($V>3) && ($url ne $org));
	$url;
}
1;
