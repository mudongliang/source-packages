# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #
# Get the current data and time.  We leave the integer  timestamp  in #
# $now,  and  the OSI date/time in $cymdhms.  We also leave a shorter #
# date/time string without the century and year in $mdhms. Our return #
# value is $now, the Unix integer timestamp.                          #
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - #

sub dt {
	local($ss,$mm,$hh,$DD,$MM,$CY) = gmtime($now = time);
	$CY += 1900;
	$mdhms = sprintf('%02d' x 5,1+$MM,$DD,$hh,$mm,$ss);
	$cymdhms = "$CY$mdhms";
	return $now;
}
&dt;
