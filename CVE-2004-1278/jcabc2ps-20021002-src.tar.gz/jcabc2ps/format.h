#ifndef _formatH
#define _formatH

/*
 *  This file is part of jcabc2ps,
 *  Copyright (C) 1996,1997,1998  Michael Methfessel
 *  See file jcabc2ps.c for details.
 */


void fontspec (struct FONTSPEC *f, char name[], float size, int box);

int add_font (struct FONTSPEC *f);

void make_font_list (struct FORMAT *f);

void set_standard_format (struct FORMAT *f);

void set_pretty_format (struct FORMAT *f);

void set_pretty2_format (struct FORMAT *f);

void print_font (char *str, struct FONTSPEC fs);

void print_format (struct FORMAT f);

void g_unum (char *l, char *s, float *num);

void g_logv (char *l, char *s, int *v);

void g_fltv (char *l, int nch, float *v);

void g_intv (char *l, int nch, int *v);

void g_fspc (char *l, int nch, struct FONTSPEC *fn);

int interpret_format_line (char l[], struct FORMAT *f);

int read_fmt_file (char filename[], char dirname[], struct FORMAT *f);

#endif _formatH
