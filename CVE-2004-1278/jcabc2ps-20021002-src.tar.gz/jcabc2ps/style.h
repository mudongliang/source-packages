#ifndef _styleH
#define _styleH
/*
 *  This file is part of jcabc2ps,
 *  Copyright (C) 1996,1997,1998  Michael Methfessel
 *  See file jcabc2ps.c for details.
 */


/* name for this set of parameters */
#define STYLE "std"

void set_style_pars (float strictness);

#endif _styleH
