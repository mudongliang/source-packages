#ifndef _buffer_h_
#define _buffer_h_
/*
**  This file is part of jcabc2ps,
**  Copyright (C) 1996,1997,1998  Michael Methfessel
**  Copyright (C) 2000,2001       John Chambers
**  See file jcabc2ps.c for details.
*/

/* PUTn: add to buffer with n arguments */

#define PUT0(f) {sprintf(mbf,f); a2b(mbf); }
#define PUT1(f,a) {sprintf(mbf,f,a); a2b(mbf); }
#define PUT2(f,a,b) {sprintf(mbf,f,a,b); a2b(mbf); }
#define PUT3(f,a,b,c) {sprintf(mbf,f,a,b,c); a2b(mbf); }
#define PUT4(f,a,b,c,d) {sprintf(mbf,f,a,b,c,d); a2b(mbf); }
#define PUT5(f,a,b,c,d,e) {sprintf(mbf,f,a,b,c,d,e); a2b(mbf); }


void a2b (char *t);

void bskip(float h);

void init_pdims ();

void clear_buffer ();

void write_index_entry ();

void write_buffer (FILE *fp);

void buffer_eob (FILE *fp);

void check_buffer (FILE *fp, int nb);

#endif _buffer_h_

