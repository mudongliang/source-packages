#include <sys/types.h> /* For open() */
#include <sys/stat.h>  /* For open() */
#include <fcntl.h>     /* For open() */
#include <stdlib.h>     /* For exit() */
#include <unistd.h>     /* For close() */
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <fstream>
#include "dwarf.h"
#include "libdwarf.h"


#include "tool.h"
//using namespace qali;
using namespace std;


uint g_nNumOfGlobal = 0;
uint g_nNumOfLocal = 0;
uint g_nNumOfFile = 0;
std::map<uint, std::list<CData *> > g_DataMap;
std::set<string> g_UsedData;
std::vector<CData *> g_DataVec;
NameMangle g_NameMangle;
CTool g_Tool;


struct srcfilesdata {
    char ** srcfiles;
    Dwarf_Signed srcfilescount;
    int srcfilesres;
};


static void read_cu_list(Dwarf_Debug dbg);
static void print_die_data(Dwarf_Debug dbg, Dwarf_Die print_me,int level,
   struct srcfilesdata *sf);
static void get_die_and_siblings(Dwarf_Debug dbg, Dwarf_Die in_die,int in_level,
   struct srcfilesdata *sf);
static void resetsrcfiles(Dwarf_Debug dbg,struct srcfilesdata *sf);


static int namesoptionon = 0;


int main(int argc, char **argv)
{


    Dwarf_Debug dbg = 0;
    int fd = -1;
    const char *filepath = "<stdin>";
    int res = DW_DLV_ERROR;
    Dwarf_Error error;
    Dwarf_Handler errhand = 0;
    Dwarf_Ptr errarg = 0;


    if(argc < 2) {
        fd = 0; /* stdin */
    } else {
        int i = 0;
        for(i = 1; i < (argc-1) ; ++i) {
            if(strcmp(argv[i],"--names") == 0) {
                namesoptionon=1;
            } else {
                printf("Unknown argument \"%s\" ignored\n",argv[i]);
            }
        }
        filepath = argv[i];
        fd = open(filepath,O_RDONLY);  // Open the object file before dwarf_init
    }
    if(argc > 2) {
    }
    if(fd < 0) {
        printf("Failure attempting to open \"%s\"\n",filepath);
    }
    res = dwarf_init(fd,DW_DLC_READ,errhand,errarg, &dbg,&error); // Obtain the debug info as stored int dbg
    if(res != DW_DLV_OK) {
        printf("Giving up, cannot do DWARF processing\n");
        exit(1);
    }


    read_cu_list(dbg);      // read and print all compiler units
    res = dwarf_finish(dbg,&error);
    if(res != DW_DLV_OK) {
        printf("dwarf_finish failed!\n");
    }
    close(fd);      // Close the object file after dwarf_finish
    ofstream fout;
    fout.open("data.log");
    CTool::DumpData(fout);
    fout.close();
    return 0;
}


static void 
read_cu_list(Dwarf_Debug dbg)
{
    Dwarf_Unsigned cu_header_length = 0;
    Dwarf_Half version_stamp = 0;
    Dwarf_Unsigned abbrev_offset = 0;
    Dwarf_Half address_size = 0;
    Dwarf_Unsigned next_cu_header = 0;
    Dwarf_Error error;
    int cu_number = 0;


    for(;;++cu_number) {       
        Dwarf_Die no_die = 0;
        Dwarf_Die cu_die = 0;
        int res = DW_DLV_ERROR;
        res = dwarf_next_cu_header(dbg,&cu_header_length,
            &version_stamp, &abbrev_offset, &address_size,
            &next_cu_header, &error);            // get the offset of the next CU header
        if(res == DW_DLV_ERROR) {
            printf("Error in dwarf_next_cu_header\n");
            exit(1);
        }
        if(res == DW_DLV_NO_ENTRY) {
            /* Done. */
            return;
        }
        /* The CU will have a single sibling, a cu_die. */
        res = dwarf_siblingof(dbg,no_die,&cu_die,&error);  // get the first die (cu, pu, or tu) of dbg
        if(res == DW_DLV_ERROR) {
            printf("Error in dwarf_siblingof on CU die \n");
            exit(1);
        }
        if(res == DW_DLV_NO_ENTRY) {
            /* Impossible case. */
            printf("no entry! in dwarf_siblingof on CU die \n");
            exit(1);
        }
    // timon
    g_NameMangle.SetFile(cu_die);
    
        get_die_and_siblings(dbg,cu_die,0,NULL);      // travel the tree-grouped dies in pre-order
        dwarf_dealloc(dbg,cu_die,DW_DLA_DIE);
    
    // timon
    g_NameMangle.ResetFile();
    
    }
}


static void
get_die_and_siblings(Dwarf_Debug dbg, Dwarf_Die in_die,int in_level,
   struct srcfilesdata *sf)
{
    int res = DW_DLV_ERROR;
    Dwarf_Die cur_die=in_die;
    Dwarf_Die child = 0;
    Dwarf_Error error;
    
    print_die_data(dbg,in_die,in_level,sf);     // print out the die element first (root node first)
    


    for(;;) {
        Dwarf_Die sib_die = 0;
        res = dwarf_child(cur_die,&child,&error);
        if(res == DW_DLV_ERROR) {
            printf("Error in dwarf_child , level %d \n",in_level);
            exit(1);
        }
    
    // timon
    Dwarf_Error error1 = 0;
    Dwarf_Half tag1 = 0;
    int res1 = dwarf_tag(cur_die,&tag1,&error1);    // get the tag number
    if(res1 != DW_DLV_OK) {
      printf("Error in dwarf_tag \n");
      exit(1);
    }
    if( tag1 == DW_TAG_subprogram )
      g_NameMangle.SetFunc(cur_die);       
    // before child
        if(res == DW_DLV_OK) {       // foreach child-node, call the same function recursively (left first)      
            get_die_and_siblings(dbg,child,in_level+1,sf);
        }
    // after child
    // timon
    if( tag1 == DW_TAG_subprogram )
      g_NameMangle.ResetFunc();    
      
        /* res == DW_DLV_NO_ENTRY */
        res = dwarf_siblingof(dbg,cur_die,&sib_die,&error); // deal with the siblings last
        if(res == DW_DLV_ERROR) {
            printf("Error in dwarf_siblingof , level %d \n",in_level);
            exit(1);
        }
        if(res == DW_DLV_NO_ENTRY) {
            /* Done at this level. */
            break;
        }
        /* res == DW_DLV_OK */
        if(cur_die != in_die) {
            dwarf_dealloc(dbg,cur_die,DW_DLA_DIE);
        }
        cur_die = sib_die;
        print_die_data(dbg,cur_die,in_level,sf);
    }
    return;
}


// print out the die element
static void
print_die_data(Dwarf_Debug dbg, Dwarf_Die print_me,int level, struct srcfilesdata *sf)
{
    char *name = 0;
    Dwarf_Error error = 0;
    Dwarf_Half tag = 0;
    const char *tagname = 0;
    int localname = 0;
    char digits[8];


    int res = dwarf_tag(print_me,&tag,&error);    // get the tag number
    if(res != DW_DLV_OK) {
        printf("Error in dwarf_tag , level %d \n",level);
        exit(1);
    }
    sprintf(digits, "%d", tag);
    if( tag != DW_TAG_variable )          // only deal with variables
    return;
    
    // 0.1 if external?    
    Dwarf_Attribute attr;
    Dwarf_Bool bRet;
    bool bExternal = false;
    attr = CTool::GetAttribute(print_me,DW_AT_external,string("external"),false);    
    if( attr == NULL)
    bExternal = false;
    else
    {
    res = dwarf_formflag(attr, &bRet, &error );
    if(res != DW_DLV_OK ) {
      printf("Error in getting external value\n");
      exit(1);
    }    
    bExternal = bRet;
    }
    
    // 0.2 if declaration?
    bool bDeclared = false;
    attr = CTool::GetAttribute(print_me,DW_AT_declaration,string("declaration"),false);    
    if( attr == NULL)
    bDeclared = false;
    else
    {
    res = dwarf_formflag(attr, &bRet, &error );
    if(res != DW_DLV_OK ) {
      printf("Error in getting declaration value\n");
      exit(1);
    }    
    bDeclared = bRet;
    }
    // 1. get name    
    std::string szName = g_NameMangle.GetName(print_me, bExternal);
    if(szName.find("NoName") != string::npos)     // some variable has several variants, and not considered
    return;
    
    // 2. get address
    if( bDeclared )       // declared variables are not considered
    return;
    uint addr = 0;
    attr = CTool::GetAttribute(print_me, DW_AT_location, string("location"),false);
    if( attr == NULL)      // in optimized code, some symbols are removed
    addr = CTool::NON_ADDRESS;
    else
    {
    Dwarf_Block *pBlock;
    res = dwarf_formblock(attr, &pBlock, &error);
    if(res != DW_DLV_OK)
    {
      printf("Warning:\tno location value of %s; perhaps for the dynamic address-list\n", szName.c_str());  // error for getting address value
      addr = CTool::NON_STATIC_ADDRESS;
    }    
    else
    {    
      if( *(char *)(pBlock->bl_data) != 0X03 )    // if not static address, mark it by zero
       addr = CTool::NON_STATIC_ADDRESS;
      else 
       addr = *(int *)(pBlock->bl_data+1);
    }
    }
    // 3. get size
    attr = CTool::GetAttribute(print_me, DW_AT_type, string("type")+szName, true );
    Dwarf_Off offset;
    res = dwarf_global_formref(attr, &offset, &error);
    if( res != DW_DLV_OK) 
    {
    printf("Error in getting type value for %s\n", szName.c_str()); 
    exit(1);    
    }    
    
    Dwarf_Die typeDie = 0;
    res = dwarf_offdie(dbg, offset, &typeDie, &error);
    if( res != DW_DLV_OK)
    {
    printf("Error in getting die of type for %s\n", szName.c_str()); 
    exit(1);
    }
    uint size = CTool::GetTypeSize(dbg, typeDie, szName+digits);
    
    // 4. build a data record
    //string oriName = g_NameMangle.GetDieName(print_me);
    if( g_UsedData.find(szName) == g_UsedData.end() )
    {
    if( szName.find("%%") != string::npos)
      ++g_nNumOfFile;
    else if( szName.find("##") != string::npos)
      ++ g_nNumOfLocal;
    else
      ++g_nNumOfGlobal;
    CData *pData = new CData(szName, addr, size, level ); 
    pData->SetFile(g_NameMangle.GetDieName(g_NameMangle.m_fileDie));
    g_DataMap[addr].push_back(pData);
    g_UsedData.insert(szName);
    }
    printf("tag_level<%d>,\tname<\"%s\">,\taddress<%x>,\tsize<%d>\n", level,szName.c_str(),addr,size);   
}
