int main(int argc, char ** argv){

	int a; 
	a=1;
	if(argc==2){
		int a;
		a=2;
	}

	return 1;

}
