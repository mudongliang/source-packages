/* Code sample: Using libdwarf for getting the address of a function
** from DWARF in an ELF executable.
** Not much error-handling or resource-freeing is done here...
**
** Eli Bendersky (http://eli.thegreenplace.net)
** This code is in the public domain.
*/
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <dwarf.h>
#include <libdwarf.h>

void die(char* fmt, ...){
    va_list args;
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    exit(EXIT_FAILURE);
}

int get_offset_of_PC(Dwarf_Debug dbg,
    Dwarf_Attribute attrib,
    Dwarf_Unsigned * uval_out,
    Dwarf_Error * err)
{
	 Dwarf_Unsigned uval = 0;
	int vres = dwarf_formudata(attrib, &uval, err);
	if (vres != DW_DLV_OK) {
		Dwarf_Signed sval = 0;
		if(vres == DW_DLV_ERROR) {
			dwarf_dealloc(dbg,*err, DW_DLV_ERROR);
			*err = 0;
		}
		vres = dwarf_formsdata(attrib, &sval, err);
		if (vres != DW_DLV_OK) {
			vres = dwarf_global_formref(attrib,&uval,err);
			if (vres != DW_DLV_OK)
				return vres;
			*uval_out = uval;
		} else {
			uval =  (Dwarf_Unsigned) sval;
			*uval_out = uval;
		}
	} else {
		*uval_out = uval;
	}
	return DW_DLV_OK;
}

int is_location_form(int form){
    if (form == DW_FORM_block1 ||
        form == DW_FORM_block2 ||
        form == DW_FORM_block4 ||
        form == DW_FORM_block ||
        form == DW_FORM_data4 ||
        form == DW_FORM_data8 ||
        form == DW_FORM_sec_offset) {
        return 1;
    }
    return 0;
}


int _dwarf_print_one_expr_op(Dwarf_Debug dbg,Dwarf_Loc* expr)
{
    /*  local_space_needed is intended to be 'more than big enough'
        for a short group of loclist entries.  */
    char small_buf[100];
    Dwarf_Small op;
    Dwarf_Unsigned opd1;
    Dwarf_Unsigned opd2;
    Dwarf_Error err;
    op = expr->lr_atom;
    /*  We have valid operands whose values are bigger than the
        DW_OP_nop = 0x96; for example: DW_OP_GNU_push_tls_address = 0xe0
        Also, the function 'get_OP_name' handles this case, generating a
        name 'Unknown OP value'.  */
    if (op > DW_OP_hi_user) {
        printf("dwarf_op unexpected value!\n");
        return DW_DLV_ERROR;
    }
    opd1 = expr->lr_number;
   printf("The operation code number is %d\n", op);

}

static int get_form_values(Dwarf_Attribute attrib, Dwarf_Half * theform, Dwarf_Half * directform){
    Dwarf_Error err = 0;
    int res = dwarf_whatform(attrib, theform, &err);
    dwarf_whatform_direct(attrib, directform, &err);
    return res;
}

int
dwarfdump_print_one_locdesc(Dwarf_Debug dbg,
    Dwarf_Locdesc * llbuf)
{
    Dwarf_Locdesc *locd = 0;
    Dwarf_Half no_of_ops = 0;
    int i = 0;
    locd = llbuf;

    no_of_ops = llbuf->ld_cents;
    for (i = 0; i < no_of_ops; i++) {
        Dwarf_Loc * op = &locd->ld_s[i];
        int res = _dwarf_print_one_expr_op(dbg,op);
        if (res == DW_DLV_ERROR) {
            return res;
        }
    }
    return DW_DLV_OK;
}


void get_string_from_locs(Dwarf_Debug dbg,
    Dwarf_Ptr bytes_in,
    Dwarf_Unsigned block_len,
    Dwarf_Half addr_size)
{   
    Dwarf_Locdesc *locdescarray = 0;
    Dwarf_Signed listlen = 0;
    Dwarf_Error err2 =0;
    int res = 0;
    int res2 = dwarf_loclist_from_expr_a(dbg,
        bytes_in,block_len,
        addr_size,
        &locdescarray,
        &listlen,&err2);
    if (res2 == DW_DLV_ERROR) {
        printf("dwarf_get_loclist_from_expr_a\n");
	return; 
    }
    if (res2==DW_DLV_NO_ENTRY) {
        return;
    }
    /* lcnt is always 1 */

    /* Use locdescarray  here.*/
    res = dwarfdump_print_one_locdesc(dbg,
        locdescarray);
    if (res != DW_DLV_OK) {
        printf("Bad status from _dwarf_print_one_locdesc %d\n",res);
        exit(1);
    }
    
    dwarf_dealloc(dbg, locdescarray->ld_s, DW_DLA_LOC_BLOCK);
    dwarf_dealloc(dbg, locdescarray, DW_DLA_LOCDESC);
    return ;
}


void print_exprloc_content(Dwarf_Debug dbg,Dwarf_Die die, Dwarf_Attribute attrib)
{   
    Dwarf_Ptr x = 0;
    Dwarf_Unsigned tempud = 0;
    char small_buf[80];         
    Dwarf_Error err = 0;
    int wres = 0;
    wres = dwarf_formexprloc(attrib,&tempud,&x,&err);
    if (wres == DW_DLV_NO_ENTRY) {
        /* Show nothing?  Impossible. */
    } else if (wres == DW_DLV_ERROR) {
        printf("Cannot get a  DW_FORM_exprbloc....\n");
    } else {
        Dwarf_Half address_size = 0;
        int ares = 0;
        unsigned u = 0;
        snprintf(small_buf, sizeof(small_buf),
            "len 0x%04" DW_PR_DUx ": ",tempud);
        
        address_size = 0;
        ares = dwarf_get_die_address_size(die,&address_size,&err);
        if (wres == DW_DLV_NO_ENTRY) {
            printf("Cannot get die address size for exprloc\n");
        } else if (wres == DW_DLV_ERROR) {
            printf("Cannot Get die address size for exprloc\n");
        } else {
            get_string_from_locs(dbg,x,tempud,address_size);
        }
    }
}

void list_para_var_in_die(Dwarf_Debug dgb, Dwarf_Die the_die){
    char* die_name = 0;
    const char* tag_name = 0;
    Dwarf_Error err;
    Dwarf_Half tag;
    Dwarf_Attribute* attrs;
    Dwarf_Unsigned lowpc, highpc;
    Dwarf_Signed attrcount, i;
    Dwarf_Half return_form;
    int highpc_offset = 0; 

    int rc = dwarf_diename(the_die, &die_name, &err);

    if (rc == DW_DLV_ERROR)
        die("Error in dwarf_diename\n");
    else if (rc == DW_DLV_NO_ENTRY)
        return;

    if (dwarf_tag(the_die, &tag, &err) != DW_DLV_OK)
        die("Error in dwarf_tag\n");

    /* Only interested in subprogram DIEs here */
    if (tag != DW_TAG_formal_parameter && tag != DW_TAG_variable)
        return;

    if (dwarf_get_TAG_name(tag, &tag_name) != DW_DLV_OK)
        die("Error in dwarf_get_TAG_name\n");

    printf("DW_TAG_formal_parameter or DW_TAG_variable: '%s'\n", die_name);
#if 1
    /* Grab the DIEs attributes for display */
    if (dwarf_attrlist(the_die, &attrs, &attrcount, &err) != DW_DLV_OK)
        die("Error in dwarf_attlist\n");

    for (i = 0; i < attrcount; ++i) {
#if 1 
	    Dwarf_Half attrcode;
	    if (dwarf_whatattr(attrs[i], &attrcode, &err) == DW_DLV_OK){
		   if(attrcode == DW_AT_location){
			 Dwarf_Half theform = 0;
			 Dwarf_Half directform = 0;
			 get_form_values(attrs[i],&theform,&directform);
			 if (is_location_form(theform)){
					//we do not handle this case yet
					//fixme please
					printf("The location is in the location form\n");	
			}
			 else if (theform == DW_FORM_exprloc)  {
				 print_exprloc_content(dgb,the_die,attrs[i]);
			 } else {
					printf("The location cannot be handled\n");
			 }
		   }
	    }
#endif
	    dwarf_dealloc(dgb, attrs[i], DW_DLA_ATTR);
    }
    dwarf_dealloc(dgb, attrs, DW_DLA_LIST);	
#endif
}

void list_para_var_in_func(Dwarf_Debug dgb, Dwarf_Die the_die){
	Dwarf_Die   cur_die = the_die, child_die = 0, sib_diel = 0, sib_dier = 0;
	int res = DW_DLV_ERROR;
	Dwarf_Error err;

	/* Expect the CU DIE to have children */
	res = dwarf_child(cur_die, &child_die, &err);

	if(res == DW_DLV_ERROR){
		die("Error getting child of CU DIE\n");
		return;
	}

	if(res == DW_DLV_NO_ENTRY) {
		/* Impossible case. */
		printf("no entry! in dwarf_child on child die \n");
		return;
	}

	list_para_var_in_die(dgb, child_die);

	res = dwarf_siblingof(dgb, child_die, &sib_diel, &err);

	if (res == DW_DLV_ERROR)
		die("Error getting sibling of DIE\n");
	else if (res == DW_DLV_NO_ENTRY)
		return;
	list_para_var_in_die(dgb, sib_diel);

	//           list_func_in_die(dbg, sib_diel);   
	/* Now go over all children DIEs */
	while (1) {
		Dwarf_Die temp_die;
		res = dwarf_siblingof(dgb, sib_diel, &sib_dier, &err);
		temp_die = sib_diel;
		sib_diel = sib_dier;
		dwarf_dealloc(dgb,temp_die,DW_DLA_DIE);
		if (res == DW_DLV_ERROR)
			die("Error getting sibling of DIE\n");
		else if (res == DW_DLV_NO_ENTRY)
			break; /* done */
		list_para_var_in_die(dgb, sib_diel);
	}
	dwarf_dealloc(dgb,child_die,DW_DLA_DIE);
}


void list_func_in_die(Dwarf_Debug dgb, Dwarf_Die the_die){
    char* die_name = 0;
    const char* tag_name = 0;
    Dwarf_Error err;
    Dwarf_Half tag;
    Dwarf_Attribute* attrs;
    Dwarf_Unsigned lowpc, highpc;
    Dwarf_Signed attrcount, i;
    Dwarf_Half return_form;
    int highpc_offset = 0; 

    int rc = dwarf_diename(the_die, &die_name, &err);

    if (rc == DW_DLV_ERROR)
        die("Error in dwarf_diename\n");
    else if (rc == DW_DLV_NO_ENTRY)
        return;

    if (dwarf_tag(the_die, &tag, &err) != DW_DLV_OK)
        die("Error in dwarf_tag\n");

    /* Only interested in subprogram DIEs here */
    if (tag != DW_TAG_subprogram)
        return;

    if (dwarf_get_TAG_name(tag, &tag_name) != DW_DLV_OK)
        die("Error in dwarf_get_TAG_name\n");

    printf("DW_TAG_subprogram: '%s'\n", die_name);
#if 1
    /* Grab the DIEs attributes for display */
    if (dwarf_attrlist(the_die, &attrs, &attrcount, &err) != DW_DLV_OK)
        die("Error in dwarf_attlist\n");

    for (i = 0; i < attrcount; ++i) {
#if 1 
	    Dwarf_Half attrcode;
	    if (dwarf_whatattr(attrs[i], &attrcode, &err) == DW_DLV_OK){
		    if(attrcode == DW_AT_low_pc){
			    if(dwarf_whatform(attrs[i],&return_form,&err) == DW_DLV_OK){
				    if (return_form != DW_FORM_addr){
					    fprintf(stdout, "DEBUG: The form of the low ps is not accepted\n");
					    lowpc = 0; 	
				    }	
				    else 	
					    dwarf_formaddr(attrs[i], &lowpc, 0);
			    }
		    }
		    if(attrcode == DW_AT_high_pc){
			    if(dwarf_whatform(attrs[i],&return_form,&err) == DW_DLV_OK){
				    if (return_form != DW_FORM_addr){	
						if(get_offset_of_PC(dgb,attrs[i],&highpc,&err) == DW_DLV_OK){
							highpc_offset = 1;
						}
						else
							highpc = 0;		
				    }
				    else{
					    dwarf_formaddr(attrs[i], &highpc, 0);	
					    printf("High pc is %x\n", highpc);
					    highpc_offset = 0;	
				   }
			    }
		    }
		   if(attrcode == DW_AT_frame_base){
			 Dwarf_Half theform = 0;
			 Dwarf_Half directform = 0;
			 get_form_values(attrs[i],&theform,&directform);
			 if (is_location_form(theform)){
					//we do not handle this case yet
					//fixme please
					printf("The location is in the location form\n");	
			}
			 else if (theform == DW_FORM_exprloc)  {
				 print_exprloc_content(dgb,the_die,attrs[i]);
			 } else {
					printf("The location cannot be handled\n");
			 }
		   }
	    }
#endif
	    dwarf_dealloc(dgb, attrs[i], DW_DLA_ATTR);
    }
	  if(highpc_offset)
		highpc = highpc + lowpc; 
    dwarf_dealloc(dgb, attrs, DW_DLA_LIST);	

	list_para_var_in_func(dgb, the_die);

    printf("low pc  : %x\n", lowpc);
    printf("high pc : %x\n", highpc);
#endif


}

void print_line_numbers_this_cu(Dwarf_Debug dbg, Dwarf_Die cu_die){
	Dwarf_Signed linecount = 0;
	Dwarf_Line *linebuf = NULL;
	Dwarf_Signed i = 0;
	Dwarf_Addr pc = 0;
	Dwarf_Unsigned lineno = 0;
	Dwarf_Unsigned column = 0;
	Dwarf_Error err; 

	int lres = 0;
	int sres = 0;
	int ares = 0;
	int lires = 0;
	int cores = 0;
	int line_errs = 0;

	lres = dwarf_srclines(cu_die, &linebuf, &linecount, &err);
	if (lres == DW_DLV_ERROR) {
		/* Do not terminate processing */
	} else if (lres == DW_DLV_NO_ENTRY) {
		/* no line information is included */
	} else {
		for (i = 0; i < linecount; i++) {
			Dwarf_Line line = linebuf[i];
			char * filename = 0;
			int nsres = 0;
			Dwarf_Bool found_line_error = 0;

			filename = "<unknown>";
			sres = dwarf_linesrc(line, &filename, &err);
			if(sres == DW_DLV_ERROR)
				found_line_error = 1;

			ares = dwarf_lineaddr(line, &pc, &err);

			if (ares == DW_DLV_ERROR)
				found_line_error = 1;
			
			if (ares == DW_DLV_NO_ENTRY) 
				pc = 0;

			lires = dwarf_lineno(line, &lineno, &err);

			if (lires == DW_DLV_ERROR) 
				found_line_error = 1;

			if (lires == DW_DLV_NO_ENTRY) {
				lineno = -1LL;
			}
			cores = dwarf_lineoff_b(line, &column, &err);
		
			if (cores == DW_DLV_ERROR) 
				found_line_error = 1;
		
			if (cores == DW_DLV_NO_ENTRY)
				column = 0;

			if (found_line_error) 
				continue;

			printf("The PC is %x\n", pc);
			printf("One line information: Line %d and Column %d\n", lineno, column);
		}
		dwarf_srclines_dealloc(dbg, linebuf, linecount);
	}
}

void get_die_and_siblings(Dwarf_Debug dbg, Dwarf_Die in_die,int in_level)
{
   	    Dwarf_Die	cur_die = in_die, child_die = 0, sib_diel = 0, sib_dier = 0; 
	    int res = DW_DLV_ERROR;	
           Dwarf_Error err;
	    	
           print_line_numbers_this_cu(dbg, in_die);
	
	    /* Expect the CU DIE to have children */
	    res = dwarf_child(cur_die, &child_die, &err);

	    if(res == DW_DLV_ERROR){
		    die("Error getting child of CU DIE\n");
		    return; 

	   }

            if(res == DW_DLV_NO_ENTRY) {
                    /* Impossible case. */
                    printf("no entry! in dwarf_child on child die \n");
                    return; 
            }		

	   list_func_in_die(dbg, child_die);
	   res = dwarf_siblingof(dbg, child_die, &sib_diel, &err);	

	   if (res == DW_DLV_ERROR)
			die("Error getting sibling of DIE\n");
           else if (res == DW_DLV_NO_ENTRY)
			return; 
		  list_func_in_die(dbg, sib_diel);
	
		
//           list_func_in_die(dbg, sib_diel);	
	    /* Now go over all children DIEs */
	    while (1) {
		   Dwarf_Die temp_die; 
		    res = dwarf_siblingof(dbg, sib_diel, &sib_dier, &err);
		 temp_die = sib_diel;
		   sib_diel = sib_dier;

   		dwarf_dealloc(dbg,temp_die,DW_DLA_DIE);	

		    if (res == DW_DLV_ERROR)
			    die("Error getting sibling of DIE\n");
		    else if (res == DW_DLV_NO_ENTRY)
			    break; /* done */
      		list_func_in_die(dbg, sib_diel); 
			
	    }
	    dwarf_dealloc(dbg,child_die,DW_DLA_DIE);
}

void list_funcs_in_file(Dwarf_Debug dbg){
    Dwarf_Unsigned cu_header_length=0, abbrev_offset=0, next_cu_header=0;
    Dwarf_Half version_stamp=0, address_size=0;
    Dwarf_Error err;
    int cu_number = 0; 
    int res = DW_DLV_ERROR;	
    for(;;cu_number++){
	    /* Find compilation unit header */
	    Dwarf_Die no_die = 0, cu_die = 0;
	    res = dwarf_next_cu_header(
				    dbg,
				    &cu_header_length,
				    &version_stamp,
				    &abbrev_offset,
				    &address_size,
				    &next_cu_header,
				    &err);
	    if(res == DW_DLV_ERROR)
		    die("Error reading DWARF cu header\n");
	
	    if(res == DW_DLV_NO_ENTRY) {
            /* Done. */
              break;
           } 

	    /* Expect the CU to have a single sibling - a DIE */
	    res = dwarf_siblingof(dbg, no_die, &cu_die, &err);
		printf("========================one single compiling unit=============================\n");

	    if(res == DW_DLV_ERROR)
		    die("Error getting sibling of CU\n");

	    if(res == DW_DLV_NO_ENTRY) {
		    /* Impossible case. */
		    printf("no entry! in dwarf_siblingof on CU die \n");
			break;
	    }
	
	     get_die_and_siblings(dbg,cu_die,0);
             dwarf_dealloc(dbg,cu_die,DW_DLA_DIE);
    }

	printf("The number of compiling unit is %d\n", cu_number);

}


int main(int argc, char** argv)
{
    Dwarf_Debug dbg = 0;
    Dwarf_Error err;
    const char* progname;
    int fd = -1;

    if (argc < 2) {
        fprintf(stderr, "Expected a program name as argument\n");
        return 1;
    }

    progname = argv[1];
    if ((fd = open(progname, O_RDONLY)) < 0) {
        perror("open");
        return 1;
    }
    
    if (dwarf_init(fd, DW_DLC_READ, 0, 0, &dbg, &err) != DW_DLV_OK) {
        fprintf(stderr, "Failed DWARF initialization\n");
        return 1;
    }

    list_funcs_in_file(dbg);

    if (dwarf_finish(dbg, &err) != DW_DLV_OK) {
        fprintf(stderr, "Failed DWARF finalization\n");
        return 1;
    }


    close(fd);
    return 0;
}


