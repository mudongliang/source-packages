/* and the real names of the random devices */
#undef NAME_OF_DEV_RANDOM
#undef NAME_OF_DEV_URANDOM
#undef HAVE_DEV_RANDOM
#undef NO_GETPASS

#undef PACKAGE
#undef VERSION

#undef T_CPU
#undef T_VENDOR
#undef T_OS

#undef GZIP
#undef BZIP2

#undef NO_FCNTL_LOCK
#undef NON_FREE

#undef REQUEST_CAPABILITIES

#undef LIBMCRYPT24
#undef LIBMCRYPT22

#undef WIN32
