void *_mcrypt_malloc(size_t size);
void *_mcrypt_calloc(size_t nmemb, size_t size);
void *_mcrypt_realloc(void *ptr, size_t size);
void * _secure_mcrypt_malloc(size_t size);
void * _secure_mcrypt_calloc(size_t nmemb, size_t size);
void * _secure_mcrypt_realloc(void *ptr, size_t size);
void _mcrypt_free( void* ptr);
void _secure_mcrypt_free( void* ptr, int size);

