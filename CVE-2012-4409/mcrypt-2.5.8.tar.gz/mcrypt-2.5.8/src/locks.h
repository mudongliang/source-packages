void time_out(int signo);

#ifndef NO_FCNTL_LOCK
struct flock* file_lock(short type, short whence);
int read_lock(int fd);
int write_lock(int fd);
int append_lock(int fd);
void unlock(int fd);  /* unlock */

#else /* Do nothing */

void file_lock(short type, short whence);
int read_lock(int fd);
int write_lock(int fd);
int append_lock(int fd);
void unlock(int fd);

#endif /* NO_FCNTL_LOCK */
