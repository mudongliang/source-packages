
#line 104 "gaa.skel"
/* GAA HEADER */
#ifndef GAA_HEADER_POKY
#define GAA_HEADER_POKY

typedef struct _gaainfo gaainfo;

struct _gaainfo
{
#line 93 "mcrypt.gaa"
	char **input;
#line 92 "mcrypt.gaa"
	int size;
#line 83 "mcrypt.gaa"
	char *hash;
#line 79 "mcrypt.gaa"
	char *mode;
#line 74 "mcrypt.gaa"
	char **keys;
#line 73 "mcrypt.gaa"
	int keylen;
#line 70 "mcrypt.gaa"
	char *algorithm;
#line 67 "mcrypt.gaa"
	char *config_file;
#line 66 "mcrypt.gaa"
	int config;
#line 63 "mcrypt.gaa"
	char *keyfile;
#line 59 "mcrypt.gaa"
	int unlink_flag;
#line 56 "mcrypt.gaa"
	char *kmode;
#line 52 "mcrypt.gaa"
	char *modes_directory;
#line 49 "mcrypt.gaa"
	char *algorithms_directory;
#line 46 "mcrypt.gaa"
	int keysize;
#line 43 "mcrypt.gaa"
	int ed_specified;
#line 42 "mcrypt.gaa"
	int ein;
#line 41 "mcrypt.gaa"
	int din;
#line 38 "mcrypt.gaa"
	int double_check;
#line 35 "mcrypt.gaa"
	int flush;
#line 31 "mcrypt.gaa"
	int nodelete;
#line 28 "mcrypt.gaa"
	int noiv;
#line 25 "mcrypt.gaa"
	int noecho;
#line 22 "mcrypt.gaa"
	int nolock;
#line 19 "mcrypt.gaa"
	int bzipflag;
#line 16 "mcrypt.gaa"
	int gzipflag;
#line 13 "mcrypt.gaa"
	int bare_flag;
#line 10 "mcrypt.gaa"
	int real_random_flag;
#line 7 "mcrypt.gaa"
	int force;
#line 3 "mcrypt.gaa"
	int quiet;

#line 114 "gaa.skel"
};

#ifdef __cplusplus
extern "C"
{
#endif

    int gaa(int argc, char *argv[], gaainfo *gaaval);

    void gaa_help();
    
    int gaa_file(char *name, gaainfo *gaaval);
    
#ifdef __cplusplus
}
#endif


#endif
