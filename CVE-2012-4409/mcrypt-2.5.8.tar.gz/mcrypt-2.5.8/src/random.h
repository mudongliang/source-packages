
#ifdef HAVE_DEV_RANDOM

word32 get_rand32();
word8 get_rand8();
word32 get_safe_rand32();
word8 get_safe_rand8();

int open_rand(int);
void close_rand();
word32 get_o_rand32();
word8 get_o_rand8();

#endif
