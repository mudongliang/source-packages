/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef MAKEPAR_H
#define MAKEPAR_H

#include "par.h"

#endif /* MAKEPAR_H */
