/*
   rom-documents.c 
   Compiled by webcomp: Mon Jan 14 14:13:54 2013
 */

#include "goahead.h"

#if BIT_ROM
WebsRomIndex websRomIndex[] = {
	{ 0, 0, 0 }
};
#else
WebsRomIndex websRomIndex[] = {
	{ 0, 0, 0 }
};
#endif
