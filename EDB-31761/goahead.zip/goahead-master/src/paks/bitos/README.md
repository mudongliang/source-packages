Embedthis Bit O/S Layer
===

Licensing
---
See LICENSE.md for details.

### To Package:

    ./configure
    bit package

Resources
---
  - [Bit O/S GitHub repository](http://github.com/embedthis/bitos)
