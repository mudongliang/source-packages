#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "globals.h"
#include "functions.h"

int parse_mail(char *newtoken, char *temptoken)
{
char token[TOKENSIZE];
char variable[TOKENSIZE];
char molecule1[LINELENGTH];
char molecule2[LINELENGTH];
int tokentype;

  molecule1[0]=0;
  molecule2[0]=0;
  strcpy(variable,temptoken);

  strtolower(variable);

  autoindent();
/*
  while(1)
  {
    tokentype=gettoken(token);
    if (tokentype==5 || tokentype==0) break;
    printf("(%d) %s\n",tokentype,token);
  }
*/

  tokentype=gettoken(token);

/*
  if (strcmp(token,".")!=0)
  { error(token,".","parse_mail"); } 
*/

  if (strcasecmp(token,"execute")==0)
  {
    fprintf(out,"$%s_headers=$%s_headers.\"From: \".$%s_sender;\n",variable,variable,variable);

    autoindent();
    fprintf(out,"mail($%s_recipient,$%s_subject,$%s_body,$%s_headers);\n",variable,variable,variable,variable);
  }
    else
  if (strcasecmp(token,"addrecipient")==0)
  {
    fprintf(out,"$%s_recipient=$%s_recipient.",variable,variable); 
    eval_molecule(molecule1);
    fprintf(out,"%s.\",\";\n",molecule1);
  }
    else
  if (strcasecmp(token,"addheader")==0)
  {
    /* fprintf(out,"%s_recipient=%s_recipient.",variable,variable); */
    fprintf(out,"$%s_headers=$%s_headers.",variable,variable); 
    eval_molecule(molecule1);
    fprintf(out,"%s",molecule1);
    eval_molecule(molecule2);
    fprintf(out,".\": \".%s;\n",molecule2);
  }
    else
  {
    strcat(variable,"_");
    strcat(variable,token);

    strtolower(variable);

    tokentype=gettoken(token);
    fprintf(out,"$%s=",variable);

    if (strcmp(token,"=")==0)
    {
      /* eval_expression(" "); */
      eval_molecule(molecule1);
      fprintf(out,"%s;\n",molecule1);
      
    }
  }

  newtoken[0]=0;
  return 0;
}

int parse_new_mail(char *newtoken, char *temptoken)
{
char token[TOKENSIZE];
char molecule1[TOKENSIZE];
char molecule2[TOKENSIZE];
char molecule3[TOKENSIZE];
char molecule4[TOKENSIZE];
int tokentype;
int parens=0;

  tokentype=gettoken(token);
  if (strcmp(token,"(")==0)
  {
    parens++;
  }
    else
  {
    push (token, tokentype);
  }

  eval_molecule(molecule1);
  eval_molecule(molecule2);
  eval_molecule(molecule3);
  eval_molecule(molecule4);

  fprintf(out,"mail(%s,%s,%s,\"From: \".%s);\n",molecule2,molecule3,molecule4,molecule1);

  if (parens!=0)
  {
    tokentype=gettoken(token);
  }

  return 0;
}


