#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "globals.h"
#include "functions.h"

int parse_fileupload()
{
int tokentype;
char token[TOKENSIZE];
char newtoken[LINELENGTH];
char buffer[LINELENGTH];

  autoindent();

  if ((tokentype=gettoken(token))!=14)
  {
    error(token,".","Response");
    return 0;
  }

  tokentype=gettoken(token);

  if (strcasecmp(token,"write")==0)
  {
    fprintf(out,"echo ");
    tokentype=gettoken(token);
    push(token,tokentype);

    if (strcmp(token,"(")==0)
    {
      strcpy(newtoken,"");
      eval_funct(newtoken);
      fprintf(out,"%s;",newtoken);
    }
      else
    {
      eval_molecule(newtoken);
      fprintf(out,"%s;\n",newtoken);
    }
  } 
    else
  if (strcasecmp(token,"contenttype")==0)
  {
    tokentype=gettoken(token);
    if (strcmp(token,"=")!=0)
    { error(token,"=","ContentType"); }

    fprintf(out,"header(\"Content-type: \".");
    eval_molecule(newtoken);
    fprintf(out,"%s);\n",newtoken);
  }
    else
  if (strcasecmp(token,"addheader")==0)
  {
    fprintf(out,"header(");
    eval_molecule(newtoken);
    fprintf(out,"%s.\": \".",newtoken);
    eval_molecule(newtoken);
    fprintf(out,"%s);\n",newtoken);
  } 
    else
  if (strcasecmp(token,"expires")==0)
  {
    fprintf(out,"header(\"Expires: ");
    tokentype=gettoken(token);

    if (strcmp(token,"=")!=0)
    {  error(token,"=","parse_response"); }

    eval_molecule(newtoken);
    fprintf(out,"%s\");\n",newtoken);
  } 
    else
  if (strcasecmp(token,"redirect")==0)
  {
    fprintf(out,"header(\"Location: \".");
    tokentype=gettoken(token);
    push(token,tokentype);

    if (strcmp(token,"(")==0)
    {
      strcpy(newtoken,"");
      eval_funct(newtoken);
      fprintf(out,"%s);\nexit;\n",newtoken);
    }
      else
    {
      eval_molecule(newtoken);
      fprintf(out,"%s);\nexit();\n",newtoken);
    }
  }
    else
  if (strcasecmp(token,"cookies")==0)
  {
    sprintf(buffer,"setcookie(");

    tokentype=gettoken(token);
    push(token,tokentype);

    if (strcmp(token,"(")==0)
    {
      strcpy(newtoken,"");
      eval_funct(newtoken);
      strcat(buffer,newtoken);
    }
      else
    {
      eval_molecule(newtoken);
      strcat(buffer,newtoken);
    }

    tokentype=gettoken(token);
    if (strcmp(token,"=")==0)
    {
      fprintf(out,"%s",buffer);
      if (strcmp(token,"(")==0)
      {
        strcpy(newtoken,"");
        eval_funct(newtoken);
        fprintf(out,"%s,",newtoken);
      }
        else
      {
        eval_molecule(newtoken);
        fprintf(out,"%s,",newtoken);
      }

      fprintf(out,"0,\"\",\"\",0);\n");
    }
      else
    if (strcmp(token,".")==0)
    {
      unsupported("Response.Cookie.Something");
      comment_out("Unsupported: Response.Cookie.");
    }
      else
    {
      error(token,"=","parse_response");
    }
  }
    else
  { fprintf(out,"// asp2php says 'huh'?: "); eval_expression(" "); }

  return 0;
}

