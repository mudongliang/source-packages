#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globals.h"
#include "functions.h"

int db_open_mysql(char *newtoken,char *variable)
{
int tokentype;
char token[TOKENSIZE];
int paren=0;
char UID[TOKENSIZE];
char passwd[TOKENSIZE];
char database[TOKENSIZE];
char address[TOKENSIZE];
char dsn[TOKENSIZE];
char temp[LINELENGTH];

  tokentype=gettoken(token);
  if (strcmp(token,"(")==0)
  {
    paren=1;
    tokentype=gettoken(token);
  }

  if (global_uid[0]==0) { getvar(UID,token,"uid"); }
    else { strcpy(UID,global_uid); }
  if (global_passwd[0]==0) { getvar(passwd,token,"pwd"); }
    else { strcpy(passwd,global_passwd); }
  if (global_dsn[0]==0) { getvar(dsn,token,"dsn"); }
    else { strcpy(dsn,global_dsn); }
  if (global_database[0]==0) { getvar(database,token,"database"); }
    else { strcpy(database,global_database); }
  if (global_address[0]==0) { strcpy(address,"localhost"); }
    else { strcpy(address,global_address); }

  if (tokentype==10 || tokentype==11)
  {
    sprintf(newtoken,"$%s=mysql_connect(\"%s\",\"%s\",\"%s\");\n",
                                   variable,address,UID,passwd);
/*
    for (r=0; r<indent; r++)
    { strcat(newtoken,"  "); }
*/
    sprintf(temp,"mysql_select_db(\"%s\",$%s);\n",database,variable); 
    strcat(newtoken,temp);
  }
    else
  {
    push(token,tokentype);
    eval_molecule(temp);
    sprintf(newtoken,"$a2p_connstr=%s;\n",temp);
    strcpy(temp,newtoken);

    add_indent(temp);
    strcat(temp,"$a2p_uid=strstr($a2p_connstr,'uid');\n");
    add_indent(temp);
    strcat(temp,"$a2p_uid=substr($d,strpos($d,'=')+1,strpos($d,';')-strpos($d,'=')-1);\n");
    add_indent(temp);

    strcat(temp,"$a2p_pwd=strstr($a2p_connstr,'pwd');\n");
    add_indent(temp);
    strcat(temp,"$a2p_pwd=substr($d,strpos($d,'=')+1,strpos($d,';')-strpos($d,'=')-1);\n");
    add_indent(temp);

    if (strlen(database)==0)
    {
      strcat(temp,"$a2p_database=strstr($a2p_connstr,'dsn');\n");
      add_indent(temp);
      strcat(temp,"$a2p_database=substr($d,strpos($d,'=')+1,strpos($d,';')-strpos($d,'=')-1);\n");
      add_indent(temp);
    }

    sprintf(newtoken,"%s$%s=mysql_connect(\"%s\",$a2p_uid,$a2p_pwd);\n",
                                     temp,variable,address);
    if (strlen(database)==0)
    { sprintf(temp,"mysql_select_db($a2p_database,$%s);\n",variable); }
      else
    { sprintf(temp,"mysql_select_db(\"%s\",$%s);\n",database,variable); }
    add_indent(newtoken);
    strcat(newtoken,temp);
  }
 
  if (paren==1)
  { tokentype=gettoken(token); } 

  return 0;
}

int db_execute_mysql(char *newtoken,char *variable)
{
char molecule1[LINELENGTH];
char spaces[100];
int r;

  molecule1[0]=0;
  spaces[0]=0;
  eval_molecule(molecule1);

  if (setvar==0)
  {
    sprintf(newtoken,"mysql_query(%s,$%s);",molecule1,variable);
  }
    else
  {
    sprintf(newtoken,"$%s_query=mysql_query(%s,$%s);",objects[setvar],molecule1,variable);

    if (BOF==1)
    {
      strcat(newtoken,"\n");
      for (r=0; r<indent; r++)
      { strcat(newtoken,"  "); }
      strcat(newtoken,"$");
      strcat(newtoken,objects[setvar]);
      strcat(newtoken,"_BOF=1;");
    }

    for (r=0; r<indent; r++)
    { strcat(newtoken,"  "); }

    strcpy(objectstype[setvar],"ADODB.Execute");

    sprintf(molecule1,"\n$%s=mysql_fetch_array($%s_query);\n",objects[setvar],objects[setvar]);

    strcat(newtoken,molecule1);
  }

  return 0;
}

int parse_adodb_rs_mysql(char *newtoken,char *variable)
{
int tokentype;
char token[TOKENSIZE];
char molecule1[LINELENGTH];
char temp[512];
int r;

  /* autoindent(); */
  tokentype=gettoken(token);

  if (strcasecmp(token,"open")==0)
  {
/*
    tokentype=gettoken(token);
  
    sprintf(newtoken,"mysql_query($%s_CommandText,$%s_ActiveConnection);",variable,variable);
*/

    sprintf(newtoken,"$rs=mysql_query"); 
    convert_funct(newtoken,"1",0);
    strcat(newtoken, ";");
  }
    else
  if (strcasecmp(token,"bof")==0)
  { sprintf(newtoken,"($%s_BOF==1)",variable); }
    else
  if (strcasecmp(token,"eof")==0)
  { sprintf(newtoken,"($%s==0)",variable); }
    else
  if (strcasecmp(token,"move")==0)
  {
    tokentype=gettoken(token);
    if (strcmp(token,"(")!=0)
    { error(token,"(","move"); }

    tokentype=gettoken(token);

    sprintf(newtoken,"mysql_data_seek($%s_query,%s);\n",variable,token);

    tokentype=gettoken(token);
    if (strcmp(token,")")!=0)
    { error(token,")","move"); }
  }
    else
  if (strcasecmp(token,"count")==0 || strcasecmp(token,"recordcount")==0)
  {
    sprintf(newtoken,"mysql_num_rows($%s_query)",variable);
  }
    else
  if (strcasecmp(token,"movelast")==0)
  {
    sprintf(newtoken,"mysql_data_seek($%s_query,mysql_num_rows($%s_query)-1);\n",variable,variable);
    sprintf(temp,"\n$%s=mysql_fetch_array($%s_query);\n",variable,variable);
    strcat(newtoken,temp);

    if (BOF==1)
    {
      for (r=0; r<indent; r++)
      { strcat(newtoken,"  "); }
      strcat(newtoken,"$");
      strcat(newtoken,variable);
      strcat(newtoken,"_BOF=0;\n");
    }
  }
    else
  if (strcasecmp(token,"movenext")==0)
  { 
    sprintf(newtoken,"$%s=mysql_fetch_array($%s_query);\n",variable,variable);

    if (BOF==1)
    {
      for (r=0; r<indent; r++)
      { strcat(newtoken,"  "); }
      strcat(newtoken,"$");
      strcat(newtoken,variable);
      strcat(newtoken,"_BOF=0;\n");
    }
  }
    else
  if (strcmp(token,"(")==0)
  {
    tokentypepush=12;
    strcpy(tokenpush,"("); 
    molecule1[0]=0;
    eval_funct(molecule1);
    
    sprintf(newtoken,"$%s[%s]",variable,molecule1);

    tokentype=gettoken(token);
    if (strcmp(token,"=")==0)
    {
      fprintf(out,"%s=",newtoken);
      strcpy(newtoken,"");
      eval_expression(" ");
    }
      else
    { push(token,tokentype); }
  }

  return 0;
}

int parse_adodb_connection_mysql(char *newtoken,char *variable)
{
int tokentype;
char token[TOKENSIZE];

  tokentype=gettoken(token);
  /* newtoken[0]=0; */

  if (strcasecmp(token,"open")==0)
  { db_open_mysql(newtoken,variable); } 
    else 
  if (strcasecmp(token,"execute")==0)
  { db_execute_mysql(newtoken,variable); }
    else
  if (strcasecmp(token,"close")==0)
  { 
    sprintf(newtoken,"mysql_close($%s);",variable); 
  }

  return 0;
}

