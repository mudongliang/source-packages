#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globals.h"
#include "functions.h"

void parse_object(char *newtoken, char *token)
{
int tokentype,t;
char temptoken[TOKENSIZE];

  t=getobject(token);

  strcpy(temptoken,token);
  tokentype=gettoken(token);
  if (strcmp(token,".")!=0)
  {
    strcpy(tokenpush,token);
    tokentypepush=tokentype;
  }

  strcase(temptoken);

  if (t==1) 
  { 
    if (database_type==0)
    { parse_adodb_connection_mysql(newtoken,temptoken); }
      else
    if (database_type==1)
    { parse_adodb_connection_odbc(newtoken,temptoken); }
      else
    if (database_type==2)
    { parse_adodb_connection_oracle(newtoken,temptoken); }
      else
    if (database_type==3)
    { parse_adodb_connection_sybase(newtoken,temptoken); }
      else
    if (database_type==4)
    { parse_adodb_connection_pg(newtoken,temptoken); }
  }
    else
  if (t==2) 
  { 
    if (database_type==0)
    { parse_adodb_rs_mysql(newtoken,temptoken); }
      else
    if (database_type==1)
    { parse_adodb_rs_odbc(newtoken,temptoken); }
      else
    if (database_type==2)
    { parse_adodb_rs_oracle(newtoken,temptoken); }
      else
    if (database_type==3)
    { parse_adodb_rs_sybase(newtoken,temptoken); }
      else
    if (database_type==4)
    { parse_adodb_rs_pg(newtoken,temptoken); }
  }
    else
  if (t==3) { parse_command_set(newtoken,temptoken); }
    else
  if (t==5) { parse_filesystem(newtoken,temptoken); }
    else
  if (t==6) { parse_mail(newtoken,temptoken); }
    else
  if (t==7) { parse_new_mail(newtoken,temptoken); }

}

