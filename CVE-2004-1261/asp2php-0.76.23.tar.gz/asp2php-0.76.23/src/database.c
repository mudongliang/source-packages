#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globals.h"
#include "functions.h"

/* getvar() - grab the variables from the DSN string */

int getvar(char *answer, char *token, char *variable)
{
int t=0;
char *needle;

  needle=strcasestr_m(token,variable);
  answer[0]=0;

  if (needle==0)
  { return 0; }
    else
  {
    while (needle[0]!='=' && needle[0]!=0) needle++;

    if (needle[0]==0)
    { return 0; }

    needle++;
     
    if (needle[0]==0)
    { return 0; }

    while ((needle[t]!=';' && needle[t]!=0) &&
           (needle[t]!='\'' && needle[t]!='\"'))
    { t++; }
 
    strncpy(answer,needle,t);
    answer[t]=0;
  }

  return 0;
}


