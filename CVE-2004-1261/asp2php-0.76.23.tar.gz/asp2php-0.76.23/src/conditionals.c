#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globals.h"
#include "functions.h"

int parse_condition()
{
char token[TOKENSIZE];
int tokentype;
char newtoken[LINELENGTH];
char comment[LINELENGTH];
/* int lasttype=0; */

  putc('(',out);
  comment[0]=0;

  /* while((tokentype=gettoken(token))!=5 && tokentype!=3) */
  while((tokentype=gettoken(token))!=5)
  {
    if (tokentype==0) { return 1; }

    if (tokentype==3)
    {
      fprintf(out,"\n");
      autoindent();
      fprintf(out,"   ");
    }
      else
    if (tokentype==6)
    { break; }
      else
    if (tokentype==15)
    {
      strcpy(comment,token);
      strcpy(token,"\n");
      tokentype=5;
      break;
    }
      else
    if (tokentype==7)
    { fprintf(out,"%s",token); }
      else
/*
    if (tokentype==3)
    { putc('\n',out); continue; }
      else
*/
    if (strcasecmp(token,"not")==0)
    { fprintf(out,"!"); }
      else
    if (strcasecmp(token,"and")==0)
    { fprintf(out," && "); }
      else
    if (strcasecmp(token,"then")==0 || tokentype==5)
    { break; }
      else
    if (strcasecmp(token,"=")==0)
    { fprintf(out,"=="); }
      else
    if (strcasecmp(token,"<>")==0)
    { fprintf(out,"!="); }
      else
    if (strcasecmp(token,"or")==0)
    { fprintf(out," || "); }
      else
    if (tokentype==10 || tokentype==11)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==9)
    { putc('.',out); }
      else
    if (tokentype==12 || tokentype==8)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==1)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==2)
    {
      eval_element(newtoken, tokentype, token);
      fprintf(out,"%s",newtoken);
    }

    if (spacer==1) putc(' ',out);
  } 

  fprintf(out,")");
  push (token,tokentype);

  if (comment[0]!=0)
  {
    comment[strlen(comment)-1]=0;
    fprintf(out," %s",comment);
  }

  return 0;
}

int parse_select()
{
char token[TOKENSIZE];
char newtoken[LINELENGTH];
int t,c,tokentype;
int lasttype=0;

  tokentype=gettoken(token);
  if (strcasecmp(token,"case")!=0)
  { error(token,"case","Select"); }

  autoindent();
  fprintf(out,"switch ");
  c=parse_condition();
  putc('\n',out);
  autoindent();
  fprintf(out,"{\n");
  indent++;
  
  while(1)
  {
    tokentype=gettoken(token);
    if (tokentype==5 || tokentype==13)
    { continue; }
      else
    if (tokentype==0 || strcasecmp(token,"end")==0)
    { break; }
      else
    if (strcasecmp(token,"case")!=0)
    { error(token,"case","Select"); }

    while (1)
    {
      autoindent();
      tokentype=gettoken(token);

      if (strcasecmp(token,"else")==0)
      {
        fprintf(out,"default:\n");
        break;
      }

      push(token,tokentype);
      fprintf(out,"case ");
      lasttype=0;

      while (1)
      {
        tokentype=gettoken(token);

        if ((tokentype==10 || (tokentype==11 || tokentype==2)) && lasttype==1)
        { 
          push(token,tokentype);
          lasttype=2;
          break; 
        }

        if ((tokentype==5 || tokentype==13) || tokentype==6)
	{ break; }
	  else
	if (strcmp(token,",")==0)
	{ break; }
	  else
        if (tokentype!=2)
        { fprintf(out,"%s",token); }
          else
        if (isfunction(token)==1)
        {
    	  fprintf(out,"%s",token);
    	  t=gettoken(token);
    	  if (strcmp(token,"(")==0)
    	  {
      	    sprintf(newtoken,"(");
      	    strcpy(tokenpush,"(");
      	    tokentypepush=tokentype;
      	    eval_funct(newtoken);
	    strcat(newtoken,")");
    	  }
      	    else
    	  { error(token,"(","Select"); }
        }
          else
        { eval_token(tokentype,token); }

        if (tokentype==10 || tokentype==11 || tokentype==2)
        { lasttype=1; }
          else
        { lasttype=0; }
      }

      if (tokentype==6)
      {
        push(token,tokentype);
        fprintf(out,": ");
        break;
      }

      fprintf(out,":\n");

      if ((tokentype==5 || tokentype==13) || lasttype==2)
      { break; }

      if (tokentype==6)
      {
        push(token,tokentype);
        break;
      }
    }
    indent++;
    parse_body(0);
    autoindent();
    fprintf(out,"break;\n");
    indent--;

    tokentype=gettoken(token);
    if (strcasecmp(token,"select")==0)
    { break; }

    push(token,tokentype);
  }

  indent--;
  autoindent();
  fprintf(out,"} ");

  return 0;
}

int parse_if()
{
char token[255];
int tokentype;
int c;

  autoindent();
  fprintf(out,"if ");

  c=parse_condition();

  c=gettoken(token);
  fprintf(out,"\n");
  autoindent();
  fprintf(out,"{\n");
  indent++;

  tokentype=gettoken(token);
  push(token,tokentype);

  if (tokentype==15)
  {
    fprintf(out,"%s",token);
    tokentype=gettoken(token);
    tokentype=gettoken(token);
    push(token,tokentype);
    tokentype=5;
  }

  if (tokentype==5 || tokentype==6)
  { c=parse_body(0); }
    else
  { c=parse_body(1); }

  indent--;
  autoindent();
  fprintf(out,"} ");

  if (c==1)
  {
    tokentype=gettoken(token);

    if (strcasecmp(token,"if")!=0)
    {
      tokentypepush=tokentype;
      strcpy(tokenpush,token);
    }
  }

  tokentype=gettoken(token);
  push(token,tokentype);

  if (tokentype!=6)
  { fprintf(out,"\n"); }

  return 0;
}



