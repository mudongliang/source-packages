#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "globals.h"
#include "functions.h"

int eval_expression(char *oldtoken)
{
int tokentype;
char token[TOKENSIZE];
char temp[TOKENSIZE];
char newtoken[LINELENGTH];
int isstring=0;
int r;

  newtoken[0]=0;

  if (oldtoken[0]!=' ')
  { 
    autoindent();
    strcpy(token,oldtoken);
    strcase(token);
    fprintf(out,"$%s",token);

    if (spacer==1) putc(' ',out);

    tokentypepush=gettoken(temp);
    strcpy(tokenpush,temp);

    if (strcmp(temp,"(")==0)
    {
/* Fix me here!!! */
      convert_funct(newtoken,"1,2,3,4,5",20);
      fprintf(out,"%s",newtoken);
      
/*
      eval_funct(newtoken);
*/
      newtoken[0]=0;
      if (spacer==1) putc(' ',out);
    }
  }

  while((tokentype=gettoken(token))!=5 && tokentype!=13)
  {
    if (tokentype==10 || tokentype==11)
    { isstring=1; }

    if (tokentype==0) { return 0; }
      else
    if (tokentype==15)
    { fprintf(out,"; %s",token); }
      else
    if (strcasecmp(token,"else")==0)
    {
/*
printf("else\n");
      push(token,tokentype);
*/
      /* fprintf(out," } else { "); */
      fprintf(out,";\n");
      indent--;
      autoindent();
      fprintf(out,"}\n");
      autoindent();
      fprintf(out,"  else\n");
      autoindent();
      fprintf(out,"{\n");
      indent++;
      parse_body(1);
      indent--;

      return 0;
    }
      else
    if (tokentype==6)
    {
      fprintf(out,"; ");
      strcpy(tokenpush,token);
      tokentypepush=tokentype;
      return 0;
    }
      else
    if (strcasecmp(token,"mod")==0)
    { fprintf(out,"%c",'%'); }
      else
/*
    if (strcasecmp(token,"&h")==0)
    {
      tokentype=gettoken(token);
      fprintf(out,"0x%s",token+1);
    }
      else
*/
    if (strcmp(token,"+")==0)
    { fprintf(out,"+"); }
      else
    if (strcmp(token,",")==0)
    { 
      strcpy(tokenpush,token);
      tokentypepush=tokentype;
      return 0;
    }
      else
    if (tokentype==3)
    {
      fprintf(out,"\n  ");
      autoindent();
      continue;
    }
      else
    {
      r=eval_element(newtoken,tokentype,token);
      fprintf(out,"%s",newtoken);
      if (r==-1) return 0;
    }
  }

  putc(';',out);
  if (tokentype==5) putc('\n',out);
    else
  if (tokentype==13) fprintf(out," ");

  return 0;
}

void convert_expression(char *newtoken)
{
char token[TOKENSIZE];
int tokentype;

  tokentype=gettoken(token);
  if (strcmp(token,"=")!=0)
  { error(token,"=","convert_expression()"); }

  eval_molecule(newtoken);
}

