#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "globals.h"
#include "functions.h"

void change_tag(char *tag)
{
char *s,*r;
int t,l;

  if (fixwin95paths==1) fixwinpath(tag);
  s=strcasestr_m(tag,".asp");

  if (s!=0)
  {
    s[1]='p';
    s[2]='h';
    s[3]='p';

    if (php==3 || php==4) 
    {
      l=strlen(s)+1;

      for (t=l; t>=5; t--)
      {
        s[t]=s[t-1];
      }

      s[4]=php+'0';
    }
  }

  s=strcasestr_m(tag,".gif");

  if (s!=0 && pngs==1)
  {
    s[1]='p';
    s[2]='n';
    s[3]='g';
  }

  s=strcasestr_m(tag,".htm");

  if (s!=0 && html==1)
  {
    if (strcasestr_m(s,".html")!=s)
    {
      s=s+4;
      r=tag+strlen(tag);
      while (1)
      {
        r[1]=r[0];
        if (r==s) break;
        r--;
      }
      s[0]='l';
    }
  }
}

/* parse_tag() will change occurances of .asp to .php/.php3/.php4 and
   change .htm to .html */

void parse_tag()
{
int ch,lastchar;
int count=0;
char extension[12];

  while((ch=getc(in))!=EOF)
  {
    lastchar=ch;
    if (!((ch>='a' && ch<='z') || (ch>='A' && ch<='Z')) || count>3)
    {
      break;
    }
    extension[count++]=ch;
  }

  extension[count]=0;

  if (strcasecmp(extension,"htm")==0 && html==1)
  { strcpy(extension,"html"); }
    else
  if (strcasecmp(extension,"asp")==0)
  { 
    strcpy(extension,"php");
    if (php==3) strcat(extension,"3");
      else
    if (php==4) strcat(extension,"4");
  }
    else
  if (strcasecmp(extension,"gif")==0 && pngs==1)
  { strcpy(extension,"png"); }

  fprintf(out,"%s",extension);
  putc(lastchar,out);
}

/* check and see if a tag is <script language=vbscript runat=server> */
/* Btw kids.. this code is gross.. don't copy crap like this */

int is_openasp(char *tag)
{
  if (strcasestr_m(tag,"runat")!=0)
  {
    if (strcasestr_m(tag,"server")!=0)
    {
      if (strcasestr_m(tag,"language")!=0)
      {
        if (strcasestr_m(tag,"vbscript")!=0)
        { return 1; }
          else
        if (strcasestr_m(tag,"jscript")!=0 || strcasestr_m(tag,"javascript")!=0)
        { return 3; }
          else
        { return 1; }
      }
        else
      {
        if (language==0) return 1;
          else
        if (language==1) return 3;
          else
        { return 1; }
      }
    }
  }

  return 0;
}

/* get attribute from tag */

int getattribute(char *tag, char *att, char *value)
{
char *s;
char q;
int t;

  q=0;
  if ((s=strcasestr_m(tag,att))==0) return 0;

  while (s[0]!='=' && s[0]!=0) s++;
  if (s[0]==0) return 0;
  s++;

  while (s[0]==' ') s++;

  if (s[0]=='\'' || s[0]=='\"') 
  { 
    q=s[0];
    s++;
  }

  t=0;
  while (1)
  {
    value[t++]=s[0];
    s++;

    if (q==0 && (s[0]==' ' || s[0]=='>')) break;
    if (s[0]==q) break;
    if (s[0]==0) break;
  }

  value[t]=0;
  return 1;
}

/* parse include to change to require */

void parse_include(char *tag)
{
char value[100];

  change_tag(tag);

  if (getattribute(tag,"file",value)==1)
  {
    if (fixwin95paths==1) fixwinpath(value);
    if ((flags|1)==0)
    { fprintf(out,"? require(\"%s\"); ?>",value); }
      else
    { fprintf(out,"?php require(\"%s\"); ?>",value); }
  }
    else
  if (getattribute(tag,"virtual",value)==1)
  {
    if (fixwin95paths==1) fixwinpath(value);
    if ((flags|1)==0)
    { fprintf(out,"? require(\"%s\"); ?>",value); }
      else
    { fprintf(out,"?php require(\"%s\"); ?>",value); }
  }
    else
  {
    fprintf(out,"%s",tag);
  }
}

/* 
   read in tag to see if it's a script tag or an image tag or
   an include tag
*/

int parse_for_script()
{
char tag[4096];
int tagptr,ch;

  tagptr=0;

  while((ch=getc(in))!=EOF)
  {
    tag[tagptr++]=ch;

    if (ch=='%' && tagptr==1) 
    {
      if (language==0)
      { return 1; }
        else
      if (language==1)
      { return 3; }
        else
      { return 1; }
    }

    if (ch=='<')
    {
      ch=getc(in);

      if (ch=='%')
      {
        tag[tagptr]=0;
        fprintf(out,"%s",tag);

        if (language==0)
        { return 1; }
          else
        if (language==1)
        { return 3; }
          else
        { return 1; }
      }
        else
      { 
        tag[tagptr++]=ch;
        continue; 
      }
    }
      else
    if (ch=='>' || tagptr>4000)
    {
      tag[tagptr++]=0;

      if (strncasecmp(tag,"script",6)==0 && is_openasp(tag)==1)
      {  return 1; }
         else
      if (strncasecmp(tag,"script",6)==0 && is_openasp(tag)==3)
      {  return 3; }
         else
      /* if (includes==1 && (strncasecmp(tag,"!--#include",11)==0 || strncasecmp(tag,"!-- #include",12)==0)) */
      if (includes==1 && (strncasecmp(tag,"!--",3)==0 || strcasestr_m(tag,"#include")!=0))
      {
        parse_include(tag);
        return 0; 
      }
         else
      /* if (strncasecmp(tag,"!--#include",11)==0 || strncasecmp(tag,"!-- #include",12)==0) */
      if (strncasecmp(tag,"!--",3)==0 || strcasestr_m(tag,"#include")!=0)
      {
        change_tag(tag);
        fprintf(out,"%s",tag);
        return 0; 
      }
        else
      if (strncasecmp(tag,"img",3)==0)
      {
        change_tag(tag);
        fprintf(out,"%s",tag);
        return 0;
      }
        else
      if (strncasecmp(tag,"a ",2)==0)
      {
        change_tag(tag);
        fprintf(out,"%s",tag);
        return 0;
      }
        else
      if (strncasecmp(tag,"form",2)==0)
      {
        change_tag(tag);
        fprintf(out,"%s",tag);
        return 0;
      }
        else
      if (strncasecmp(tag,"frame",2)==0)
      {
        change_tag(tag);
        fprintf(out,"%s",tag);
        return 0;
      }
        else
      if (strncasecmp(tag,"script",6)==0)
      { 
        fprintf(out,"%s",tag);
        return 2; 
      }
        else
      { 
        fprintf(out,"%s",tag);
        return 0; 
      }
    }
  }

  return 0;
}

/* copyhtml() will simply copy html code straight */

int copyhtml()
{
int ch,lastchar=-1,k=0;
int carret=0,quote=0;
char *endscript="</script>";
int endptr;

  endptr=0;

  while((ch=getc(in))!=EOF)
  {
    if (javascript==1)
    {
      if (tolower(ch)==endscript[endptr++])
      {
        if (endscript[endptr]==0)
        {
          endptr=0;
          javascript=0;
        }
      }
        else
      { endptr=0; }
    }

    if (javascript==1 && (ch=='%' && lastchar=='<'))
    {
      if ((flags&1)==0)
      { fprintf(out,"<? "); }
        else
      { fprintf(out,"<?php "); }

#ifdef DEBUG
printf("in_body=%d\n",in_body);
#endif

      if (in_body!=0) return 0;

      if (language==0)
      { parse_body(0); }
        else
      if (language==1)
      { parse_body_j(); }
    }
      else
    if (ch=='<' && javascript==0) 
    { 
      if (lastchar!=-1) { putc(lastchar,out); }

      putc('<',out);
      k=parse_for_script();

      if (k==1 || k==3)
      {
        if ((flags&1)==0)
        { fprintf(out,"? "); }
          else
        { fprintf(out,"?php "); }

#ifdef DEBUG
printf("in_body=%d\n",in_body);
#endif

        if (in_body!=0) return 0;

        if (k==1)
        { parse_body(0); }
          else
        if (k==3)
        { parse_body_j(); }
      }
        else
      if (k==2)
      { javascript=1; }

      lastchar=-1;
      continue;
    }

    if (ch=='\n' && carret==0) line++;
      else
    if (carret==1 && ch!='\n')
    { carret=0; column=0; }
      else
    if (carret==1 && ch=='\n')
    { continue; }

    carret=0;

    if (ch=='\r')
    { 
      if (lastchar!=-1) putc(lastchar,out); 
      putc('\n',out); 
      lastchar=-1;
      carret=1; 
      line++; 
      column=0; 
      continue; 
    }

    column++;

    if ((ch=='\'' || ch=='\"') && lastchar!='\\')
    {
      if (ch==quote)
      { quote=0; }
        else
      { quote=ch; }
    }

    if (quote!=0)
    {
      if ((ch==' ' || ch=='\t') || (ch=='\r' || ch=='\n'))
      { quote=0; line++; }
    }

    if (lastchar!=-1)
    { putc(lastchar,out); }
    lastchar=ch;
  }

  if (lastchar!=-1) putc(lastchar,out);
  return 1;
}



