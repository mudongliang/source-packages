#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../globals.h"
#include "../functions.h"

void eval_expression_j()
{
char token[TOKENSIZE];
char newtoken[LINELENGTH];
int tokentype;
int sflag=0;
int parens=0;

  while(1)
  {
    tokentype=gettoken_j(token);

#ifdef DEBUG
printf("eval_expression: %d: %s\n",tokentype, token);
#endif

    if (tokentype==0)
    { return; }
      else
    if (tokentype==7)
    {
      if (strcmp(token,"+")!=0 || sflag==0)
      { fprintf(out,"%s",token); }
        else
      { fprintf(out,"."); }
    }
      else
    if (strcmp(token,"(")==0)
    {
      parens++;
      fprintf(out,"%s",token);
    }
      else
    if (strcmp(token,")")==0)
    {
      parens--;

      if (parens<0)
      {
        push(token,tokentype);
        break;
      }

      fprintf(out,"%s",token);
    }
      else
    if (tokentype==1)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==5)
    { fprintf(out,"\n"); }
      else
    if (tokentype==8 || tokentype==9)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==18)
    { fprintf(out," %s ",token); }
      else
    if (tokentype==10 || tokentype==11)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==2)
    {
      eval_token_j(newtoken,tokentype,token);
      fprintf(out,"%s",newtoken);
    }
      else
    if (tokentype==3)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==17)
    {
      fprintf(out,";");
      break;
    }
  }
}

void convert_expression_j(char *token)
{
char temp[TOKENSIZE];
int tokentype;

  tokentype=gettoken_j(temp);
  if (strcmp(temp,"=")!=0)
  {
    error(temp,"=","convert_expression");
  }

  convert_funct_j(token,"1",1);
}

