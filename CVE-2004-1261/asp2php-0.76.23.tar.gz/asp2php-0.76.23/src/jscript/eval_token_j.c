#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../globals.h"
#include "../functions.h"

int eval_token_j(char *newtoken, int tokentype,char *token)
{
char molecule1[LINELENGTH];
char *onetoone[]={ "strcmp","strcat",0 };
int ptr;

  newtoken[0]=0;
  molecule1[0]=0;

  ptr=0;

  while(onetoone[ptr]!=0)
  {
    if (strcmp(token,onetoone[ptr])==0)
    {
      convert_funct_j(molecule1,"1,2,3,4,5,6,7,8",4);
      sprintf(newtoken,"%s%s",token,molecule1);
      return 0;
    }

    ptr++;
  }

  if (strcasecmp(token,"request")==0)
  { parse_request_j(newtoken); }
/*
    else
  if (strcasecmp(token,"strcmp")==0 || strcasecmp(token,"strcat")==0)
  {
    convert_funct_j(molecule1,"1,2",0);
    sprintf(newtoken,"%s%s",token,molecule1);
  }
*/
    else
  {
    ptr=gettoken_j(molecule1);
    if (strcmp(molecule1,".")!=0)
    {
      push(molecule1,ptr);
      sprintf(newtoken,"$%s",token); 
    }
      else
    { eval_method_j(newtoken,token); }
  }

  return 0;
}

int eval_method_j(char *newtoken, char *variable)
{
char molecule1[LINELENGTH];
char token[TOKENSIZE];
int tokentype;

  molecule1[0]=0;
  tokentype=gettoken_j(token);

  if (strcasecmp(token,"length")==0)
  { sprintf(newtoken,"strlen($%s)",variable); }
    else
  if (strcasecmp(token,"link")==0)
  {
    convert_funct_j(molecule1,"1",1);
    sprintf(newtoken,"\"<A HREF=\\\"\".%s.\"\\\">\".$%s.\"</A>\"",molecule1,variable);
  } 
    else
  if (strcasecmp(token,"substr")==0)
  {
    convert_funct_j(molecule1,"1,2",5);
    sprintf(newtoken,"substr($%s,%s)",variable,molecule1);
  } 
    else
  if (strcasecmp(token,"tolowercase")==0)
  {
    convert_funct_j(molecule1,"1",1);
    sprintf(newtoken,"strtolower($%s)",variable);
  } 
    else
  if (strcasecmp(token,"tostring")==0 || strcasecmp(token,"valueof")==0)
  {
    convert_funct_j(molecule1,"1",1);
    sprintf(newtoken,"$%s",variable);
  } 
    else
  if (strcasecmp(token,"touppercase")==0)
  {
    convert_funct_j(molecule1,"1",1);
    sprintf(newtoken,"strtoupper($%s)",variable);
  } 

  return 0;
}

