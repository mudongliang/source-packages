#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../globals.h"
#include "../functions.h"


void parse_for_j()
{
char token[TOKENSIZE];
int tokentype;

  fprintf(out,"for(");
  tokentype=gettoken_j(token);

  if (strcmp(token,"(")!=0)
  { error(token,"(","for"); }

  eval_expression_j();
  eval_expression_j();
  eval_expression_j();
  fprintf(out,")");

  tokentype=gettoken_j(token);
  parse_section_j();
}

void parse_while_j()
{
char token[TOKENSIZE];
int tokentype;

  fprintf(out,"while(");
  tokentype=gettoken_j(token);

  if (strcmp(token,"(")!=0)
  { error(token,"(","while"); }

  eval_expression_j();
  fprintf(out,")");

  tokentype=gettoken_j(token);
  parse_section_j();
}



