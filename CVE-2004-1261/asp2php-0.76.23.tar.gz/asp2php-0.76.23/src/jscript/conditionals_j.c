#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../globals.h"
#include "../functions.h"

void parse_condition_j()
{
char token[TOKENSIZE];
char newtoken[LINELENGTH];
int tokentype;
int sflag=0;
int parens;

  while(1)
  {
    tokentype=gettoken_j(token);

    if (tokentype==7)
    {
      if (strcmp(token,"+")!=0 || sflag==0)
      { fprintf(out,"%s",token); }
        else
      { fprintf(out,"."); }
    }
      else
    if (tokentype==12)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==1)
    { fprintf(out,"%s",token); }
      else
    if (tokentype==2)
    {
      eval_token_j(newtoken,tokentype,token);
      fprintf(out,"%s",newtoken);
    }
      else
    if (tokentype==17)
    {
      fprintf(out,";");
      break;
    }
  }

  parens=0;
}

void parse_if_j()
{
char token[TOKENSIZE];
int tokentype;
int f;

  f=0;

  while(1)
  {
    if (f==0)
    {
      fprintf(out,"if (");
      tokentype=gettoken_j(token);

      if (strcmp(token,"(")!=0)
      { error(token,"(","if"); }

      eval_expression_j();
      fprintf(out,")");
      tokentype=gettoken_j(token);
    }

    parse_section_j();

    while(1)
    {
      tokentype=gettoken(token);
      if (tokentype==5)
      { fprintf(out,"\n"); }
        else
      { break; }
    }

#ifdef DEBUG
printf("parse_if out: %d: %s\n",tokentype,token);
#endif

    if (strcmp(token,"else")!=0)
    {
      push(token,tokentype);
      break;
    }

    fprintf(out,"else");

    while(1)
    {
      tokentype=gettoken(token);
      if (tokentype==5)
      { fprintf(out,"\n"); }
        else
      { break; }
    }

    if (strcmp(token,"if")!=0)
    { 
      f=1;
      push(token,tokentype);
    }
  }
}

void parse_switch_j()
{


}



