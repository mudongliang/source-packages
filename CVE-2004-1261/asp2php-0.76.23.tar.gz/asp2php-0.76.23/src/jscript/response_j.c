#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../globals.h"
#include "../functions.h"

int parse_response_j()
{
int tokentype;
char token[TOKENSIZE];
char newtoken[LINELENGTH];
char buffer[LINELENGTH];

  newtoken[0]=0;
  autoindent();

  if ((tokentype=gettoken_j(token))!=14)
  {
    error(token,".","Response");
    return 0;
  }

  tokentype=gettoken_j(token);

  if (strcasecmp(token,"write")==0)
  {
    convert_funct_j(newtoken,"1",1);
    fprintf(out,"print %s;",newtoken); 
  } 
    else
  if (strcasecmp(token,"binarywrite")==0)
  {
    convert_funct_j(newtoken,"1",1);
    fprintf(out,"print %s;",newtoken); 
  } 
    else
  if (strcasecmp(token,"contenttype")==0)
  {
    convert_expression_j(newtoken);
    fprintf(out,"header(\"Content-type: \".%s);\n",newtoken);
  }
    else
  if (strcasecmp(token,"addheader")==0)
  {
    convert_funct_j(newtoken,"1,@\": \",2",2);
    fprintf(out,"header%s;",newtoken); 
  } 
    else
  if (strcasecmp(token,"expires")==0)
  {
    convert_expression_j(newtoken);
    fprintf(out,"header(\"Expires: \".%s);\n",newtoken);
  } 
    else
  if (strcasecmp(token,"expiresabsolute")==0)
  {
    convert_expression_j(newtoken);
    fprintf(out,"header(\"Expires: \".%s);\n",newtoken);
  } 
    else
  if (strcasecmp(token,"status")==0)
  {
    convert_expression_j(newtoken);
    fprintf(out,"header(\"Status: \".%s);\n",newtoken);
  } 
    else
  if (strcasecmp(token,"buffer")==0)
  {
    convert_expression_j(newtoken);
    if (strcasecmp(newtoken,"true")==0 || strcasecmp(newtoken,"1")==0)
    { fprintf(out,"ob_start();\n"); }
      else
    if (strcasecmp(newtoken,"false")==0 || strcasecmp(newtoken,"0")==0)
    { fprintf(out,"ob_end_flush();\n"); }
      else
    { printf("Problem with Response.Buffer= conversion on line %d\n",line); } 
  } 
    else
  if (strcasecmp(token,"clear")==0)
  {
    fprintf(out,"ob_clean();\n"); 
  }
    else
  if (strcasecmp(token,"redirect")==0)
  {
    convert_funct_j(newtoken,"@\"Location: \",1",2);
    fprintf(out,"header%s;",newtoken); 
  }
    else
  if (strcasecmp(token,"cookies")==0)
  {
    sprintf(buffer,"setcookie(");

    tokentype=gettoken_j(token);
    push(token,tokentype);

    if (strcmp(token,"(")==0)
    {
      strcpy(newtoken,"");
      eval_funct(newtoken);
      strcat(buffer,newtoken);
    }
      else
    {
      eval_molecule(newtoken);
      strcat(buffer,newtoken);
    }

    tokentype=gettoken_j(token);
    if (strcmp(token,"=")==0)
    {
      fprintf(out,"%s",buffer);
      if (strcmp(token,"(")==0)
      {
        strcpy(newtoken,"");
        eval_funct(newtoken);
        fprintf(out,"%s,",newtoken);
      }
        else
      {
        eval_molecule(newtoken);
        fprintf(out,"%s,",newtoken);
      }

      fprintf(out,"0,\"\",\"\",0);\n");
    }
      else
    if (strcmp(token,".")==0)
    {
      unsupported("Response.Cookie.Something");
      comment_out("Unsupported: Response.Cookie.");
    }
      else
    {
      error(token,"=","parse_response");
    }
  }
    else
  if (strcasecmp(token,"end")==0)
  {
    fprintf(out,"exit();\n");
  }
    else
  if (strcasecmp(token,"flush")==0)
  {
    fprintf(out,"flush();\n");
  }
    else
  { fprintf(out,"// Unknown response object on line %d\n",line); eval_expression(" "); }

  return 0;
}

