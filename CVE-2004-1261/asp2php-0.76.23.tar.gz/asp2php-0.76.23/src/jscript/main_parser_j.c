#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../globals.h"
#include "../functions.h"

int parse_body_j()
{
char token[TOKENSIZE];
int tokentype;

#ifdef DEBUG
printf("in j_parse_body()\n");
#endif

  in_body++;

  while(1)
  {
    tokentype=gettoken_j(token);

#ifdef DEBUG
printf("parse_body: %d: %s\n",tokentype,token);
#endif

    if (tokentype==0)
    { break; }
      else
    if (tokentype==6)
    {
      fprintf(out,"?>");
      if (in_body==1)
      { break; }
        else
      {
        copyhtml();
      }
    }
      else
    if (strcmp(token,"for")==0)
    { parse_for_j(); }
      else
    if (strcmp(token,"while")==0)
    { parse_while_j(); }
      else
    if (strcmp(token,"if")==0)
    { parse_if_j(); }
      else
    if (tokentype==5)
    { fprintf(out,"\n"); }
      else
    if (strcmp(token,"{")==0)
    {
      fprintf(out,"{");
      parse_body_j();
      fprintf(out,"}");
    }
      else
    if (strcmp(token,"}")==0)
    { break; }
      else
    if (strcasecmp(token,"response")==0)
    { parse_response_j(); }
      else
    if (tokentype==2)
    {
      fprintf(out,"$%s",token);
      tokentype=gettoken_j(token);
      if (tokentype==3)
      {
        fprintf(out,"=");
        eval_expression_j();
      }
    }
  }

  in_body--;

  return 0;
}

void parse_section_j()
{ 
char token[TOKENSIZE];
int tokentype;

  while(1) 
  {
    tokentype=gettoken_j(token);
#ifdef DEBUG
printf("parse_section: %d: %s\n",tokentype,token);
#endif
    if (tokentype==5)
    { fprintf(out,"\n"); }
      else
    { break; }
  }

  if (strcmp(token,"{")==0)
  {
    fprintf(out,"{");
    parse_body_j();
    fprintf(out,"}");
  }
    else
  { eval_expression_j(); }
#ifdef DEBUG
printf("leaving section\n");
#endif
}

