#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globals.h"
#include "functions.h"

int parse_server(char *newtoken)
{
int tokentype;
char token[TOKENSIZE];
char temptoken[LINELENGTH];
char molecule1[LINELENGTH];

  temptoken[0]=0;
  molecule1[0]=0;

  if ((tokentype=gettoken(token))!=14)
  {
    error(token,".","Server");
    return 0;
  }

  tokentype=gettoken(token);

  if (strcasecmp(token,"htmlencode")==0)
  { 
    convert_funct(temptoken,"1",1);
    sprintf(molecule1,"htmlspecialchars(%s)",temptoken);
    strcat(newtoken,molecule1);
  } 
    else
  if (strcasecmp(token,"urlencode")==0)
  { 
    convert_funct(temptoken,"1",1);
    sprintf(molecule1,"rawurlencode(%s)",temptoken);
    strcat(newtoken,molecule1);
  } 
    else
  if (strcasecmp(token,"scripttimeout")==0)
  {
    convert_expression(temptoken);
    sprintf(molecule1,"set_time_limit(%s);\n",temptoken);
    strcat(newtoken,molecule1);
  } 
    else
  if (strcasecmp(token,"mappath")==0)
  {
    convert_funct(temptoken,"1",1);
    sprintf(molecule1,"$DOCUMENT_ROOT.%s",temptoken);
    strcat(newtoken,molecule1);
  } 
    else
  { strcat(newtoken,"// asp2php says 'huh'?: "); eval_expression(" "); }

  return 0;
}

