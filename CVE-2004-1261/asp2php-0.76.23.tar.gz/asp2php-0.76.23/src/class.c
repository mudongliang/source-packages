#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "globals.h"
#include "functions.h"

/*
int show_classes()
{
char *strptr;
int t;

  strptr=classes;

  for (t=0; t<classesptr; t++)
  {
    printf("%d %s\n",t,strptr);
    strptr=strptr+strlen(strptr)+1;
  }
}
*/

int isclass(char *token)
{
char *strptr;
int t;

  strptr=classes;

  for (t=0; t<classesptr; t++)
  {
    if (strcasecmp(strptr,token)==0) return 1;
    strptr=strptr+strlen(strptr)+1;
/* 
    while(strptr[0]!=0) strptr++; 
    strptr++;
*/
  }

  return 0;
}

int addclass(char *token)
{
char *strptr;
int t;

  strptr=classes;

  for (t=0; t<classesptr; t++)
  {
    strptr=strptr+strlen(strptr)+1;
/*
    while(strptr[0]!=0) strptr++; 
    strptr++;
*/
  }

  if ((strptr-classes)+strlen(token)>FUNCTHEAP)
  {
    printf("Error: Function heap for classes is too small.  Please report this to mike@mikekohn.net");
    return 1;
  }

  strcpy(strptr,token);
  classesptr++;

  return 0;
}

int parse_class()
{
char token[TOKENSIZE];
int tokentype;

  tokentype=gettoken(token);

  fprintf(out,"class %s",token);

  addclass(token);

  tokentype=gettoken(token);
  if (tokentype==5)
  {
    fprintf(out,"\n");
  }
    else
  if (strcasecmp(token,"extends")==0)
  {
    tokentype=gettoken(token);
    fprintf(out,"extends %s\n",token);
    tokentype=gettoken(token);
  }

  autoindent();
  fprintf(out,"{\n");
  autoindent();
  inclass++;
 
  indent++; 
  parse_body(0);
  indent--; 

  inclass--;
  autoindent();
  fprintf(out,"} ");

  tokentype=gettoken(token);

  return 0;
}

int parse_new(char *newtoken)
{
char token[TOKENSIZE];
char molecule[LINELENGTH];
int tokentype;

  molecule[0]=0;

  tokentype=gettoken(token);
  convert_funct(molecule,"1,2,3,4,5,6,7,8,9,10,11,12",4);

  sprintf(newtoken,"new %s%s",token,molecule);
  addclass(token);

  return 0;
}

