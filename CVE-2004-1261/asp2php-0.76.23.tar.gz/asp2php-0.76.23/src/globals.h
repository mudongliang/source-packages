#include "stdio.h"
#include "stdlib.h"

#define LINELENGTH 16384
#define TOKENSIZE 1024
#define FUNCTHEAP 8192

char tokenpush[TOKENSIZE];
int tokentypepush;
char tokenpush2[TOKENSIZE];
int tokentypepush2;
FILE *in,*out;
int pushback;
char keywords[80][20];
int indent,line,column;
char objects[80][50];
char objectstype[80][50];
int objectsptr;
int database_type;
int setvar;
int add_isnum,add_session,BOF;
int infunct,functptr,currdeffunct;
char funct[FUNCTHEAP];
char classes[FUNCTHEAP];
char global_uid[70];
char global_passwd[70];
char global_database[70];
char global_address[70];
char global_dsn[70];
char sessionpool[256][200];
int sessionptr;
int classesptr;
int pngs,y2k,casesense,php;
int html,spacer;
char aspextensions[20][10];
int aspextensions_ptr;
int includes;
int javascript;
int loopcount;
int global_asa;
int language;
int in_body;
int fixwin95paths;
int supress;
int inclass;
int flags;

