This is the nanox ui port
tested with versions 0.90

makefile_nanox can be edited to change file localtions
run make -f makefile_nanox in this directory to compile it

nanoxreadme.txt - notes, this file
makefile_nanox - makefile
nanoxwin.cpp - ui lib
