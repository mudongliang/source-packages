/*
  **
  ** dproxy.c
  **
  ** Part of the dproxy package by Matthew Pratt. 
  **
  ** Copyright 1999 Matthew Pratt <mattpratt@yahoo.com>
  **
  ** This software is licensed under the terms of the GNU General 
  ** Public License (GPL). Please see the file COPYING for details.
  ** 
  **
*/

/*
  **
  ** See ChangeLog for version history.
  **
*/

#include "dproxy.h"
#include "cache.h"
#include "conf.h"

/*****************************************************************************/
/* Global variables */
/*****************************************************************************/
/* function protos */
void usage(char * program , char * message );
void sig_child(int signo);
int udp_sock_open(struct in_addr ip, int port);
int udp_packet_write(int sockfd, struct udp_packet *udp_pkt);
int udp_packet_read(int sockfd, struct udp_packet *udp_pkt);
int dns_is_query(struct udp_packet *udp_pkt);
int dns_get_opcode(struct udp_packet *udp_pkt);
void dns_send_reply(int sockfd, struct udp_packet *pkt,char *query);
void dns_reverse_lookup( int sockfd, struct udp_packet *pkt, char *query );

void encode_domain_name(char *name, char encoded_name[BUF_SIZE]);
void decode_domain_name(char name[BUF_SIZE]);
void reverse_domain_name(char name[BUF_SIZE]);
int is_ppp_up();
int is_isdn_up();
int is_connection();

int host_deny (char *filename, char *name);
void sig_hup (int signo);
int get_options( int argc, char ** argv );
/*****************************************************************************/
int main(int argc, char **argv)
{
  int sockfd;
  struct in_addr ip;
  char query_string[BUF_SIZE];
  int numread;
  struct udp_packet pkt;

  /* get commandline options, load config if needed. */
  if(get_options( argc, argv ) < 0 ) {
	  exit(1);
  }

  ip.s_addr = INADDR_ANY;
  sockfd = udp_sock_open( ip, PORT );

  if (config.daemon_mode) {
    /* Standard fork and background code */
    switch (fork()) {
	 case -1:	/* Oh shit, something went wrong */
		debug_perror("fork");
		exit(-1);
	 case 0:	/* Child: close off stdout, stdin and stderr */
		close(0);
		close(1);
		close(2);
		break;
	 default:	/* Parent: Just exit */
		exit(0);
    }
  }

  signal(SIGHUP, sig_hup);

  /* when the child process that handles the actual response exits, we must
	* call wait so that we dont get a zombie */
  signal(SIGCHLD, sig_child);
  while(1){
	 numread = udp_packet_read( sockfd, &pkt );	 
	 if( numread < 0 ) {
		debug("no data ...\n");
		continue;
	 }
	 if(numread < sizeof(struct dns_header)+1 ) {
		debug("got packet with invalid size of %d \n",numread);
		continue;
	 }
	 debug("Dns query from %s port %d\n", inet_ntoa(pkt.src_ip), pkt.src_port);

	 cache_purge( config.purge_time );

	 /* make a child process to handle reply so we can go on taking queries */
	 if( fork() == 0 )break;
  }

  /* child process only here */
  signal(SIGCHLD, SIG_IGN);

  strcpy( query_string, pkt.buf );
  decode_domain_name( query_string );
  debug("query: %s\n", query_string );
  
  /* check if it is a query.... And the type... */
  if (dns_is_query(&pkt)) {
	 switch (dns_get_opcode(&pkt)) { 
	 case 0:
		dns_send_reply( sockfd, &pkt, query_string );
		break;
	 case 1:
		dns_reverse_lookup( sockfd, &pkt, query_string );
		break;
	 default:
		debug("unsupported opcode: %s\n", dns_get_opcode(&pkt));
		break;
	 }
  }
  debug("Done.\n\n");
  return 0;
}
/*****************************************************************************/
int udp_sock_open(struct in_addr ip, int port)
{
  int fd;
  struct sockaddr_in sa;
  
  /* Clear it out */
  memset((void *)&sa, 0, sizeof(sa));
    
  fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

  /* Error */
  if( fd < 0 ){
	 debug_perror("Could not create socket");
	 exit(1);
  } 

  sa.sin_family = AF_INET;
  memcpy((void *)&sa.sin_addr, (void *)&ip, sizeof(struct in_addr));
  sa.sin_port = htons(port);
  
  /* bind() the socket to the interface */
  if (bind(fd, (struct sockaddr *)&sa, sizeof(struct sockaddr)) < 0){
	 debug_perror("Could not bind to port");
	 exit(1);
  }
             
  return(fd);
}

/*****************************************************************************/
int udp_packet_write(int sockfd, struct udp_packet *udp_pkt)
{
  struct sockaddr_in sa;

  /* Zero it out */
  memset((void *)&sa, 0, sizeof(sa));

  /* Fill in the information */
  sa.sin_addr.s_addr = udp_pkt->src_ip.s_addr;
  sa.sin_port = htons(udp_pkt->src_port);
  sa.sin_family = AF_INET;

  return(sendto(sockfd, &udp_pkt->dns_hdr, udp_pkt->len, 0, 
					 (struct sockaddr *)&sa, sizeof(sa)));
}
/*****************************************************************************/
int udp_packet_read(int sockfd, struct udp_packet *udp_pkt )
{
  int numread;
  struct sockaddr_in sa;
  int salen;

  /* Read in the actual packet */
  salen = sizeof(sa);
  if ((numread = recvfrom(sockfd, &udp_pkt->dns_hdr, sizeof(udp_pkt->buf),0,
	(struct sockaddr *)&sa, &salen)) < 0) {
    debug_perror("udp_read_read: recvfrom");
	 debug("udp_read_read: recvfrom\n");
    return -1;
  }

  /* Then record where the packet came from */
  memcpy((void *)&udp_pkt->src_ip, (void *)&sa.sin_addr, sizeof(struct in_addr));
  udp_pkt->src_port = ntohs(sa.sin_port);

  udp_pkt->len = numread;

  return numread;
}
/*****************************************************************************/
/* Checks the QR bit from a dns query
 */
int dns_is_query(struct udp_packet *udp_pkt)
{
	return ( !((udp_pkt->buf[ strlen(udp_pkt->buf) +2 ] & 0x80)/0x80));
}
/*****************************************************************************/
/* Extracts the opcode from a dns query
 */
int dns_get_opcode(struct udp_packet *udp_pkt)
{
	return ( ((udp_pkt->buf[ strlen(udp_pkt->buf) +2 ]) & 0x38)/8);
}
/*****************************************************************************/
/* Change query flag field to response flag field
 */
int dns_set_flags(int err, struct udp_packet *udp_pkt)
{
	/* Keep opcode and rd flags set all others to 0 */
	udp_pkt->dns_hdr.dns_flags=udp_pkt->dns_hdr.dns_flags & 0x7900;
	/* Set QR to response and RA to recursion available */
	udp_pkt->dns_hdr.dns_flags=udp_pkt->dns_hdr.dns_flags | 0x8080;
	if (err) {
		/* Set RCODE to refused.
		   maybe this should be 0x0002=Server failure??? */
		udp_pkt->dns_hdr.dns_flags=udp_pkt->dns_hdr.dns_flags | 0x0005;
	
	}
	return 0;
}
/*****************************************************************************/
/* adds the data to the paket buff and updates the pointer to the end of the 
	packet_buf */
void packet_append(struct udp_packet *pkt, void *data, int data_len)
{
  memcpy( (void*)&pkt->dns_hdr + pkt->len, data, data_len);
  pkt->len += data_len;
}
/*****************************************************************************/
void dns_send_reply(int sockfd, struct udp_packet *pkt, char *query)
{
  struct dns_answer dns_ans;
  struct in_addr ip;
  struct hostent *host;
  char result[BUF_SIZE];

  /* see if we can find host in database */
  if( cache_lookup_name( query, result) ){
	 debug(" -> cache hit: %s\n", result);
	 inet_aton(result, &ip);
  }else if( is_connection() && !host_deny(config.deny_file, query)){
	 /* not found so do lookup */
	 host = gethostbyname( query );
		
	 if( !host ){
		/* host must not exist so reply with a packet saying so */
		debug( " -> host not found\n");
		dns_set_flags(1, pkt);
		udp_packet_write(sockfd, pkt);
		return;
	 }else{	
		/* else add the host we found to the list */
		memcpy(&ip.s_addr, host->h_addr, host->h_length);
		debug(" -> cache miss %s (appending)\n", inet_ntoa( ip ) );
		cache_name_append( query, inet_ntoa( ip ));
	 }
  }else{
         dns_set_flags(1, pkt);
	 udp_packet_write(sockfd, pkt);
	 return;
  }

  dns_set_flags(0, pkt); /* set flags to success */
  pkt->dns_hdr.dns_no_answers  = htons(1);

  dns_ans.dns_name = htons(0xc00c);
  dns_ans.dns_type = htons(1);   //Host name 
  dns_ans.dns_class = htons(1);  //inet
  dns_ans.dns_time_to_live = htons(60);
  dns_ans.dns_data_len = htons(4);

  packet_append( pkt, &dns_ans, sizeof(dns_ans) );
  packet_append( pkt, &ip, sizeof(ip));

  udp_packet_write(sockfd, pkt);	
  
}
/*****************************************************************************/
void dns_reverse_lookup( int sockfd, struct udp_packet *pkt, char *query )
{
  struct dns_answer dns_ans;
  struct hostent *host = NULL;
  struct in_addr ip;
  char *name, encoded_name[BUF_SIZE];
  char result[BUF_SIZE];

  reverse_domain_name(query);

  debug("Reversed: %s\n", query);

  /* see if we can find host in database */
  if( cache_lookup_ip( query, result) ){
	 debug(" <- cache hit: %s\n", result);
	 name = result;
  }else if( is_connection() ){
	 /* do lookup */
	 inet_aton( query, &ip);
	 host = gethostbyaddr( (char *)&ip, sizeof(ip), AF_INET );
	 
	 if( !host ){
		debug( " -> host not found\n");
		herror("herror");
		dns_set_flags(1, pkt);
		udp_packet_write(sockfd, pkt);
		return;
	 }else{	

		name = host->h_name;
		debug(" <- cache miss %s (appending)\n", inet_ntoa( ip ) );
		cache_name_append( name, query);
	 }
  }else{
         dns_set_flags(1, pkt);
	 udp_packet_write(sockfd, pkt);
	 return;
  }

  encode_domain_name( name, encoded_name );

  dns_set_flags(0, pkt); /* set flags to success */
  pkt->dns_hdr.dns_no_answers  = htons(1);

  dns_ans.dns_name = htons(0xc00c);
  dns_ans.dns_type = htons(0x000c); //Domain name pointer
  dns_ans.dns_class = htons(1);     //inet
  dns_ans.dns_time_to_live = htons(60);
  dns_ans.dns_data_len = htons( strlen(encoded_name)+1 );

  packet_append( pkt, &dns_ans, sizeof(dns_ans) );
  
  packet_append( pkt, encoded_name, strlen(encoded_name) +1 );

  udp_packet_write(sockfd, pkt);
}
/*****************************************************************************/
/* this function encode the plain string in name to the domain name encoding 
 * see decode_domain_name for more details on what this function does. */
void encode_domain_name(char *name, char encoded_name[BUF_SIZE])
{
  int i,j,k,n;

  k = 0; /* k is the index to temp */
  i = 0; /* i is the index to name */
  while( name[i] ){

	 /* find the dist to the next '.' or the end of the string and add it*/
	 for( j = 0; name[i+j] && name[i+j] != '.'; j++);
	 encoded_name[k++] = j;

	 /* now copy the text till the next dot */
	 for( n = 0; n < j; n++)
		encoded_name[k++] = name[i+n];
	
	 /* now move to the next dot */ 
	 i += j + 1;

	 /* check to see if last dot was not the end of the string */
	 if(!name[i-1])break;
  }
  encoded_name[k++] = 0;
}
/*****************************************************************************/
/* reverse lookups encode the IP in reverse, so we need to turn it around
 * example 2.0.168.192.in-addr.arpa => 192.168.0.2
 * this function only returns the first four numbers in the IP
 *  NOTE: it assumes that name points to a buffer BUF_SIZE long
 */
void reverse_domain_name(char name[BUF_SIZE])
{
  char temp[BUF_SIZE];
  int i,j,k;
  
  k = 0;
  
  for( j = 0, i = 0; j<3; i++) if( name[i] == '.' )j++;
  for( ; name[i] != '.'; i++) temp[k++] = name[i];
  temp[k++] = '.';

  name[i] = 0;

  for( j = 0, i = 0; j<2; i++) if( name[i] == '.' )j++;
  for( ; name[i] != '.'; i++) temp[k++] = name[i];
  temp[k++] = '.';

  for( j = 0, i = 0; j<1; i++) if( name[i] == '.' )j++;
  for( ; name[i] != '.'; i++) temp[k++] = name[i];
  temp[k++] = '.';

  for( i = 0; name[i] != '.'; i++) temp[k++] = name[i];
  
  temp[k] = 0;

  strcpy( name, temp );
}
/*****************************************************************************/
int is_isdn_up()
{
  FILE *isdninfo_fp;
  char dummy_line[4096];
  char usage_line[4096];
  char *ptr_usage;
  int usage;

  if (!(isdninfo_fp = fopen("/dev/isdninfo", "r"))) {
	 //debug("Can't open /dev/isdninfo\n");
	 return 0;
  }
  
  fgets(dummy_line, 4095, isdninfo_fp);
  fgets(dummy_line, 4095, isdninfo_fp);
  fgets(dummy_line, 4095, isdninfo_fp);
  fgets(usage_line, 4095, isdninfo_fp);
  ptr_usage = usage_line + 7;
  
  sscanf(ptr_usage, "%d" , &usage);
  
  fclose(isdninfo_fp);
  
  if (usage != 0)  {
	 debug("online\n");
	 return 1;
  }else{
	 debug("offline\n");
	 return 0;	   
  }   
}
/*****************************************************************************
 * same as debug_perror but writes to debug output.
 * 
*****************************************************************************/
void debug_perror( char * msg ) {
	debug( "%s : %s\n" , msg , strerror(errno) );
}
/*****************************************************************************/
void debug(char *fmt, ...)
{
#define MAX_MESG_LEN 1024
  
	 va_list args;
	 char text[ MAX_MESG_LEN ];
	 
	 sprintf( text, "[ %d ]: ", getpid());
	 va_start (args, fmt);
	 vsnprintf( &text[strlen(text)], MAX_MESG_LEN - strlen(text), fmt, args);
	 va_end (args);
	 
  if( config.debug_file[0] ){
	 FILE *fp;
	 fp = fopen( config.debug_file, "a");
	 if(!fp){
		syslog( LOG_ERR, "could not open log file %m" );
		return;
	 }
	 fprintf( fp, "%s", text);
	 fclose(fp);
  }

  /** if not in daemon-mode stderr was not closed, use it. */
  if( ! config.daemon_mode ) {
	 fprintf( stderr, "%s", text);
  }

}
/*****************************************************************************/
void sig_child(int signo)
{
  while(wait3(NULL, WNOHANG, 0) > 0);
  signal(SIGCHLD, sig_child);
}
/*****************************************************************************/
/* Queries are encoded such that there is and integer specifying how long 
 * the next block of text will be before the actuall text. For eaxmple:
 *             www.linux.com => \03www\05linux\03com\0
 * This function replaces the query in the array with its dot '.' seperated
 * equivalent. */
void decode_domain_name(char query[BUF_SIZE])
{
  char temp[BUF_SIZE];
  int i, k, len, j;

  i = 0;
  k = 0;
  while( query[i] ){
         len = query[i];
         i++;
         for( j = 0; j<len ; j++)
                temp[k++] = query[i++];
         temp[k++] = '.';
  }
  temp[k-1] = 0;
  strcpy( query, temp );
}
/*****************************************************************************/
int is_ppp_up()
{
  FILE *fp;

  fp = fopen( config.ppp_device_file, "r" );
  if(!fp)return 0;
  fclose(fp);

  return 1;
}
/*****************************************************************************/
int is_connection()
{
  if(!config.ppp_detect)return 1;
  if( is_ppp_up() )return 1;
  if( is_isdn_up() )return 1;
  return 0;
}
/*****************************************************************************/
int host_deny (char *filename, char *name)
{
  FILE *fp;
  char line[256];
  char hostdeny[256];
  
  fp = fopen (filename, "r");
  if (fp) {
	 while (fgets(line, 256, fp)) {
		sscanf (line, "%s", hostdeny);
		if (!(strlen(hostdeny) > strlen(name))) {
		  if (!strcmp(hostdeny,
				    name+strlen(name)-strlen(hostdeny))) {
			 fclose(fp);
			 return 1; // looking up bad things???
		  }
		}
	 }
	 fclose(fp);
  }
	return 0; //no entry or deny file so its okay...
}
/*****************************************************************************/
void sig_hup (int signo)
{
  signal(SIGHUP, sig_hup); /* set this for the next sighup */
  conf_load (config.config_file);
}
/*****************************************************************************
 * print usage informations to stderr.
 * 
 *****************************************************************************/
void usage(char * program , char * message ) {
  fprintf(stderr,"%s\n" , message );
  fprintf(stderr,"usage : %s [-c <config-file>] [-d] [-h] [-P]\n", program );
  fprintf(stderr,"\t-c <config-file>\tread configuration from <config-file>\n");
  fprintf(stderr,"\t-d \t\trun in debug (=non-daemon) mode.\n");
  fprintf(stderr,"\t-P \t\tprint configuration on stdout and exit.\n");
  fprintf(stderr,"\t-h \t\tthis message.\n");
}
/*****************************************************************************
 * get commandline options.
 * 
 * @return 0 on success, < 0 on error.
 *****************************************************************************/
int get_options( int argc, char ** argv ) 
{
  char c = 0;
  int not_daemon = 0;
  int want_printout = 0;
  char * progname = argv[0];

  conf_defaults();

  while( (c = getopt( argc, argv, "c:dhP")) != EOF ) {
    switch(c) {
	 case 'c':
  		conf_load(optarg);
		break;
	 case 'd':
		not_daemon = 1;
		break;
	 case 'h':
		usage(progname,"");
		return -1;
	 case 'P':
		want_printout = 1;
		break;
	 default:
		usage(progname,"");
		return -1;
    }
  }
  
  /** unset daemon-mode if -d was given. */
  if( not_daemon ) {
	 config.daemon_mode = 0;
  }
  
  if( want_printout ) {
	 conf_print();
	 return -1;
  }
  return 0;
}
