/*
  **
  ** cache.c - cache handling routines
  **
  ** Part of the dproxy package by Matthew Pratt. 
  **
  ** Copyright 1999 Matthew Pratt <mattpratt@yahoo.com>
  **
  ** This software is licensed under the terms of the GNU General 
  ** Public License (GPL). Please see the file COPYING for details.
  ** 
  **
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <sys/file.h>

#include "cache.h"
#include "conf.h"

/** function prototypes for private functions*/
static void cache_lock( FILE * , int ); 
static void cache_unlock( FILE * ); 
static int cache_byname(FILE * , char *, char *);
static int leases_byname(char *, char * );  


/*****************************************************************************
 * lock a file.
 *
 * This function blocks until the lock is given to this process.
 * 
 * @param fp an open file pointer
 * @param mode one of LOCK_SH or LOCK_EX (see flock manpage).
 * 
 ****************************************************************************/
static void cache_lock( FILE * fp, int mode ) {
	int fd = -1;
 	fd = fileno(fp);

	debug("cache_lock(%d)\n", fd);

	if( fd < 0 ) {
		debug("cache_lock(): can not get the descriptor for a file");
		return;
	}

	flock( fd , mode );
}
/*****************************************************************************
 * unlock a file.
 *
 * This function releases a lock for this file.
 * 
 * @param fp an open file pointer
 * 
 ****************************************************************************/
static void cache_unlock( FILE * fp ) {
	int fd = -1;

 	fd = fileno(fp);
	debug("cache_unlock(%d)\n", fd );

	if( fd < 0 ) {
		debug("cache_unlock(): can not get the descriptor for a file");
		return;
	}

	/** flush data to the file */
	fflush(fp);

	flock( fd , LOCK_UN);
}
/*****************************************************************************
 *  search for a host by its name.
 *  
 *    This function first searches the cache for an entry. If the entry 
 *    was not found there, we will look into a dhcp "leases" file.
 * 
 *  @arg name  - name to find.
 *  @arg ip    - pointer to a buffer where to put the ip adress.
 *  
 *  @return 0 if an entry was found, 1 if not.
*****************************************************************************/
int cache_lookup_name(char *name, char ip[BUF_SIZE])
{
  FILE * fp;
  
  debug( "cache_lookup_name(%s)\n", name);
  
  /** check the cache */
  if( (fp = fopen( config.cache_file , "r")) != NULL) {
	 int result = 0;
	 cache_lock(fp, LOCK_SH);
	 result = cache_byname(fp,name, ip); 
	 cache_unlock(fp);
	 fclose(fp);   
	 if( result > 0 ) {
		return 1;
	 }
  }
  
  if( config.dhcp_lease_file[0] ) {
	 if(leases_byname(name, ip) > 0) {
		return 1;
	 }
  }
  
  return 0;
}
/*****************************************************************************
 * lookup a hostname in the cache file.
 *
 * This function will not lock the cache ! 
 * 
 *  @arg fp    - open file pointer for the cache file.
 *  @arg name  - name to find.
 *  @arg ip    - pointer to a buffer where to put the ip adress.
 *  
 *  @return 0 if an entry was found, 1 if not.
 *****************************************************************************/
static int cache_byname(FILE * fp, char *name, char ip[BUF_SIZE])
{

  char line[BUF_SIZE];
  char *token;
  int i = 0;

  ip[0] = 0;

  /** make shure we are at the start of the cache */
  rewind(fp);

  while( fgets(line, BUF_SIZE, fp) ){
	 token = strtok( line, " ");
	 if( !strcasecmp( token, name) ){
		token = strtok( NULL, " ");
		while( isalnum(*token) || (*token=='.') )ip[i++] = *token++;
		ip[i] = 0;
		return 1;
	 }
  }
 
  return 0;
}

/*****************************************************************************
 * try the dhcp.leases file
 * format:
 * lease 192.168.1.1 {
 *      starts 4 1999/11/18 03:43:48;
 *      ends 4 1999/11/18 15:43:48;
 *      hardware ethernet 00:00:00:00:00:00;
 *      uid 00:00:00:00:00:00:00;
 *      client-hostname "blahblah";  # or alternatively the following hostname:
 *      hostname "blahblah";
 * }
 *
 * We must browse through the complete file, because the most recent 
 * entry is valid, multiple entries for the same host are possible
*/
static int leases_byname(char *name , char ip[BUF_SIZE]) {

  FILE *fp;
  char line[BUF_SIZE];
  char *token;
  int i = 0;
  char dhcp_ip[20];
  int foundip = 0;

  ip[0] = 0;
  dhcp_ip[0] = 0;

  fp = fopen( config.dhcp_lease_file, "r");
  if(!fp)return 0;
  
  while( fgets(line, BUF_SIZE, fp) ){
	 token = strtok( line, " ");
	 if( !strncasecmp( token, "lease", 5) ){
		token = strtok( NULL, " "); /* ip address */
		i=0;
		while( isalnum(*token) || (*token=='.') )dhcp_ip[i++] = *token++;
		dhcp_ip[i] = 0;
		/* now check, if the hostname matches this ip */
		while(fgets(line, BUF_SIZE, fp) && (line[0] != '}')){
		  token = strtok( line, " ");
		  if(token[0]){ /* not empty */
			 i=1;
			 while( token[i] )token[i-1]=token[i++];
			 token[i-1]=0;
		  }
		  if( (!strncasecmp( token, "client-hostname", 15))
	         ||(!strncasecmp( token, "hostname", 8)) ){
			 token = strtok ( NULL, ";");
			 /* we have now the hostname as "hostname" */
			 if(token[0] && token[1]){ /* not empty */
				i=1;
				while(token[i] != 0)token[i-1]=token[i++];
				token[i-2]=0;
				/* we have now the hostname as hostname */
				if ( !strncasecmp( name, token, strlen(token) ) ){
				  /* we have found the ip address of name */
				  i=0;
				  while( dhcp_ip[i] != 0 ) ip[i] = dhcp_ip[i++];
				  ip[i] = 0;
				  foundip = 1;
				}
			 }
		  }
		}
	 }
  }
  fclose(fp);
  if (foundip) return 1;
  return 0;
}
/*****************************************************************************/
int cache_lookup_ip(char *ip, char result[BUF_SIZE])
{
  FILE *fp;
  char line[BUF_SIZE];
  char *token;
  int i = 0;
  int foundname = 0;
  char dhcp_ip[20];
  
  result[0] = 0;
  dhcp_ip[0] = 0;
  
  fp = fopen( config.cache_file , "r");
  if(!fp)return 0;
  cache_lock(fp,LOCK_SH);
  while( fgets(line, BUF_SIZE, fp) ){
	 strtok( line, " ");
	 token = strtok( NULL, " ");
	 if( !strncasecmp( token, ip, strlen(ip) ) ){
		while( isalnum(line[i]) || (line[i]=='.') )result[i] = line[i++];
		result[i] = 0;
		cache_unlock(fp);
		fclose(fp);
		return 1;
	 }
  }
  cache_unlock(fp);
  fclose(fp);
  
  /* try the dhcp.leases file
   * format:
   * lease 192.168.1.1 {
   *      starts 4 1999/11/18 03:43:48;
   *      ends 4 1999/11/18 15:43:48;
   *      hardware ethernet 00:00:00:00:00:00;
   *      uid 00:00:00:00:00:00:00;
   *      client-hostname "blahblah";   # or alternatively the following hostname:
   *      hostname "blahblah";
   * }
   *
   * We must browse through the complete file, because the most recent entry is valid,
   * multiple entries for the same host are possible
   */
  fp = fopen( config.dhcp_lease_file, "r");
  if(!fp)return 0;
  
  while( fgets(line, BUF_SIZE, fp) ){
	 token = strtok( line, " ");
	 if( !strncasecmp( token, "lease", 5) ){
		token = strtok( NULL, " "); /* ip address */
		i=0;
		while( isalnum(*token) || (*token=='.') )dhcp_ip[i++] = *token++;
		dhcp_ip[i] = 0;
	     /* now check, if this is the desired ip address */
		if( !strncasecmp( ip, dhcp_ip, strlen(dhcp_ip) ) ){
		  while(fgets(line, BUF_SIZE, fp) && (line[0] != '}')){
			 token = strtok( line, " ");
			 if(token[0]){ /* not empty */
				i=1;
				while( token[i] )token[i-1]=token[i++];
				token[i-1]=0;
			 }
			 if( (!strncasecmp( token, "client-hostname", 15))
	           ||(!strncasecmp( token, "hostname", 8)) ){
				token = strtok ( NULL, ";");
				/* we have now the hostname as "hostname" */
				i=1; /* jump over first " */
		   while( (isalnum(token[i]) || (token[i]=='.')) && (token[i]!='"') )result[i-1] = token[i++];
		   result[i-1] = 0;
		   foundname = 1;
			 }
		  }
		}
	 }
  }
  fclose(fp);
  if (foundname) return 1;
  return 0;
}
/*****************************************************************************
* save the name to the list.
* 
*
*****************************************************************************/
void cache_name_append(char *name, char *ip)
{

  FILE *fp;
  char dummy[BUF_SIZE];

  fp = fopen( config.cache_file, "r+");
  if(!fp){
	 debug_perror("Could not open cache file for writing");
	 return;
  }

  /** lock the cache exclusive ! */
  cache_lock(fp,LOCK_EX);
  
  /** check if another process already added this host to the cache */
  if( cache_byname(fp, name, dummy) != 0 ) {
	  fclose(fp);
	  return;
  }

  /** make shure that we at the end of the file. */
  fseek(fp,0,SEEK_END);

  /** write new entry */
  fprintf( fp, "%s %s %ld\n", name, ip, time(NULL) );

  cache_unlock(fp);
  fclose(fp);
}
/*****************************************************************************/
void cache_purge(int older_than)
{
  FILE *in_fp, *out_fp;
  char line[BUF_SIZE];
  char old_cache[1024];
  char *name, *ip, *time_made;

  debug("enter cache_purge()\n");

  in_fp = fopen( config.cache_file , "r");
  if(!in_fp){
	 debug_perror("Could not open old cache file");
	 /*return;*/
  }

  if( in_fp ) {
    cache_lock(in_fp,LOCK_EX);

    sprintf( old_cache, "%s.old", config.cache_file );
    if( rename( config.cache_file, old_cache ) < 0 ){
	 debug_perror("Could not move cache file");
  	 cache_unlock(in_fp);
	 fclose(in_fp);
	 return;
    }
  }

  out_fp = fopen( config.cache_file , "w");
  if(!out_fp){
	 if( in_fp ) {
  	 	cache_unlock(in_fp); 
	 	fclose(in_fp);
	 }
	 debug_perror("Could not open new cache file");
	 return;
  }

  cache_lock(out_fp,LOCK_EX);

  cache_add_hosts_entries(out_fp);

  if( in_fp ) {
    while( fgets(line, BUF_SIZE, in_fp) ){
	 name = strtok( line, " ");
	 ip = strtok( NULL, " ");
	 time_made = strtok( NULL, " ");
	 if(!time_made)continue;
	 if( time(NULL) - atoi( time_made ) < older_than )
		fprintf( out_fp, "%s %s %s", name, ip, time_made );
    }

    cache_unlock(in_fp);
    fclose(in_fp);
    unlink(old_cache);
  }

  cache_unlock(out_fp);
  fclose(out_fp);

}
/*****************************************************************************/
void cache_add_hosts_entries(FILE *cache_file)
{
  FILE *hosts_fp;
  char line[BUF_SIZE];
  char *ip, *name;

  debug("cache_add_hosts_entreies()\n");

  hosts_fp = fopen( config.hosts_file , "r");
  if( !hosts_fp ) {
	debug_perror("can not open 'hosts'-file ");
	return;
  }

  while( fgets(line, BUF_SIZE, hosts_fp) ){
	 line[strlen(line) - 1] = 0; /* get rid of '\n' */
	 ip = strtok( line, " \t");
	 if( ip == NULL ) continue;  /* ignore blank lines */
	 if( ip[0] == '#' )continue; /* ignore comments */
	 while( (name = strtok( NULL, " \t" )) ){
		fprintf( cache_file, "%s %s %ld\n", name, ip, 0L );
	 }
	 
  }
  fclose(hosts_fp);
  debug("cache_add_hosts_entreies(): done\n");
}



