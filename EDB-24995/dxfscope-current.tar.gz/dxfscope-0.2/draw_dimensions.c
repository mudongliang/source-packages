/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"
#include <stdio.h>

void mk_dimension_text(char *dst, char *src, vv x) {
    /* needs to handle interpolation - fixme */
    if(src == NULL || !strncmp(src, ";;", 255) || !strncmp(src, "<>", 255)) {
        sprintf(dst, "%.2lf", x);
    }
    else {
        strncpy(dst, src, 255);
    }
}

void draw_dimension_linear(GC gc, matrix *mt, d_dimension_t *e) {
    /*
     we're given 3 points:
     3=first ext line, 4=2nd ext line, 0=dim line
     must derive point D and slopes.

            |
         b4 +
            |\
            | \
            |  \
            |   \
            |    \
            |     \
            |      \
            |       Xpt D
            | -1/m / \
            |     /   \pt 4
            |    /
            |   /
            |  Xpt 0
            | / \
            |/   \slope m
         bd +     \
            |      \pt 3
            y
           axis

    */

    int solid_dim_line;
    int hor_dim_line;
    int ver_dim_line;
    char *txt;
    vv m; /* slope from c-0 */
    vv b4, bd;        /* y-intercepts */
    vv dist;          /* the point of the whole thing */
    vv twidth;        /* text width */
    vv theight;       /* text height - assumed for now */
    vv needgap;       /* min dist needed in slanted dim line */
    vv xdelta, ydelta;
    point d;
    point p3, p4;     /* offset copies of p3, p4 */
    point ep0, ed;    /* offset copies of p0, d */
    point tip;        /* text insertion point */
    point dg0, dg1;   /* endpoint of dimline at text */
    point tp3, tp4, tep0, ted, tp0, td, tdg0, tdg1, ttip; /* display transformed points */

    txt="ABC";
    theight = 0.25; /* fixme - point to dimstyle */
    solid_dim_line = 0;
    hor_dim_line = 0;
    ver_dim_line = 0;
    //Vdimgap=0.2;

    /* get D - the missing point */

    if(abs(e->p3.x - e->p0.x) < 0.01) { /* ext line vertical */
        d.x = e->p4.x;
        d.y = e->p0.y;
        m = (e->p3.y < e->p0.y) ? INF : -INF;
        hor_dim_line = 1;
    }
    else if(abs(e->p3.y - e->p0.y) < 0.01) { /* ext line hor */
        d.x = e->p0.x;
        d.y = e->p4.y;
        m = 0.00001;
        ver_dim_line = 1;
    }
    else {
        m = (e->p3.y - e->p0.y) / (e->p3.x - e->p0.x);
        if(m == 0.0) /* shouldn't happen, but jic */
            m = 0.000001;

        /* the two y-axis intercepts: */

        b4 = e->p4.y - m * e->p4.x;
        bd = e->p0.y + e->p0.x / m;
    
        d.x = (bd - b4) / (m + 1.0/m);
        d.y = e->p4.y + m * (d.x - e->p4.x);
    }

    dist = distance(d, e->p0);

    //printf("dimexe=%lf dimexo=%lf\n", Vdimexe, Vdimexo);


    /* offset pt 3 and 4 by DIMEXO */

    offset_pt(&e->p3, &p3, m, Vdimexo, e->p0.x, 1);
    offset_pt(&e->p4, &p4, m, Vdimexo, d.x, 1);

    /* offset ends of extension lines by dimexe */
    
    offset_pt(&e->p0, &ep0, m, Vdimexe, e->p3.x, -1);
    offset_pt(&d, &ed, m, Vdimexe, e->p4.x, -1);

    /* text insertion point */

    get_midpoint(&d, &e->p0, &tip);

    twidth = theight * get_text_width(txt, dfont) / 10.0;

    /* make room for text, or move it */

    if(hor_dim_line) {
        if(twidth + 2*Vdimgap + 2*Vdimasz > dist) { /* text+arrows won't fit */
            tip = e->p0;
            tip.x -= twidth/2.0;
            solid_dim_line = 1;
        }
        else {
            dg0 = tip;
            dg1 = tip;
            if(d.x > e->p0.x) {
                dg0.x += Vdimgap+twidth/2.0;
                dg1.x -= Vdimgap+twidth/2.0;
            }
            else {
                dg0.x -= Vdimgap+twidth/2.0;
                dg1.x += Vdimgap+twidth/2.0;
            }
        }
    }
    else if(ver_dim_line) {
        if(theight + 2*Vdimgap + 2*Vdimasz > dist) { /* text+arrows won't fit */
            tip = e->p0;
            tip.x -= theight;
            solid_dim_line = 1;
        }
        else {
            dg0 = tip;
            dg1 = tip;
            if(d.y > e->p0.y) {
                dg0.y += Vdimgap+theight/2.0;
                dg1.y -= Vdimgap+theight/2.0;
            }
            else {
                dg0.y -= Vdimgap+theight/2.0;
                dg1.y += Vdimgap+theight/2.0;
            }
        }
    }
    else { /* slanted */
        ydelta = 0.5 * theight + Vdimgap;
        xdelta = ydelta * m;
        if(needgap > dist) { 
            tip = e->p0; /* need to offset */
            solid_dim_line = 1;
        }
        else {
            dg0 = tip;
            dg1 = tip;
            if(xdelta * (d.x - dg0.x) > 0.0) {
                dg0.x += xdelta;
                dg1.x -= xdelta;
            }
            else {
                dg0.x -= xdelta;
                dg1.x += xdelta;
            }
            if(ydelta * (d.y - dg0.y) > 0.0) {
                dg0.y += ydelta;
                dg1.y -= ydelta;
            }
            else {
                dg0.y -= ydelta;
                dg1.y += ydelta;
            }
        }
    }

    transform(&p3, &tp3, mt);
    transform(&p4, &tp4, mt);
    transform(&ep0, &tep0, mt);
    transform(&ed, &ted, mt);
    transform(&e->p0, &tp0, mt);
    transform(&d, &td, mt); 
    transform(&dg0, &tdg0, mt);
    transform(&dg1, &tdg1, mt);
    transform(&tip, &ttip, mt);

    // tp3, tp4, tp0, tep0 good

    //XDrawLine(dis, win, gc, td.x, td.y, 0,0);
    //XDrawLine(dis, win, gc, ted.x, ted.y, 0,0);

    XDrawLine(dis, win, gc, tp3.x, tp3.y, tep0.x, tep0.y);
    XDrawLine(dis, win, gc, tp4.x, tp4.y, ted.x, ted.y);
    if(solid_dim_line) {
        XDrawLine(dis, win, gc, tp0.x, tp0.y, td.x, td.y);
    }
    else {
        XDrawLine(dis, win, gc, tp0.x, tp0.y, tdg1.x, tdg1.y);
        XDrawLine(dis, win, gc, tdg0.x, tdg0.y, td.x, td.y);
    }
    draw_arrowhead(gc, mt, e->p0, d, 0.0);
    draw_arrowhead(gc, mt, d, e->p0, 0.0);


    mk_dimension_text(wild_text.content, e->manual_text, dist);
    wild_text.height = theight;
    wild_text.insertion_point = tip;
    wild_text.horizontal_justification = HJUST_C;
    wild_text.vertical_justification = VJUST_M;
    wild_text.layer = e->layer;
  
    draw_text(gc, mt, &wild_text);

/*  diagnostic junk:

    if(solid_dim_line) {
         XDrawLine(dis, win, gc, ttip.x, ttip.y, 0, 0);
         printf("solid dim line\n");
    }
    else {
        XDrawLine(dis, win, gc, tdg0.x, tdg0.y, 0, 0);
        XDrawLine(dis, win, gc, tdg1.x, tdg1.y, 0, 0);
        XDrawLine(dis, win, gc, ttip.x, ttip.y, 0, 0);
        printf("not solid dim line\n");
    }
*/
}

void draw_dimension_angular(GC gc, matrix *mt, d_dimension_t *e) {
    point c, p, q, r, s; /*  pq, rs are ext lines, q, s are outside ends */
    point ctr, tctr;
    int solid_dim_arc;
    vv dist, radius;
    vv aq, as, sweep, ar_angle; /* angles */
    vv twidth, theight;
    char msg[256]; /* temproary debug */

    theight = 0.25; // fixme
    get_int_ll(&e->p3, &e->p4, &e->p0, &e->p5, &ctr);
    solid_dim_arc = 1;

    transform(&e->p3, &p, mt);
    transform(&e->p4, &q, mt);
    transform(&e->p6, &c, mt);
    transform(&e->p0, &r, mt);
    transform(&e->p5, &s, mt);
    transform(&ctr, &tctr, mt);

    dist = distance(q, s);
    radius = distance(tctr, s) - Vdimexe;
    aq = line_angle(e->p3, e->p4);
    //as = line_angle(e->p5, e->p0);
    as = line_angle(e->p0, e->p5);
    
    sweep = as - aq;
    //printf("old sweep=%lf\n", sweep);
    if(sweep < 0.0) {
        sweep += 360.0;
    }
    //printf("new sweep=%lf\n", sweep);

    ar_angle = 0.0;
    if(distance(ctr, e->p4) < distance(ctr, e->p3)) { /* backwards ext lines ugh */
        //printf("** flipping arc\n");
        aq += 180.0;
        ar_angle = -180.0;
    }
    else {
        //printf("not flipping arc: c-q=%.1lf  c-p=%.1lf\n", distance(ctr,q), distance(ctr, p));
    }

    XDrawLine(dis, win, gc, p.x, p.y, q.x, q.y);
    XDrawLine(dis, win, gc, r.x, r.y, s.x, s.y);

    draw_arrowhead(gc, mt, e->p4, e->p3, 180.0 + ar_angle);
    draw_arrowhead(gc, mt, e->p5, e->p0, ar_angle);

    wild_text.height = theight;
    mk_dimension_text(wild_text.content, e->manual_text, sweep);
    twidth = theight * get_text_width(wild_text.content, dfont) / 10.0;

    /* simplistically assume worst case: axis of text tan to arc */

    if(twidth + 2*Vdimgap + 2*Vdimasz > dist) { /* text+arrows won't fit */
        solid_dim_arc = 0;
        wild_text.insertion_point = e->p4; // fixme
    }

    if(solid_dim_arc) {
        XDrawArc(dis, win, gc,
            tctr.x-radius, tctr.y - radius, 
            2.0*radius, 2.0*radius, 
            64 * (aq - mt->angle),
            64 * sweep);
    }
    else {
    //    XDrawArc(dis, win, gc,
    //        tctr.x-radius, tctr.y - radius, 
    //        2.0*radius, 2.0*radius, 
    //        64 * (aq - mt->angle),
    //        64 * sweep - twidth/(2*r));
    }

    wild_text.insertion_point = e->p4; // fixme
    wild_text.horizontal_justification = HJUST_C;
    wild_text.vertical_justification = VJUST_M;
    wild_text.layer = e->layer;
  
    draw_text(gc, mt, &wild_text);

    //sprintf(msg, "--q  angle=%.1lf  x=%.1lf y=%.1lf", aq, e->p4.x, e->p4.y);
    //XDrawString(dis, win, text_gc, q.x, q.y, msg, strlen(msg));
    //sprintf(msg, "--s  angle=%.1lf  x=%.1lf y=%.1lf", as, e->p5.x, e->p5.y);
    //XDrawString(dis, win, text_gc, s.x, s.y, msg, strlen(msg));


    //sprintf(msg, "--p  angle=%.1lf  x=%.1lf y=%.1lf", aq, e->p3.x, e->p3.y);
    //XDrawString(dis, win, text_gc, p.x, p.y, msg, strlen(msg));
    //sprintf(msg, "--r  angle=%.1lf  x=%.1lf y=%.1lf", as, e->p0.x, e->p0.y);
    //XDrawString(dis, win, text_gc, r.x, r.y, msg, strlen(msg));


    //XDrawLine(dis, win, gc, 0, 0, c.x, c.y);
    //XDrawLine(dis, win, gc, tctr.x, tctr.y, 0, 0);
   
} 

void draw_arrowhead(GC gc, matrix *mt, point p, point q, vv ang) {
    matrix m, m2, m3;
    point a, b, c, d, e;
    vv w;

    //matrix_translate(&identity_matrix, &m, p.x, p.y);
    //matrix_rotate(&m, &m3, 15);
    //matrix_multiply(&m3, mt, &m2);

    matrix_rotate_vec(&identity_matrix, &m, p, q, ang);
    //matrix_rotate(&identity_matrix, &m, 15);
    matrix_translate(&m, &m3, p.x, p.y);
    matrix_multiply(&m3, mt, &m2);
    

    //matrix_rotate_vec(&m2, &m3, p, q);
    //matrix_rotate(&m2, &m3, 5);
    m3=m2;



    w = Vdimasz/4.0;
    d.x=0; d.y=0;
    transform(&d, &a, &m3);
    d.x=w; d.y=-Vdimasz;
    transform(&d, &b, &m3);
    d.x= -w;
    transform(&d, &c, &m3);

    d.x = 0.0; d.y = -4.0;
    transform(&d, &e, &m3);

    //printf("a=%lf %lf    b=%lf %lf\n", a.x, a.y, b.x, b.y);
    XDrawLine(dis, win, gc, a.x, a.y, b.x, b.y);
    XDrawLine(dis, win, gc, a.x, a.y, c.x, c.y);
    //XDrawLine(dis, win, gc, a.x, a.y, e.x, e.y);
}
    
