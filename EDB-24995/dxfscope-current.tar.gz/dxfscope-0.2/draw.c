/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"

void draw_arc(GC gc, matrix *m, d_ent_t *ent) {
    vv sweep_angle, r;
    point c;
    d_arc_t *e;

    e=(d_arc_t *) ent;
    sweep_angle = e->end_angle - e->start_angle;
    if(sweep_angle < 0.0) {
        sweep_angle += 360.0;
    }
    transform(&e->center, &c, m);
    r = e->radius * sqrt(m->a*m->a + m->b*m->b);
    if(m->a == -m->e) { /* symmetrical */
        mXDrawArc(dis, win, gc, 
            c.x - r, c.y - r,
            2.0*r, 2.0*r,
            64 * (e->start_angle - m->angle),
            64 * sweep_angle);
    } else { 
        mXDrawString(dis, win, gc,
            c.x, c.y, "arc", strlen("arc"));
    }
}
void draw_circle(GC gc, matrix *m, d_ent_t *ent) {
    d_circle_t *e;
    point c;
    vv r;
    vv cx, cy;
    matrix m1;

    e=(d_circle_t *) ent;
    transform(&e->center, &c, m);
    r = e->radius * sqrt(m->a*m->a + m->b*m->b);
    if(m->a == -m->e) { /* symmetrical */
        mXDrawArc(dis, win, gc, 
            c.x - r, c.y - r,
            2.0*r, 2.0*r,
            0, 23040);
    } else { 
        mXDrawString(dis, win, gc,
            c.x, c.y, "circle", strlen("circle"));
    }
}
void draw_dimension(GC gc, matrix *m, d_ent_t *ent) {
    d_dimension_t *e;
    point a;

    e=(d_dimension_t *) ent;

    switch(e->dimension_type & 31) { /* top 3 bits are flags */
    case DIM_TYPE_LINEAR:
    case DIM_TYPE_ALIGNED:
        draw_dimension_linear(gc, m, e);
        break;
    case DIM_TYPE_ANGULAR:
        draw_dimension_angular(gc, m, e);
        break;
    default:
        transform(&e->p0, &a, m);
        //printf("dim:  %f %f  -> %f %f\n", e->p0.x, e->p0.y, a.x, a.y);
        mXDrawString(dis, win, gc, a.x, a.y, "dimension", strlen("dimension"));
        printf("Unhandled dimension type %d\n", e->dimension_type);
    }
}
void draw_line(GC gc, matrix *m, d_ent_t *ent) {
    d_line_t *e;
    point a, b;
    e=(d_line_t *) ent;
    //mXDrawString(dis, win, gc, (int)(ds*e->start_point.x), (int)(ds*e->start_point.y), "lIne", strlen("lIne"));
    /* mXDrawLine(dis, win, gc, (int)(ds*e->start_point.x), (int)(ds*e->start_point.y), (int)(ds*e->end_point.x), (int)(ds*e->end_point.y)); */
    /* mXDrawLine(dis, win, gc,
               TRX(e->start_point), TRY(e->start_point),
               TRX(e->end_point), TRY(e->end_point)
    ); */

    transform(&e->start_point, &a, m);
    transform(&e->end_point, &b, m);
    //printf("drawing line: [%lf %lf] = [%d %d]\n", a.x, a.y, a.x, a.y);
    mXDrawLine(dis, win, gc, a.x, a.y, b.x, b.y);
}
void draw_point(GC gc, matrix *m, d_ent_t *ent) {
    d_point_t *e;
    point a;

    e=(d_point_t *) ent;
    transform(&e->point, &a, m);
    mXDrawPoint(dis, win, gc, a.x, a.y);
}
void draw_solid(GC gc, matrix *m, d_ent_t *ent) {
    d_solid_t *e;
    point a, b, c, d;

    e=(d_solid_t *) ent;
    transform(&e->point_1, &a, m);
    transform(&e->point_2, &b, m);
    transform(&e->point_3, &c, m);
    transform(&e->point_4, &d, m);
    mXDrawLine(dis, win, gc, a.x, a.y, b.x, b.y);
    mXDrawLine(dis, win, gc, b.x, b.y, c.x, c.y);
    mXDrawLine(dis, win, gc, c.x, c.y, d.x, d.y);
    mXDrawLine(dis, win, gc, d.x, d.y, a.x, a.y);

    //mXDrawString(dis, win, gc, (int)(ds*e->point_1.x), (int)(ds*e->point_1.y), "solid", strlen("solid"));
}
void draw_text(GC gc, matrix *m, d_ent_t *ent) {
    d_text_t *e;
    point a;
    matrix m1, m2, m3, m4;
    vv x, y, width, height;

    e=(d_text_t *) ent;
    height = e->height/10.0;
    width = height; /* should use x scale factor */
    x = e->insertion_point.x;
    y = e->insertion_point.y;

    switch(e->horizontal_justification) {
    case HJUST_C:
        x -= width * get_text_width(e->content, dfont)/2.0;
        break;
    case HJUST_R:
        x -= width * get_text_width(e->content, dfont);
        break;
    }

    switch(e->vertical_justification) {
    case VJUST_T:
        y -= e->height;
        break;
    case VJUST_M:
        y -= e->height/2.0;
        break;
    }

    // this was working:
    //matrix_scale(&identity_matrix, &m1, width, height);
    //matrix_translate(&m1, &m2, x, y);
    //matrix_multiply(&m2, m, &m3);
    //mdraw_text(dis, win, gc, &m3, e->content, dfont);

    matrix_scale(&identity_matrix, &m1, width, height);
    matrix_rotate(&m1, &m2, e->rotation_angle);
    matrix_translate(&m2, &m3, x, y);
    matrix_multiply(&m3, m, &m4);
    mdraw_text(dis, win, gc, &m4, e->content, dfont);

}
void draw_trace(GC gc, matrix *m, d_ent_t *ent) {
    d_trace_t *e;
    e=(d_trace_t *) ent;
    mXDrawString(dis, win, gc, (int)(ds*e->point_1.x), (int)(ds*e->point_1.y), "trace", strlen("trace"));
}

void draw_polyline(GC gc, matrix *m, d_ent_t *ent) {
    /* don't really draw anything, just set up for vertices */
    d_polyline_t *e;
    e=(d_polyline_t *) ent;
    have_ltv = 0;
    vbulge = 0.0;
}

void draw_vertex(GC gc, matrix *m, d_ent_t *ent) {
    d_vertex_t *e;
    point tb, tc;  /* transformed points */
    point a, b, c; /* endpoints of arc, center */
    vv radius, tr;
    vv phi;        /* 1/4 of arc angle */
    vv ang_ab;     /* angle from a to b */
    vv ang_ac;     /* angle from a to c */
    vv start_angle;
    vv sweep_angle;
    vv ab;         /* distance from a to b */
    vv sin2phi;
    vv dir;
    char diag[256];

    e=(d_vertex_t *) ent;
    transform(&e->location, &tb, m);

    if(have_ltv) {
        if(vbulge) {
            /* this is quite suboptimal in speed */
            a = lv;
            b = e->location;
            phi = RAD2DEG(atan(vbulge));
            ab = distance(a, b);
            sin2phi = dsin(2.0 * phi);
            radius = ab/(2.0 * sin2phi);
            ang_ab = line_angle(a, b);
            ang_ac = ang_ab + 90.0 - 2.0 * phi;
            c.x = a.x + radius * dcos(ang_ac);
            c.y = a.y + radius * dsin(ang_ac);
            sweep_angle = 4.0 * phi;
            start_angle = ang_ab - 90.0 - 2.0 * phi;
            dir = 1;
            if(sweep_angle < 0.0) {
                sweep_angle *= -1.0;
                start_angle += 180.0;
                start_angle -= sweep_angle;
                dir = -1;
            }

            transform(&c, &tc, m);
            tr = radius * sqrt(m->a*m->a + m->b*m->b);

            //printf("vertex: ax=%.1lf ay=%.1lf bx=%.1lf by=%.1lf bulge=%.3lf  phi=%.1lf dist=%.1lf dsin=%.1lf\n", a.x, a.y, b.x, b.y, e->bulge, phi, ab, sin2phi);

            mXDrawArc(dis, win, gc, 
                tc.x - dir * tr, tc.y - dir * tr,
                fabs(2.0*tr), fabs(2.0*tr),
                64 * (start_angle - m->angle),
                64 * sweep_angle
            );

            /* diagnostic stuff */

            //mXDrawLine(dis, win, basic_gc[1], ltv.x, ltv.y, tb.x, tb.y);
            //mXDrawLine(dis, win, basic_gc[1], ltv.x, ltv.y, tc.x, tc.y);
            //mXDrawLine(dis, win, basic_gc[1], tb.x, tb.y, tc.x, tc.y);

            //sprintf(diag, "c  start=%.1lf  sweep=%.1lf", start_angle, sweep_angle);
            //mXDrawString(dis, win, gc,
            //    tc.x, tc.y, diag, strlen(diag));
            //mXDrawString(dis, win, gc,
            //    ltv.x, ltv.y, "ltv ", strlen("ZZZZ"));
            //mXDrawString(dis, win, gc,
            //    tb.x, tb.y, "b XX", strlen("ZZZZ"));

        }
        else { /* a straight line */
            mXDrawLine(dis, win, gc, ltv.x, ltv.y, tb.x, tb.y);
        }
    }
    vbulge = e->bulge;
    ltv = tb;
    lv = e->location;  /* store untransformed */
    have_ltv = 1;
}

/*
 * Warning - autogenerated by ./gen.pl
 * 
 * No use editing this!
 *
 */
void draw_all(matrix *m, d_ent_t *head) {
    d_ent_t *p;
    d_layer_t *layer;
    for(p=head; p->next; p=p->next) {
        //printf("type %d\n", p->type);
        switch(p->type) {
        case EN_ARC:
            layer=((d_arc_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_arc_t *)p)->thickness);
                draw_arc(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_CIRCLE:
            layer=((d_circle_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_circle_t *)p)->thickness);
                draw_circle(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_DIMENSION:
            layer=((d_dimension_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_dimension_t *)p)->thickness);
                draw_dimension(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_LINE:
            layer=((d_line_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_line_t *)p)->thickness);
                draw_line(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_POINT:
            layer=((d_point_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_point_t *)p)->thickness);
                draw_point(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_POLYLINE:
            layer=((d_polyline_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_polyline_t *)p)->thickness);
                draw_polyline(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_SOLID:
            layer=((d_solid_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_solid_t *)p)->thickness);
                draw_solid(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_TEXT:
            layer=((d_text_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_text_t *)p)->thickness);
                draw_text(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_TRACE:
            layer=((d_trace_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_trace_t *)p)->thickness);
                draw_trace(basic_gc[layer->color % 10], m, p);
            }
            break;
        case EN_VERTEX:
            layer=((d_vertex_t *)p)->layer;
            if(layer->color >= 0) {
                mset_pen(((d_vertex_t *)p)->thickness);
                draw_vertex(basic_gc[layer->color % 10], m, p);
            }
            break;
        }
    }
}

/** hand made: **/

void xset_pen(double thk) {
}

void draw_mode_x() {
    mXDrawLine = XDrawLine;
    mXDrawArc = XDrawArc;
    mXDrawString = XDrawString;
    mXDrawPoint = XDrawPoint;
    mset_pen = xset_pen;
}
