/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"

int ps_XDrawLine(Display *dis, Drawable win, GC gc, int x1, int y1, int x2, int y2) {
    fprintf(psfile, "%d %d moveto %d %d lineto stroke\n", x1, y1, x2, y2);
}
int ps_XDrawArc(Display *dis, Drawable win, GC gc, int x, int y, unsigned int width, unsigned int height, int angle1, int angle2) {
    // fprintf(stderr, "ps_XDrawArc\n");
}

int ps_XDrawString(Display *dis, Drawable win, GC gc, int x, int y, char *s, int length) {
    // fprintf(stderr, "ps_XDrawString\n");
}
int ps_XDrawPoint(Display *dis, Drawable win, GC gc, int x, int y) {
    // fprintf(stderr, "ps_XDrawPoint\n");
}
void ps_set_pen(double thk) {
    // fprintf(stderr, "ps_set_pen: thick=%f  setting %f\n", thk, thk * PSSF);
    fprintf(psfile, "%f setlinewidth\n", thk * PSSF);
}
void draw_mode_ps() {
    mXDrawLine = ps_XDrawLine;
    mXDrawArc = ps_XDrawArc;
    mXDrawString = ps_XDrawString;
    mXDrawPoint = ps_XDrawPoint;
    mset_pen = ps_set_pen;
}
void ps_out() {
    vv sf;
    matrix psm;
    sf = (PSSF * PAGE_HEIGHT)/wwidth;
    // fprintf(stderr, "ps sf=%f\n", sf);
    matrix_scale(&current_matrix, &psm, sf, sf);
    psfile = fopen("plot.ps", "w");
    ps_start(psfile);
    draw_mode_ps();
    draw_all(&psm, ent_head);
    draw_mode_x();
    fprintf(psfile, "showpage\n");
    fclose(psfile);
}
void ps_start(FILE *fh) {
    fprintf(fh, "%!PS-Adobe-1.0\n");
    fprintf(fh, "1 setlinewidth\n");
    fprintf(fh, "/Helvetica findfont 7 scalefont setfont\n");
    fprintf(fh, "90 rotate %f -%f scale\n", 1.0/PSSF, 1.0/PSSF);
}
