/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

typedef struct {
    point a;
    point b;
} zwin_t;

zwin_t zwin;
d_ent_t *ent_head, *ent_tail, *help_list, *layers_list;
matrix current_matrix;
matrix screen_matrix;
matrix prev_matrix[NPREVMATRIX];
matrix help_matrix;
int prev_matrix_index;
matrix m2, m3;
ch_char *dfont;
d_text_t wild_text;
vv vbulge; /* bulge from last vertex */
point ltv; /* last transformed vertex */
point lv;  /* last vertex, untransformed */
int have_ltv;
int draw_check_event; /* should draw check for events */
int layer_start_index; /* first line of layers to display */
int layer_end_index;
int layer_chunk_size;

void print_dumper(d_ent_t *head, FILE *fh);
void draw_all(matrix *m, d_ent_t *head);
void extensify(point *p, point *a, point *b);
void set_extents(d_ent_t *head, point *a, point *b);


void print_matrix(matrix *m);
void matrix_multiply(matrix *a, matrix *b, matrix *c);
void transform(point *src, point *dst, matrix *m);
void matrix_rotate(matrix *src, matrix *dst, vv angle);
void matrix_translate(matrix *src, matrix *dst, vv x, vv y);
void matrix_scale(matrix *src, matrix *dst, vv x, vv y);
void matrix_rotate_vec(matrix *src, matrix *dst, point p, point q, vv a);
void offset_pt(point *a, point *b, vv m, vv dist, vv refx, int dir);
vv distance(point a, point b);
vv line_angle(point a, point b);
int get_int_ll(point *a, point *b, point *c, point *d, point *z);
void get_midpoint(point *a, point *b, point *c);
void draw_arrowhead(GC gc, matrix *mt, point p, point q, vv ang);
vv dsin(vv ang);
vv dcos(vv ang);


void startup();
ch_char *read_font(FILE *fh);
void mdraw_text(Display *dis, Drawable d, GC gc, matrix *m, char *s, ch_char *font);
void mdraw_text_box(Display *dis, Drawable d, GC gc, matrix *m, char *s, ch_char *font);

vv get_text_width(char *s, ch_char *font);
void start_timer();
int finish_timer();

void draw_dimension_linear(GC gc, matrix *m, d_dimension_t *e);
void xset_pen(double thk);
void offset_pt(point *a, point *b, vv m, vv dist, vv refx, int dir);

int dict_clear(dict *d);
int dict_add(dict *d, char *s, void *p);
void *dict_lookup(dict *d, char *s);
void *dict_lookup_or_default(dict *d, char *s);

void *dxfin_lwpolyline(FILE *fh);
void progress_bar(long progress, long total);
void cls();
void draw_help_screen();

int ps_XDrawLine(Display *dis, Drawable win, GC gc, int x1, int y1, int x2, int y2);
int ps_XDrawArc(Display *dis, Drawable win, GC gc, int x, int y, unsigned int width, unsigned int height, int angle1, int angle2);
int ps_XDrawString(Display *dis, Drawable win, GC gc, int x, int y, char *s, int length);
int ps_XDrawPoint(Display *dis, Drawable win, GC gc, int x, int y);
void ps_set_pen(double thk);
void ps_out();

void draw_mode_x();
void draw_mode_ps();
void ps_start(FILE *fh);
int find_click(int x, int y);
