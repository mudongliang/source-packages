/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <string.h>
#include "d.h"

vv pan_ratio;

void mdraw_all();
void zoom_extents();
void zoom_2p(point a, point b);
void zoom_ratio(vv zf);
void test_fscanf();
void test_text();
int handle_event_main(XEvent *rp);
int handle_event_help(XEvent *rp);
int handle_event_layers(XEvent *rp);
point press_point;
point release_point;

int main(int argc, char **argv) {
    char *filename;
    int i;

    if(argc != 2) {
        fprintf(stderr, "Invoke as %s filename\n", argv[0]);
        exit(1);
    }
    filename = argv[1];

    prev_matrix_index = 0;
    pan_ratio = 0.09;
    text = "Loading...";
    wwidth=500;
    wheight=400;
    ds=1.0;
    dc.x=10;
    dc.y=10;
    startup();
    current_matrix = identity_matrix;
    screen_matrix = identity_matrix;

    /* create main gc */

    //green_gc = XCreateGC(dis, win, 0, 0);
    //green="#00FF00";
    //XParseColor(dis, colormap, green, &green_col);
    //XAllocColor(dis, colormap, &green_col);
    //XSetForeground(dis, green_gc, green_col.pixel);


    //black_gc = XCreateGC(dis, win, 0, 0);
    //black="#000000";
    //XParseColor(dis, colormap, black, &black_col);
    //XAllocColor(dis, colormap, &black_col);
    //XSetForeground(dis, black_gc, black_col.pixel);

    text_gc = XCreateGC(dis, win, 0, 0);
    font = XLoadQueryFont(dis, "fixed");
    fontid = font->fid;
    fontwidth=font->per_char->width;
    fontheight=font->per_char->ascent - font->per_char->descent;
    //printf("fontwidth=%d  fontheight=%d\n", fontwidth, fontheight);

    XSetFont(dis, text_gc, fontid);
    XSetForeground(dis, text_gc, green_col.pixel);

    XSelectInput(dis, win, ExposureMask |
                           KeyPressMask |
                           ButtonPressMask |
                           ButtonReleaseMask |
                           StructureNotifyMask
    );
    
    XDrawString(dis, win, text_gc, 20, 20, text, strlen(text));
    XFlush(dis);

    x=50; y=50;

    cls();
    dxfin(filename);
    zoom_extents();
    for(i=0; i<NPREVMATRIX; i++)
        prev_matrix[i] = current_matrix;

    while (1)  {
        draw_check_event = 1;
        XNextEvent(dis, &report);
        switch(mode) {
        case MODE_MAIN:
            handle_event_main(&report);
            break;
        case MODE_HELP:
            handle_event_help(&report);
            break;
        case MODE_LAYERS:
            handle_event_layers(&report);
            break;
        }
    }
    return 0;
}

int change_gc(Display *dis, GC gc, char dashes) {
    unsigned long vmask;
    XGCValues gv;
    vmask = 0;
    if(dashes) {
        vmask |= GCDashList;
        gv.dashes=dashes;
    }
    XChangeGC(dis, gc, vmask, &gv);
    return(0);
}
    
int mputc(char c) {
    int lines, height, lheight, maxchars, need_scroll;
    maxchars = (int) (wwidth/fontwidth);
    lines=4;
    lheight = fontheight*1.3;
    height = lheight * lines;

    if(c == 10) { /* if newline */
        need_scroll=1;
    }
    else {
        need_scroll=0;
        XDrawString(dis, win, text_gc, cursor_x, wheight, &c, 1);
        cursor_x+= fontwidth;
        if(cursor_x > wwidth - fontwidth) {
            need_scroll=1;
        }
    }

    if(need_scroll) {
        XCopyArea(dis, win, win, text_gc, 0, wheight-height,
                  wwidth, height,  0, wheight-height-lheight);
        cursor_x = 0;
        /* blank bottom row */
        XFillRectangle(dis, win, black_gc, 0, wheight-lheight, wwidth, lheight);
    }
    return(1);
}
    
void zoom_extents() {
    vv ysf;
    set_extents(ent_head, &Vextmin, &Vextmax);
    dc.x=Vextmin.x;
    dc.y=Vextmin.y;
    ds=wwidth/(Vextmax.x-Vextmin.x);
    ysf = wheight/(Vextmax.y-Vextmin.y);
    if(ysf < ds)
        ds = ysf;
        // printf("extents: min=%lf %lf  max=%lf %lf    ds=%lf\n", Vextmin.x, Vextmin.y, Vextmax.x, Vextmax.y, ds);
    matrix_translate(&identity_matrix, &m2, 0, 0);
    m2=identity_matrix;
    matrix_scale(&m2, &m3, ds, -ds);
    transform(&Vextmin, &dc, &m3);
    matrix_translate(&m3, &current_matrix, -dc.x, wheight-dc.y);
    mdraw_all();
    XFlush(dis);
}

void zoom_2p(point a, point b) {
    vv ysf;
    dc.x=a.x;
    dc.y=a.y;
    ds=wwidth/(b.x-a.x);
    ysf = wheight/(b.y-a.y);
    if(ysf < ds)
        ds = ysf;
    matrix_translate(&identity_matrix, &m2, 0, 0);
    m2=identity_matrix;
    matrix_scale(&m2, &m3, ds, -ds);
    transform(&a, &dc, &m3);
    matrix_translate(&m3, &current_matrix, -dc.x, wheight-dc.y);
    mdraw_all();
    XFlush(dis);
}

void zoom_2p_screen(point a, point b) { /* screen points */
    matrix m1, m2;
    vv cx, cy, nw, nh, xsf, ysf, sf;
    
    prev_matrix[prev_matrix_index++] = current_matrix;
    if(prev_matrix_index >= NPREVMATRIX) 
        prev_matrix_index = 0;

    cx = (a.x + b.x) / 2.0;
    cy = (a.y + b.y) / 2.0;
    nw = fabs(b.x-a.x);
    nh = fabs(b.y-a.y);
    sf = 1.1;
    if(nw > 7 && nh > 7) {
        xsf = wwidth/nw;
        ysf = wheight/nh;
        sf = xsf > ysf ? ysf : xsf;
    }

    matrix_translate(&current_matrix, &m1, (wwidth/2 - cx), (wheight/2 - cy));
    current_matrix = m1;
    zoom_ratio(sf);
}


void zoom_ratio(vv zf) {
    vv xloss, yloss;

//    xloss = ((wwidth/2.0) * (1.0-zf)) / current_matrix.a;
//    yloss = ((wheight/2.0) * (1.0-zf)) / current_matrix.e;
    xloss = ((wwidth/2.0) * (1.0-zf));
    yloss = ((wheight/2.0) * (1.0-zf));
    //printf("xloss=%lf   yloss=%lf\n", xloss, yloss);
    matrix_scale(&current_matrix, &m2, zf, zf);
    //print_matrix(&current_matrix);    
    matrix_translate(&m2, &current_matrix, xloss, yloss);
    //printf("---\n");
    //print_matrix(&current_matrix);    
    mdraw_all();
}
void mdraw_all() {
    //start_timer();
    XFillRectangle(dis, win, black_gc, 0, 0, wwidth, wheight);
    draw_all(&current_matrix, ent_head);
    XFlush(dis);
    //printf("mdraw_all:");
    //finish_timer();
}
    
void test_fscanf() {
    vv val;
    FILE *fh;

    fh = fopen("test_lv", "r");
    fscanf(fh, "%lf", &val);
    printf("val=%lf\n", val);
}

void test_text() {
    matrix test_matrix;
    m2 = identity_matrix;
    matrix_scale(&m2, &m3, 4, -4);
    matrix_rotate(&m3, &m2, 0);
    matrix_translate(&m2, &test_matrix, 0, 120);
    
    mdraw_text(dis, win, green_gc, &test_matrix, "8675309 piece of rotated monkey", dfont);
}

void start_timer() {
    gettimeofday(&start, NULL);
}

int finish_timer() {
    struct timeval now;
    int ticks;

    gettimeofday(&now, NULL);
    ticks=(now.tv_sec-start.tv_sec)*1000+(now.tv_usec-start.tv_usec)/1000;
    printf("Timer: %d ms\n", ticks);
    return(ticks);
}

int handle_event_main(XEvent *rp) {
    switch  (rp->type) {
    case Expose:   
        mdraw_all();
        break;
    case KeyPress:
        key = XLookupKeysym(&rp->xkey, 0);
        if (key == 'q') {
            exit(0);
        }
        else if (key == 'z') {
            zoom_extents();
        }
        else if (key == 'l') {
            zoom_2p(Vlimmin, Vlimmax);
        }
        else if (key == 'r') {
            XDrawRectangle(dis, win, green_gc, x, y, 10, 10);
                mdraw_all();
        }
        else if (key == 'w') {
            //XDrawArc(dis, win, green_gc, 200, 200, 100, 100, 180*64, 90*64);
            XFlush(dis);
        }
        else if (key == 'd') {
            mode = MODE_LAYERS;
            layer_chunk_size = 30;
            if(layer_start_index < 0) { /* uninitalized */
                layer_start_index = 0;
                layer_end_index = layer_start_index + (layer_chunk_size < layer_dict.n) ? layer_chunk_size: layer_dict.n;
            }
            draw_layers_screen(1);
        }
        else if (key == 65363) {
            matrix_translate(&current_matrix, &m2, -pan_ratio*wwidth, 0);
            current_matrix=m2;
            mdraw_all();
        }
        else if (key == 65364) {
            matrix_translate(&current_matrix, &m2, 0, -pan_ratio*wheight);
            current_matrix=m2;
            mdraw_all();
        }
        else if (key == 65361) {
            matrix_translate(&current_matrix, &m2, pan_ratio*wwidth, 0);
            current_matrix=m2;
            mdraw_all();
        }
        else if (key == 65362) {
            matrix_translate(&current_matrix, &m2, 0, pan_ratio*wheight);
            current_matrix=m2;
            mdraw_all();
        }
        else if (key == 'i') {
            zoom_ratio(1.1);
        }
        else if (key == 'o') {
            zoom_ratio(0.9);
        }
        else if (key == 65535) { /* rotate ccw */
            matrix_translate(&current_matrix, &m2, -wwidth/2.0, -wheight/2.0);
            matrix_rotate(&m2, &m3, 5);
            matrix_translate(&m3, &current_matrix, wwidth/2.0, wheight/2.0);
            mdraw_all();
        }
        else if (key == 65367) { /* rotate cw */
            matrix_translate(&current_matrix, &m2, -wwidth/2.0, -wheight/2.0);
            matrix_rotate(&m2, &m3, -5);
            matrix_translate(&m3, &current_matrix, wwidth/2.0, wheight/2.0);
            mdraw_all();
        }
        else if (key == 'f') {
                //test_fscanf();
                //read_default_font();
                test_text();
        }
        else if (key == 'h') {
            mode = MODE_HELP;
            draw_help_screen();
        }
        else if (key == 'p') {
            ps_out();
        }
        else if(0) { /* don't want this right now */
            if(key == 65293)
                key=10;
            fprintf(stderr, "key=%d\n", key);
            mputc(key);
        }
        else if(key == 65507 || key == 65406 || key == 65511) {
            //fprintf(stderr, "ignoring mod key\n");
            // 65505 = shift
        }
        else {
            fprintf(stderr, "Unknown key=%d\n", key);
            mode = MODE_HELP;
            draw_help_screen();
        }
        break;
        case ConfigureNotify :
            // fprintf(stderr, "ConfigureNotify\n");
            wwidth=rp->xconfigure.width;    
            wheight=rp->xconfigure.height;
            // fprintf(stderr, "wwidth=%d wheight=%d\n", wwidth, wheight);
            mdraw_all();
            break;
        case ButtonPress :
            switch(rp->xbutton.button) {
            case 1:
                press_point.x = rp->xbutton.x;
                press_point.y = rp->xbutton.y;
                XDrawLine(dis, win, green_gc,
                          press_point.x, press_point.y,
                          press_point.x, wheight-1);
                XDrawLine(dis, win, green_gc,
                          press_point.x, press_point.y,
                          wwidth-1, press_point.y);
                break;
            case 2: /* zoom prev */
                prev_matrix_index--;
                if(prev_matrix_index < 0)
                    prev_matrix_index = NPREVMATRIX-1;
                current_matrix = prev_matrix[prev_matrix_index];
                draw_check_event = 0;
                mdraw_all();
                break;
            }
            break;
        
        case ButtonRelease :
            switch(rp->xbutton.button) {
            case 1:
                release_point.x = rp->xbutton.x;
                release_point.y = rp->xbutton.y;
                zoom_2p_screen(press_point, release_point);
                break;
            }
            break;
    }
}

int handle_event_help(XEvent *rp) {
    switch  (rp->type) {
    case Expose:   
        draw_help_screen();
        break;
    case ConfigureNotify :
        wwidth=rp->xconfigure.width;
        wheight=rp->xconfigure.height;
        fprintf(stderr, "wwidth=%d wheight=%d\n", wwidth, wheight);
        draw_help_screen();
        break;
    case KeyPress:
        key = XLookupKeysym(&rp->xkey, 0);
            mode = MODE_MAIN;
            mdraw_all();
            break;
    }
}

int handle_event_layers(XEvent *rp) {
    int click;
    switch  (rp->type) {
    case Expose:
        draw_layers_screen(0);
        break;
    case ConfigureNotify :
        wwidth=rp->xconfigure.width;
        wheight=rp->xconfigure.height;
        fprintf(stderr, "wwidth=%d wheight=%d\n", wwidth, wheight);
        draw_layers_screen(1);
        break;
    case KeyPress:
        key = XLookupKeysym(&rp->xkey, 0);
        if(key == 65366) { // pg dn 
            layer_end_index += layer_chunk_size;
            if(layer_end_index > layer_dict.n)
                layer_end_index = layer_dict.n;
            layer_start_index = layer_end_index - layer_chunk_size;
            if(layer_start_index < 0)
                layer_start_index = 0;
            draw_layers_screen(1);
        }
        else if(key == 65365) { // pg up
            layer_start_index -= layer_chunk_size;
            if(layer_start_index < 0) 
                layer_start_index = 0;
            layer_end_index = layer_start_index + layer_chunk_size;
            if(layer_end_index > layer_dict.n)
            layer_end_index = layer_dict.n;
            draw_layers_screen(1);
        }
        else {
            mode = MODE_MAIN;
            mdraw_all();
            fprintf(stderr, "key=%d\n", key);
        }
        break;
    case ButtonPress:
        switch(rp->xbutton.button) {
            case 1:
                click = find_click(rp->xbutton.x, rp->xbutton.y);
                if(click >= 0)
                //fprintf(stderr, "x=%d y=%d click=%d  color=%d\n", rp->xbutton.x, rp->xbutton.y, click, ((d_layer_t*)(layer_dict.recs[click].p))->color);
                ((d_layer_t*)(layer_dict.recs[click + layer_start_index].p))->color *= -1;
                draw_layers_screen(0);
                break;
        }
        break;
    }
}

