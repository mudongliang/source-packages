#!/usr/bin/perl

# This file is part of DXFscope.
#
# Copyright (c) 2003 Asher Blum <asher@wildspark.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

use strict;

my @ranges = qw( * x y z f a * i );
my %ranges = map(($ranges[ $_ ] => 10 * $_), 0..$#ranges);
sub mprint($);
my $indent = 0;
my $tab = 4;

my %g = ( # global vars
    ACADVER      => '1',
    ANGBASE      => 'a',
    ANGDIR       => 'i',
    ATTDIA       => 'i',
    ATTMODE      => 'i',
    ATTREQ       => 'i',
    AUNITS       => 'i',
    AUPREC       => 'i',
    AXISMODE     => 'i',
    AXISUNIT     => 'p',
    BLIPMODE     => 'i',
    CECOLOR      => '62',
    CELTYPE      => '6',
    CHAMFERA     => 'f',
    CHAMFERB     => 'f',
    CLAYER       => '8',
    COORDS       => 'i',
    DIMALT       => 'i',
    DIMALTD      => 'i',
    DIMALTF      => 'f',
    DIMAPOST     => '1',
    DIMASO       => 'i',
    DIMASZ       => 'f',
    DIMBLK       => '2',
    DIMBLK1      => '1',
    DIMBLK2      => '1',
    DIMCEN       => 'f',
    DIMCLRD      => 'i',
    DIMCLRE      => 'i',
    DIMCLRT      => 'i',
    DIMDLE       => 'f',
    DIMDLI       => 'f',
    DIMEXE       => 'f',
    DIMEXO       => 'f',
    DIMGAP       => 'f',
    DIMLFAC      => 'f',
    DIMLIM       => 'i',
    DIMPOST      => '1',
    DIMRND       => 'f',
    DIMSAH       => 'i',
    DIMSCALE     => 'f',
    DIMSE1       => 'i',
    DIMSE2       => 'i',
    DIMSHO       => 'i',
    DIMSOXD      => 'i',
    DIMSTYLE     => '2',
    DIMTAD       => 'i',
    DIMTFAC      => 'f',
    DIMTIH       => 'i',
    DIMTIX       => 'i',
    DIMTM        => 'f',
    DIMTOFL      => 'i',
    DIMTOH       => 'i',
    DIMTOL       => 'i',
    DIMTP        => 'f',
    DIMTSZ       => 'f',
    DIMTVP       => 'f',
    DIMTXT       => 'f',
    DIMZIN       => 'i',
    DWGCODEPAGE  => 'i',
    DRAGMODE     => 'i',
    ELEVATION    => 'f',
    EXTMAX       => 'p',
    EXTMIN       => 'p',
    FILLETRAD    => 'f',
    FILLMODE     => 'i',
    HANDLING     => 'i',
    HANDSEED     => '5',
    INSBASE      => 'p',
    LIMCHECK     => 'i',
    LIMMAX       => 'p',
    LIMMIN       => 'p',
    LTSCALE      => 'f',
    LUNITS       => 'i',
    LUPREC       => 'i',
    MAXACTVP     => 'i',
    MENU         => '1',
    MIRRTEXT     => 'i',
    ORTHOMODE    => 'i',
    OSMODE       => 'i',
    PDMODE       => 'i',
    PDSIZE       => 'f',
    PELEVATION   => 'f',
    PEXTMAX      => 'p',
    PEXTMIN      => 'p',
    PLIMCHECK    => 'i',
    PLIMMAX      => 'p',
    PLIMMIN      => 'p',
    PLINEGEN     => 'i',
    PLINEWID     => 'f',
    PSLTSCALE    => 'i',
    PUCSNAME     => '2',
    PUCSORG      => 'p',
    PUCSXDIR     => 'p',
    PUCSYDIR     => 'p',
    QTEXTMODE    => 'i',
    REGENMODE    => 'i',
    SHADEDGE     => 'i',
    SHADEDIF     => 'i',
    SKETCHINC    => 'f',
    SKPOLY       => 'i',
    SPLFRAME     => 'i',
    SPLINESEGS   => 'i',
    SPLINETYPE   => 'i',
    SURFTAB1     => 'i',
    SURFTAB2     => 'i',
    SURFTYPE     => 'i',
    SURFU        => 'i',
    SURFV        => 'i',
    TDCREATE     => 'f',
    TDINDWG      => 'f',
    TDUPDATE     => 'f',
    TDUSRTIMER   => 'f',
    TEXTSIZE     => 'f',
    TEXTSTYLE    => '7',
    THICKNESS    => 'f',
    TILEMODE     => 'i',
    TRACEWID     => 'f',
    UCSNAME      => '2',
    UCSORG       => 'p',
    UCSXDIR      => 'p',
    UCSYDIR      => 'p',
    UNITMODE     => 'i',
    USRTIMER     => 'i',
    VISRETAIN    => 'i',
    WORLDVIEW    => 'i',
);
my %v = ( # per-viewport AND global vars
    FASTZOOM     => 'i',
    GRIDMODE     => 'i',
    GRIDUNIT     => 'p',
    SNAPANG      => 'a',
    SNAPBASE     => 'p',
    SNAPISOPAIR  => 'i',
    SNAPMODE     => 'i',
    SNAPSTYLE    => 'i',
    SNAPUNIT     => 'p',
    VIEWCTR      => 'p',
    VIEWDIR      => 'p',
    VIEWSIZE     => 'f',
);

my @ignore_vars = (5, 100, 330);
my @has_custom_dxfin = qw( lwpolyline );

# 'name' is the entity's name - means put it in a dict.
# _refname is a pointer to another entity - means replace it with ptr

my %e = ( 
    line      => { p => [ 'start point', 'end point' ], },
    point     => { p => [ 'point' ], },
    circle    => { p => [ 'center' ],
                   f => [ 'radius' ],
                 },
    arc       => { p => [ 'center' ],
                   f => [ 'radius' ],
                   a => [ 'start angle', 'end angle' ],
                 },
    trace     => { p => [ 'point 1', 'point 2', 'point 3', 'point 4' ], },
    solid     => { p => [ 'point 1', 'point 2', 'point 3', 'point 4' ], },
    text      => { p => [ 'insertion point', 'alignment point' ],
                   f => [ 'height', 'x-scale factor' ],
                   a => [ 'rotation angle', 'oblique angle' ],
                   i => [ 'unused', 'flags', 'horizontal justification',
                          'vertical justification' ],
                   7 => [ 'style_refname' ],
                   1 => [ 'content' ],
                 },
    shape     => { p => [ 'insertion point' ],
                   f => [ 'size', 'relative x-scale factor' ],
                   a => [ 'rotation angle', 'oblique angle' ],
                   2 => [ 'name' ],
                 },
    block     => { p => [ 'insertion point' ],
                   2 => [ 'name' ],
                   3 => [ 'name3' ],
                   1 => [ 'xref pathname' ],
                   i => [ 'block type flag' ],
                 },
    insert    => { p => [ 'insertion point' ], 
                   2 => [ 'block_refname' ],
                   f => [ 'unknown', 'x-scale factor', 'y-scale factor',
                          'z-scale factor', 'column spacing', 'row spacing' ],
                   a => [ 'rotation angle' ],
                   i => [ 'column count', 'row count' ],
                  66 => [ 'attributes follow' ],
                 },
    attdef    => { p => [ 'text start', 'alignment point' ],
                   f => [ 'text height', 'relative x scale factor' ],
                   1 => [ 'default value' ],
                   2 => [ 'tag string' ],
                   3 => [ 'prompt string' ],
                   7 => [ 'style_refname' ],
                   i => [ 'flags', 'text gen flags',
                          'horizontal text justification', 'field length',
                          'vertical text justification' ],
                   a => [ 'text rotation', 'oblique angle' ],
                 },
    attrib    => { p => [ 'text start', 'alignment point' ],
                   f => [ 'text height' ],
                   1 => [ 'value' ],
                   2 => [ 'attribute tag' ],
                   i => [ 'attribute flags', 'text gen flags',
                          'horizontal justification', 'unknown',
                          'vertical justification' ]
                 },
    polyline  => { p => [ 'elevation' ],
                   i => [ 'polyline flag', 'polygon mesh M vertex count',
                          'polygon mesh N vertex count',
                          'smooth surface M density', 
                          'smooth surface N density',
                          'curve/smooth surface type' ],
                   f => [ 'default starting width', 'default ending width' ],
                  66 => [ 'vertices follow' ],
                 },
   lwpolyline => { i => [ 'polyline flag' ],
                   p => [ 'point 1' ],
                 },
    vertex    => { p => [ 'location' ],
                   f => [ 'starting width', 'ending width', 'bulge' ],
                   a => [ 'curve fit tangent direction' ],
                   i => [ 'vertex flags' ],
                 },
   '3dface'   => { p => [ 'point 1', 'point 2', 'point 3', 'point 4' ],
                   i => [ 'invisible edge flags' ],
                 },
    viewport  => { p => [ 'center point' ],  # needs more work
                   f => [ 'width', 'height' ],
                  68 => [ 'viewport status field' ],
                  69 => [ 'viewport id' ],
                  },
    dimension => { 1 => [ 'manual text' ],
                   2 => [ 'dimension geom pseudo-block' ],
                   3 => [ 'dimstyle_refname' ],
                   i => [ 'dimension type' ],
                   p => [ qw( p0 p1 p2 p3 p4 p5 p6 ) ],
                   a => [ 'angle', 'horizontal direction' ],
                   f => [ 'leader length' ],
                 },
    appid     => { 2 => [ 'application name' ],
                   i => [ 'flag' ],
                 },
    dimstyle  => { 2 => [ 'name' ],
                   3 => [ 'dimpost' ],
                   4 => [ 'dimapost' ],
                   5 => [ 'dimblk' ],
                   6 => [ 'dimblk1' ],
                   7 => [ 'dimblk2' ],
                   f => [ qw( dimscale dimasz dimexo dimdli dimexe
                              dimrnd dimdle dimtp dimtm ) ],
                   i => [ qw( flag dimtol dimlim dimtih dimtoh dimse1
                              dimse2 dimtad dimzin ) ],
                 140 => [ 'dimtxt' ],
                 141 => [ 'dimcen' ],
                 142 => [ 'dimtsz' ],
                 143 => [ 'dimaltf' ],
                 144 => [ 'fimlfac' ],
                 145 => [ 'dimtvp' ],
                 146 => [ 'dimtfac' ],
                 147 => [ 'dimgap' ],
                 170 => [ 'dimalt' ],
                 171 => [ 'dimaltd' ],
                 172 => [ 'dimtofl' ],
                 173 => [ 'dimsah' ],
                 174 => [ 'dimtix' ],
                 175 => [ 'dimsoxd' ],
                 176 => [ 'dimclrd' ],
                 177 => [ 'dimclre' ],
                 178 => [ 'dimclrt' ],
                 },
    ltype     => { i => [ 'flag', 'unused', 'alignment_code',
                          'n_dash_length_items' ],
                   f => [ 'pattern_length' ],
                  49 => [ 'dash_length' ],
                   2 => [ 'name' ],
                   3 => [ 'description' ],
                 },
    layer     => { 2 => [ 'name' ],
                  62 => [ 'color' ],
                   6 => [ 'ltype_refname' ],
                   i => [ 'flag' ],
                 },
    style     => { 2 => [ 'name' ],
                   3 => [ 'font filename' ],
                   4 => [ 'big font filename' ],
                   f => [ 'text height', 'width factor', 'last height' ],
                   a => [ 'oblique angle' ],
                   i => [ 'flag', 'text_flag' ],
                 },
    ucs       => { 2 => [ 'name' ],
                   p => [ 'origin', 'x axis direction', 'y axis direction' ],
                   i => [ 'flag' ],
                 },
    view      => { 2 => [ 'name' ],
                   i => [ 'flag', 'view mode' ],
                   f => [ 'height', 'width', 'lens length',
                          'front clip plane', 'back clip plane' ],
                   a => [ 'twist' ],
                 },
    vport     => { 2 => [ 'name' ],
                   i => [ 'flag', 'view mode', 'circle zoom percent',
                          'fast zoom setting', 'ucsicon setting',
                          'snap on/off', 'grid on/off', 'snap style',
                          'snap isopair' ],
                   a => [ 'snap rotation', 'view twist' ],
                   p => [ 'llc', 'urc', 'center', 'snap base', 'snap spacing',
                          'grid spacing', 'view direction', 'view target' ],
                   f => [ 'height', 'aspect ratio', 'lens length',
                          'front clip plane', 'back clip plane' ],
                  68 => [ 'status' ],
                  69 => [ 'id' ],
                },

);

my @drawable = qw( line point circle arc trace solid text dimension polyline vertex );

my %dim = (
    linear    => { p => [ 'dimension line', 'unused', 'unused',
                          'first extension line', 'second extension line' ],
                 },
    angular   => { p => [ 'second extension line start', 'unused', 'unused',
                          'first extension line start',
                          'first extension line end',   
                          'second extension line end',
                          'dimension line arc' ],
                 },
    ang3pt    => { p => [ 'dimension line arc', 'unused', 'unused',
                          'first extension line start',
                          'second extension line end',
                          'angle vertex' ],
                 },
    diameter  => { p => [ 'opposite point', 'unused', 'unused', 'unused',
                          'unused', 'pick point' ],
                 },
    radius    => { p => [ 'center', 'unused', 'unused', 'unused',
                          'unused', 'pick point' ],
                 },
    ordinate  => { p => [ 'unused', 'unused', 'unused',
                          'pick point', 'leader end point' ],
                 },
);

my %funcs = (
    entity_structs => \&print_entity_structs,
    entity_numbers => \&print_entity_numbers,
    globals        => \&print_global_vars,
    sysvars        => \&print_sysvars,
    dxfin          => \&print_dxfin,
    dxfin_handlers => \&print_dxfin_handlers,
    read_section   => \&print_read_section,
    dumper         => \&print_dumper,
    dumper_handlers => \&print_dumper_handlers,
    draw_stubs     => \&print_draw_stubs,
    draw           => \&print_draw_master,
    set_extents    => \&print_set_extents,
    dict_defs      => \&print_dict_defs,
);

#main

add_common_vars();
print_auto_warning();
foreach my $arg(@ARGV) {
    my $func = $funcs{ $arg };
    if(!$func) {
        print STDERR "Invalid: use one or more of:\n";
        print STDERR "$_\n" for sort keys %funcs;
        exit 1;
    }
    &{$func}();
}
#print_entity_structs();
#print_dxfin();
#print_dxfin_handlers();

sub print_entity_structs {
    #foreach my $name(sort keys %e) {
    foreach my $name(ekeys_by_deps()) {
        print "typedef struct {\n";
        print "    void *next;\n";
        print "    void *prev;\n";
        print "    int type;\n";
        foreach my $x(keys %{ $e{ $name } }) {
            my $type = get_type($x);
            $type = 'double' if $type eq 'float';
            foreach my $var_name( @{ $e{ $name }{ $x } }) {
            $var_name =~ s/[^\w]/_/g;
                if($var_name =~ /(.+)_refname$/) {
                    print "    d_${1}_t *$1;\n";
                }
                elsif($type eq 'string') {
                    print "    char ${var_name}\[256];\n";
                }
                else {
                    print "    $type $var_name;\n";
                }
            }
        }
        print "} d_${name}_t;\n\n";
    }
}

sub print_dxfin() {
    print <<EOT;

int dxfin(char *filename) {
    char ent_name[255];
    int opcode;
    d_ent_t *new_ent;
    FILE *fh;
    struct stat mstat;

    fh = fopen(filename, "r");
    if(!fh) {
        fprintf(stderr, "Cannot open file '%s'\\n", filename);
        exit(1);
    }
    fstat(fileno(fh), &mstat);

    ent_head = ent_tail = new_ent = NULL;

    opcode = -1;
    fscanf(fh, "%d", &opcode);
    if(opcode != 0) {
        fprintf(stderr, "first opcode !=0: %d\\n", opcode);
        exit(1);
    }

    while(fscanf(fh, "%s", ent_name)) {
        progress_bar(ftell(fh), mstat.st_size);
        new_ent = (d_ent_t *)(-1);
EOT
    
    my $else = '';
    foreach my $name(sort keys %e) {
        my $ucname = uc $name;
        print qq[        ${else}if(!strncmp(ent_name, "$ucname", 255)) {\n];
        print "            new_ent = (d_ent_t *)dxfin_$name(fh);\n";
        print "          }\n";            
        $else = 'else ';
    }
    print <<EOT;
    else if(!strncmp(ent_name, "SECTION", 255)) {
        read_section(fh);
    }
    else if(!strncmp(ent_name, "EOF", 255)) {
        return(0);
    }
    else {
        /* fprintf(stderr, "Ignoring '%s'\n", ent_name); */
    }
    if(new_ent == NULL) {
        fprintf(stderr, "new_ent '%s' is null\\n", ent_name);
        exit(1);
    }
    else if(new_ent != (d_ent_t *)(-1)) {
        if(ent_head == NULL) { /* first entity */
            ent_head = new_ent;
            ent_tail = new_ent;
            ent_tail->next = NULL;
            ent_head->prev = NULL;
            /* fprintf(stderr, "Created 1st entity\n"); */
        }
        else {
            ent_tail->next = new_ent;
            new_ent->prev = ent_tail;
            ent_tail = new_ent;
            /* fprintf(stderr, "Added another entity, type %d\\n", new_ent->type); */
        }
    }
    }
}
EOT
    
}

sub print_dxfin_handlers {
    foreach my $name(sort keys %e) {
        next if grep (($_ eq $name), @has_custom_dxfin);
        my $have_name = 0; # does this ent have a name?

        mprint <<EOT;
void *dxfin_${name}(FILE *fh) {
    d_${name}_t *e;
    int opcode;
    size_t len;
    char dummy[256];
    e=(d_${name}_t *)malloc(sizeof(d_${name}_t));
    if(!e) {
        fprintf(stderr, "failed to malloc d_${name}_t\\n");
        exit(1);
    }
EOT

        foreach my $x(keys %{ $e{ $name } }) {
            my $default = get_default($x);
            foreach my $var_name( @{ $e{ $name }{ $x } }) {
                $var_name =~ s/[^\w]/_/g;
                if($var_name =~ /(layer)_refname$/) {
                    mprint "e->$1 = (d_${1}_t *)(${1}_dict.recs[0].p);\n";
                    mprint "if(e->$1 == NULL) {\n";
                    mprint qq[fprintf(stderr, "No '$1' entries in dict.\\n");];
                    mprint "exit(1);\n";
                    mprint "}\n";
                    next;
                }
                elsif($var_name =~ /(.+)_refname$/) {
                    mprint "e->$1 == NULL;\n";
                }
                elsif($x eq 'p') {
                    mprint "e->${var_name}.$_ = 0.0;\n" for qw( x y z );
                }
                elsif(get_type($x) eq 'string') { # string
                    mprint "e->${var_name}\[0] = 'x';\n";
                    mprint "e->${var_name}\[1] = 0;\n";
                }
                else {
                    mprint "e->$var_name = $default;\n";
                }
            } # foreach var_name
        } # foreach x

        my $ucname = uc $name;
        mprint <<EOT;
e->type = EN_$ucname;
while(fscanf(fh, "%d", &opcode)) {
    switch(opcode) {
        case 0: /* begin new entity */
            return((void *)e);
            break;

EOT

        foreach my $x(keys %{ $e{ $name } }) {
            my $default = get_default($x);
            my $num = ($x =~ /^\d+$/) ? $x : 7;
            my %n = (); # how many of each kind of var so far
            foreach my $var_name( @{ $e{ $name }{ $x } }) {
                $var_name =~ s/[^\w]/_/g;
                if($x eq 'p') { # point gets three vars
                    foreach my $i(0..2) {
                        my $member = ('x', 'y', 'z')[ $i ];
                        my $group_num = 10 + 10 * $i + $n{ p };
                        mprint "        case $group_num:\n";
                        mprint qq[            fscanf(fh, "%lf", &e->${var_name}.$member);\n];
                        mprint "            break;\n";
                    }
                    $n{ p }++;
                } # if x=p
                else {
                    my $group_num = ($x =~ /^\d+$/) ? $x :
                    $ranges{ $x } + $n{ $x }++;
                    mprint "        case $group_num:\n";
                    if($var_name eq 'name') {
                        mprint "mgets(dummy, fh);";
                        mprint "dict_add(&${name}_dict, dummy, (void *)e);";
                    }
                    elsif($var_name =~ /(.+)_refname$/) {
                        mprint "mgets(dummy, fh);";
                        mprint "e->$1 = (d_${1}_t *) dict_lookup_or_default(&${1}_dict, dummy);";
                    }
                    else {
                        mprint get_fscanf($x, $var_name);
                    }
                    mprint "            break;\n";
                } # else
            } # foreach var_name
        } #foreach x
        foreach my $var_name( @ignore_vars ) {
            next if $e{ $name }{ $var_name }; # in the rare case that we use it
            mprint "case $var_name: ";
        }
        mprint "";
        mprint "mgets(dummy, fh);";
        mprint "break;";

        mprint <<EOT;
        default:
            /* fprintf(stderr, "** Unexpected opcode in $name: %d\\n", opcode); */
            mgets(dummy, fh);
        }
        }
            fprintf(stderr, "** Failed to scan an opcode in $name ftell=[%d] - returning\\n", ftell(fh));
            return((void *)e);
        }
EOT

        } #foreach name
    } #end function

sub print_global_vars {
    print "\n/* System Variables */\n\n";
    pgv2(%g);
    print "\n/* Per-Viewport Variables */\n\n";
    pgv2(%v);
}

sub pgv2 {
    my %vars = @_;
    foreach my $var(sort keys %vars) {
        my $vn = 'V' . lc $var;
        my $type = get_type($vars{ $var });
        $type = 'double' if $type eq 'float';
        if($type eq 'string') {
            printf("%-8.8s %s[256];\n", 'char', $vn);
        }
        else {
            printf("%-8.8s %s;\n", $type, $vn);
        }
    }
}
        

sub get_type {
    my $x = shift;
    if($x >= 62 && $x <= 69) {
        return 'int';
    }
    my @gcr = (
        [ 0, 9, 'string' ],
        [ 10, 59, 'float' ],
        [ 60, 79, 'int' ],
        [ 100, 100, 'string' ],
        [ 140, 147, 'float' ],
        [ 170, 178, 'int' ],
        [ 210, 239, 'float' ],
        [ 330, 330, 'string' ],
        [ 999, 999, 'string' ],
        [ 1010, 1059, 'float' ],
        [ 1060, 1079, 'int' ],
    );
    if($x =~ /^\d+$/) {
        for(@gcr) {
            return $_->[ 2 ] if
            $x >= $_->[ 0 ] &&
            $x <= $_->[ 1 ];
        }
    }
    my %type = (
        p => 'point',
        f => 'float',
        i => 'int',
        a => 'float',
    );
    $type{ $x } || 'string';
}
                 
sub get_default {
    my $x = shift;
    if($x >= 62 && $x <= 69) {
        return '0';
    }
    my %default = (
        p => '{0.0, 0.0, 0.0}',
        f => '0.0',
        i => '0',
        a => '0.0',
    );
    return $default{ $x } if defined($default{ $x });
    my $type = get_type($x);
    my %default2 = (
        int => '0',
        float => '0.0',
        string => 'NULL',
    );
    $default2{ $type };
}

sub mprint($) {
    my $s = shift;
    my @lines = split(/\n/, $s);
    for(@lines) {
        s/^\s*//;
        $indent -= $tab if /^[})]/ or /^case/ or /^default/;
        print ' ' x $indent;
        print;
        print "\n";
        $indent += $tab if /[({]\s*$/ or /^case/ or /^default/;
    }
}

sub print_read_section() {
    # fixme - needs refactored - very comb code.
    mprint <<EOT;
    void read_section(FILE *fh) {
    int opcode, opcode2, have_varname;
    size_t len;
    char varname[256], dummy[256];
    char *varname2; /* points past the \$ if any */

    varname[0] = 0;
    have_varname=0;
    while(fscanf(fh, "%d", &opcode)) {
        //fprintf(stderr, "opcode=%d\\n", opcode);
        if(opcode==0) {
            return;
        }
        else if(opcode==9) {
            //fprintf(stderr, "getting varname\\n");
            mgets(varname, fh);
            have_varname=1;
            continue;
        }
        else if(opcode==2) {
            //fprintf(stderr, "getting section name\\n");
            mgets(dummy, fh);
            //fprintf(stderr, "section name='%s', getting new opcode\\n", dummy);
            have_varname=0;
            if(strncmp(dummy, "HEADER", 255)) { /* any other kind we skip */
                //fprintf(stderr, "skipping to next entity\\n");
                while(fscanf(fh, "%d", &opcode)) {
                    if(opcode==0) {
                        return;
                    }
                    mgets(dummy, fh);
                    //fprintf(stderr, "read_section skipping '%d' '%s'\\n", opcode, dummy);
                }
            }
            continue;
        }


        if(*varname == '\$') {
            varname2 = varname+1;
        }
        else {
            varname2 = varname;
        }
 
        //fprintf(stderr, "got varname: '%s'\\n", varname2);
EOT
    my %vg = (%g, %v);
    my $else = '';
    foreach my $x(sort keys %vg) {
        mprint qq[${else}if(!strncmp(varname2, "$x", 255)) {\n]; 
        mprint qq[switch(opcode) {\n];
        my $vn = 'V' . lc($x);

        if($vg{ $x } eq 'p') { # point gets three vars
            foreach my $i(0..2) {
                my $member = ('x', 'y', 'z')[ $i ];
                my $group_num = 10 + 10 * $i;
                mprint "        case $group_num:\n";
                mprint qq[            fscanf(fh, "%lf", &$vn.$member);\n];
                mprint "            break;\n";
            }
        }
        elsif($vg{ $x } eq 'i') {
                    my $group_num = $ranges{ i };
                    mprint "        case $group_num:\n";
                    mprint qq[            fscanf(fh, "%d", &$vn);\n];
                    mprint "            break;\n";
                }
        elsif($vg{ $x } >= 62 && $vg{ $x } <= 69) {
                    my $group_num = $vg{ $x };
                    mprint "        case $group_num:\n";
                    mprint qq[            fscanf(fh, "%d", &$vn);\n];
                    mprint "            break;\n";
                }
        elsif($vg{ $x } eq 'f' || $vg{ $x } eq 'a') {
            my $group_num = $ranges{ $vg{ $x } };
            mprint "        case $group_num:\n";
            mprint qq[            fscanf(fh, "%lf", &$vn);\n];
            mprint "            break;\n";
        }
        elsif($vg{ $x } > 0 && $vg{ $x } < 10) { # a string
            my $group_num = $vg{ $x };
            mprint "        case $group_num:\n";
            mprint qq[            mgets($vn, fh);\n];
            mprint "            break;\n";
        }
        else {
            die "Don't know what to do with '$x' = '$vg{ $x }'";
        }
        mprint <<EOT;
        default:
        fprintf(stderr, "Invalid group '%d' found in variable '$x'\\n", opcode);
        mgets(dummy, fh);
        //exit(1); 
        }
        }
EOT
    $else = 'else ';
    }
    mprint <<EOT;
    else { /* unknown */
        mgets(dummy, fh);
        fprintf(stderr, "Unknown variable: '%s' = '%s'\\n", varname2, dummy);
    }
EOT
    mprint "}\n}\n";
}

sub print_dumper {
    mprint <<EOT;
    void print_dumper(d_ent_t *head, FILE *fh) {
    d_ent_t *p;
    int type;

    for(p=head; p->next; p=p->next) {
        printf("type %d\\n", p->type);
        switch(p->type) {
EOT
    foreach my $x(sort keys %e) {
        my $ucx = uc $x;
        mprint "case EN_$ucx:\n";
        mprint "dump_$x(p, fh);\n";
        mprint "break;\n";
    }
    mprint <<EOT;
    default:
    fprintf(stderr, "Unknown entity type: %d\\n", p->type);
    exit(1);
    } /* close sw */
    } /* close for */
    } /* close function */
EOT
}

sub print_dumper_handlers {
    foreach my $x(sort keys %e) {
        mprint <<EOT;
        void dump_$x(d_ent_t *ent, FILE *fh) {
            d_${x}_t *e;

            e = (d_${x}_t *)ent;
            fprintf(fh, "%s\\n", "$x");
            fprintf(fh, "%s\\n", "==========");
EOT
        foreach my $kind(sort keys %{ $e{ $x } }) {
            foreach my $var(@{ $e{ $x }{ $kind } }) {
                $var =~ s/[^\w]/_/g;
                if($var =~ /(.+)_refname$/) {
                    mprint qq[fprintf(fh, "%-20.20s (ptr)\\n", "$1");];
                }
                else {
                    my $fprintf = get_fprintf($kind, $var);
                    mprint <<EOT;
                    fprintf(fh, "%-20.20s: ", "$var");
                    $fprintf;
                    fprintf(fh, "\\n");
EOT
                }
            } # each var
        } # each kind
        mprint <<EOT;
        fprintf(fh, "\\n");
        } /* end c func */
EOT
    } # each x
} # func

sub print_entity_numbers {
    my $i = 0;
    for(sort keys %e) {
        my $name = uc $_;
        mprint "#define EN_$name $i\n";
        $i++;
    }
    mprint "\n";
}

sub print_draw_stubs {
    foreach my $x(sort @drawable) {
        my $point = $e{ $x }{ p }[ 0 ];
        $point =~ s/[^\w]/_/g;
        mprint <<EOT;
        void draw_$x(GC gc, d_ent_t *ent) {
        d_${x}_t *e;
        e=(d_${x}_t *) ent;
        XDrawString(dis, win, gc, (int)(ds*e->$point.x), (int)(ds*e->$point.y), "$x", strlen("$x"));
        }

EOT
    }
}

sub print_draw_master {
    mprint <<EOT;
void draw_all(matrix *m, d_ent_t *head) {
    d_ent_t *p;
    d_layer_t *layer;
    for(p=head; p->next; p=p->next) {
        printf("type %d\\n", p->type);
        switch(p->type) {
EOT
    foreach my $x(sort @drawable) {
        my $ucx = uc $x;
        mprint "case EN_$ucx:\n";
        mprint "layer=((d_${x}_t *)p)->layer;\n";
        mprint "if(layer->color >= 0) {\n";
        mprint "mset_pen(((d_${x}_t *)p)->thickness);\n";
        mprint "draw_$x(basic_gc[layer->color % 10], m, p);\n";
        mprint "}\n";
        mprint "break;\n";
    }
    mprint "}\n}\n}\n";
}

sub print_set_extents {
    mprint <<EOT;
void set_extents(d_ent_t *head, point *a, point *b) {
    d_ent_t *p;

    /* a is min, b is max */
    have_first_point = 0;
    b->x = 1.0;
    b->y = 1.0;
    b->z = 1.0;

    a->x = 0.0;
    a->y = 0.0;
    a->z = 0.0;

    for(p=head; p; p=p->next) {
        switch(p->type) {
EOT
    foreach my $x(sort @drawable) {
        my $points = $e{ $x }{ p } or next;
        my $ucx = uc $x;
        mprint "case EN_$ucx:\n";
        foreach my $point(@$points) {
            $point =~ s/[^\w]/_/g;
            mprint "extensify(&(((d_${x}_t *)p)->$point), a, b);\n";
        }
        mprint "break;\n";
    }
    mprint "}\n}\n}\n";
}

sub print_dict_defs {
    mprint "/* dictionaries for entities looked up by name */";
    foreach my $x(sort keys %e) {
        foreach my $var_name(keys %{ $e{ $x } }) {
            if(grep(($_ eq 'name'), @{ $e{ $x }{ $var_name } })) {
                mprint "dict ${x}_dict;";
            }
        }
    }
    mprint "";
}
    
sub add_common_vars {
    my %a = (
        6 => [ 'ltype_refname' ],
        8 => [ 'layer_refname' ],
       62 => [ 'color number' ],
       39 => [ 'thickness' ],
    );
#    foreach my $x(keys %e) {
     foreach my $x(@drawable) {
        foreach my $y(keys %a) {
            next if $a{ $y }[ 0 ] eq "${x}_refname"; # don't point to self
            $e{ $x }{ $y } = $a{ $y };
        }
    }
}

sub get_fscanf {
    my($t, $name) = @_;
    my $type = get_type($t);
    my %scan = (
        int    => qq[fscanf(fh, "%d", &e->${name});\n],
        float  => qq[fscanf(fh, "%lf", &e->${name});\n],
        string => qq[mgets(e->${name}, fh);\n],
    );
    return $scan{ $type } or die "No type found for '$t' / '$type'";
}

sub get_fprintf {
    my($t, $name) = @_;
    if($t eq 'p') {
        return qq[fprintf(fh, "%lf %lf %lf", e->${name}.x, e->${name}.y, e->${name}.z);];
    }
    my $type = get_type($t);
    my %scan = (
        int    => qq[fprintf(fh, "%d", e->${name});],
        float  => qq[fprintf(fh, "%lf", e->${name});],
        string => qq[fprintf(fh, "%s", e->${name});],
    );
    return $scan{ $type } or die "No type found for '$t' / '$type'";
}

sub print_auto_warning {
    print <<EOT;
/*
 * Warning - autogenerated by $0
 * 
 * No use editing this!
 *
 */
EOT
}

sub ekeys_by_deps { # keys %e sorted by dependencies
    my(@first, @middle, @last);
    
    foreach my $x(sort keys %e) {
        my $has_name = 0;
        my $has_ref = 0;
        foreach my $y(sort keys %{ $e{ $x } }) {
            foreach my $name(@{ $e{ $x }{ $y } }) {
                $has_name = 1 if $name eq 'name';
                $has_ref = 1 if $name =~ /refname$/;
            }
        }
        if($has_name && !$has_ref) {
            push @first, $x;
        }
        elsif($has_ref && !$has_name) {
            push @last, $x;
        }
        else {
            push @middle, $x;
        }
    }
    (@first, @middle, @last);
}
