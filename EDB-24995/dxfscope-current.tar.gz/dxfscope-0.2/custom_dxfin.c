/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"

void *dxfin_lwpolyline(FILE *fh) {
    d_polyline_t *e;
    d_vertex_t *v;
    d_ent_t *tail;
    int opcode;
    size_t len;
    char dummy[256];
    e=(d_polyline_t *)malloc(sizeof(d_polyline_t));
    if(!e) {
        fprintf(stderr, "failed to malloc d_polyline_t\n");
        exit(1);
    }
    //e->point_1.x = 0.0;
    //e->point_1.y = 0.0;
    //e->point_1.z = 0.0;
    e->polyline_flag = 0;
    e->type = EN_POLYLINE;
    e->layer = (d_layer_t *)(layer_dict.recs[0].p);

    tail = (d_ent_t *)e;
    while(fscanf(fh, "%d", &opcode)) {
        switch(opcode) {
        case 0: /* begin new entity */
            return((void *)e);
            break;
        case 8:
            mgets(dummy, fh);
            e->layer = (d_layer_t *) dict_lookup_or_default(&layer_dict, dummy);
            break;
        case 10:
            v=(d_vertex_t *)malloc(sizeof(d_vertex_t));
            v->type = EN_VERTEX;
            tail->next = v;
            v->prev = tail;
            v->next = NULL;
            tail = (d_ent_t *)v;
            v->layer = e->layer;
            fscanf(fh, "%lf", &v->location.x);
            break;
        case 20:
            if(v)
                fscanf(fh, "%lf", &v->location.y);
            break;
        case 30:
            if(v)
                 fscanf(fh, "%lf", &v->location.z);
            break;
        case 70:
            fscanf(fh, "%d", &e->polyline_flag);
            break;
        case 5: 
        case 100: 
        case 330: 
            mgets(dummy, fh);
            break;
        default:
            /* fprintf(stderr, "** Unexpected opcode in lwpolyline: %d\n", opcode); */
            mgets(dummy, fh);
        }
    }
    fprintf(stderr, "** Failed to scan an opcode in lwpolyline - returning\n");
    return((void *)tail);
}
