/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#define __USE_GNU
#include <math.h>
#ifndef M_PIl
#define MPIl M_PI
#endif
#include <float.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


#define DRAW_CHUNK_SIZE 50
#define DICT_SIZE 500
#define MAX_STRING 256
#define INF DBL_MAX
#define TRX(t) (int)(ds*(t.x-dc.x))
#define TRY(t) (wheight-((int)(ds*(t.y-dc.y))))
//#define TRY(t) (int)(ds*(t.y-dc.y))
#define TRU(t) (unsigned int)((ds)*t)
#define DEG2RAD(a) (M_PIl * (a) / 180.0)
#define RAD2DEG(a) (180.0 * (a) / M_PIl)
#define MODE_MAIN 0
#define MODE_HELP 1
#define MODE_LAYERS 2
#define NPREVMATRIX 5
#define PAGE_WIDTH 8.5*72
#define PAGE_HEIGHT 11*72
/* since X is integer, and postscript is floating point, how many subdivisions
   per int in postscript out? */
#define PSSF 100.0
#define NCLICKABLES 300

int dxfin(char *filename);
int change_gc(Display *dis, GC gc, char dashes);
int mputc(char c);

Display *dis;
Window win;
XEvent report;
GC green_gc, black_gc, text_gc;
XColor green_col, black_col;
GC basic_gc[10];
XColor basic_clr[10];
Colormap colormap;

XFontStruct *font;
Font fontid;
char *text;
XGCValues gv;

int wwidth, wheight;
int fontwidth, fontheight;

int ltscale;

int x,y;
int key;
int cursor_x;

char *green;
char *black;


typedef double vv;
typedef struct {
    void *next;
    void *prev;
    int type;
} d_ent_t;

typedef struct {
    vv x;
    vv y;
    vv z;
} point;

/* matrix = | a d 0 |
            | b e 0 |
            | c f 1 |
*/

typedef struct {
    vv a;
    vv b;
    vv c;
    vv d;
    vv e;
    vv f;
    vv angle;
} matrix;

/* character parts: a ch_part can be a ch_line or a ch_arc */

typedef struct {
    char part_type;
    //ch_part *next;
    void *next;
} ch_part;

typedef struct {
    char part_type;
    ch_part *next;
    vv x0;
    vv y0;
    vv x1;
    vv y1;
} ch_line;

typedef struct {
    char part_type;
    ch_part *next;
    vv x;
    vv y;
    vv r;
    vv a0;
    vv a1;
} ch_arc;

typedef struct {
    ch_part *head;
    vv width;
} ch_char;

/* dictionary parts: a dict has many dict_recs, each pointing to something */

typedef struct {
    char name[MAX_STRING];
    void *p;
} dict_rec;

typedef struct {
    int n;
    dict_rec recs[DICT_SIZE];
} dict;

/* const matrix identity_matrix = { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0 }; */

typedef struct {
    int x;
    int y;
    int size; /* if size=0, end of list */
} clickable;

vv ds; /* draw scale */
point dc; /* viewport corner */
matrix identity_matrix;
int have_first_point;
struct timeval start;
int mode;
clickable clickables[NCLICKABLES];

FILE *psfile; /* filehandle for postscript output */
/* function pointers that can point to Xlib functions or postscript */
int(*mXDrawLine)(Display*, Drawable, GC, int, int, int, int);
int(*mXDrawArc)(Display*, Drawable, GC, int, int, unsigned int, unsigned int, int, int);
int(*mXDrawString)(Display*, Drawable, GC, int, int, char*, int);
int(*mXDrawPoint)(Display*, Drawable, GC, int, int);
void(*mset_pen)(double thk);
