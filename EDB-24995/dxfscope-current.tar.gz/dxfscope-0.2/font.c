/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"

int skip_to_eol(FILE *fh) {
    int c;
    while((c=fgetc(fh)) != EOF)
        if(c == 10)
            return 1;
    return 0;
}

void mdraw_text_box(Display *dis, Drawable d, GC gc, matrix *m, char *s, ch_char *font) {
    point a, b, p0, p1;

    a.x=0;
    a.y=0;
    b.x=get_text_width(s, font);
    b.y=0;
    transform(&a, &p0, m);
    transform(&b, &p1, m);
    mXDrawLine(dis, d, gc, p0.x, p0.y, p1.x, p1.y);

    a.y += 10.0;
    b.y += 10.0;
    transform(&a, &p0, m);
    transform(&b, &p1, m);
    mXDrawLine(dis, d, gc, p0.x, p0.y, p1.x, p1.y);
}


vv get_text_width(char *s, ch_char *font) {
    vv w;
    char *p;

    w = 0.0;
    for(p=s; *p; p++) { /* each char */
        w += font[*p].width + 1.4;
    }
    return w;
}

void mdraw_text(Display *dis, Drawable d, GC gc, matrix *m, char *s, ch_char *font) {
    char *p;
    ch_part *q;
    ch_line *cl;
    ch_arc *ca;
    matrix m2, m3, m4;
    point a, b, p0, p1;
    vv r, sweep_angle;

    m2 = *m;
    for(p=s; *p; p++) { /* each char */
        //printf("font: char %c\n", *p);
        for(q=font[*p].head; q != NULL; q=q->next) {
            //printf("ch_part\n");
            if(q->part_type == 'L') {
                cl = (ch_line *)q;
                //printf("font: line from %lf %lf  to %lf %lf\n", cl->x0, cl->y0, cl->x1, cl->y1);
                p0.x = cl->x0;
                p0.y = cl->y0;
                p1.x = cl->x1;
                p1.y = cl->y1;
                transform(&p0, &a, &m2);
                transform(&p1, &b, &m2);
                mXDrawLine(dis, d, gc, a.x, a.y, b.x, b.y);
            }
            else if(q->part_type == 'A') {
                ca = (ch_arc *)q;
                p0.x = ca->x;
                p0.y = ca->y;
                transform(&p0, &a, &m2);
                sweep_angle = ca->a1 - ca->a0;
                if(sweep_angle < 0.0) {
                    sweep_angle += 360.0;
                }


                if(m->a == -m->e) { /* symmetrical */
                    r = ca->r * sqrt(m->a*m->a + m->b*m->b);
                    //printf("drawing text arc: a0=%lf a1=%lf sweep=%lf\n", ca->a0, ca->a1, sweep_angle);
                    mXDrawArc(dis, d, gc,
                        a.x - r, a.y - r,
                        2.0*r, 2.0*r,
                        64 * (ca->a0 - m->angle),
                        64 * sweep_angle);
                }
            }
        }
        //printf("  width=%lf m2c=%lf  m2a=%lf ", font[*p].width, m2.c, m2.a);
        //m2.c += font[*p].width * m2.a; 
        //matrix_translate(&m2, &m3, font[*p].width * m2.a, 0);
        matrix_translate(&identity_matrix, &m3, 1.4 + font[*p].width, 0);
        matrix_multiply(&m3, &m2, &m4);
        m2=m4;
        //printf("now m2c = %lf\n", m2.c);
    }
}

ch_char *read_font(FILE *fh) {
    int c, currchar, qty, i;
    vv x0, y0, x1, y1, r, angle0, angle1, width;
    ch_part *head, *tail;
    ch_arc *ca;
    ch_line *cl;
    ch_char *alpha;

    alpha = malloc(256 * sizeof(ch_char));

    for(i=0; i<256; i++) {
        alpha[i].head=NULL;
        alpha[i].width=4.0;
    }

    currchar = 'A';
    head=NULL;
    tail=NULL;
   

    while((c=fgetc(fh)) != EOF) {
        switch(c) {
        case '#' : case ' ' : 
            skip_to_eol(fh);
            break;
        case '[' :
            currchar = fgetc(fh);
            /* next comes # lines, which we don't use */
            skip_to_eol(fh);
            alpha[currchar].width = (currchar == ' ') ? 3.0 : 0.0;

            tail=NULL;
            break;
        case 'L' :
            cl = malloc(sizeof(ch_line));
            cl->next=NULL;
            if(tail==NULL) {
                tail=(ch_part *)cl;
                head=(ch_part *)cl;
                alpha[currchar].head=head;
                tail->part_type = 'L';
            }
            else {
                tail->next=(ch_part *)cl;
                tail=(ch_part *)cl;
            }
            tail->part_type = 'L';

            
            fscanf(fh, "%lf,%lf,%lf,%lf", &cl->x0, &cl->y0, &cl->x1, &cl->y1);
            //printf("%c L %lf %lf %lf %lf\n", currchar, cl->x0, cl->y0, cl->x1, cl->y1);



            //printf("** comparing width [%c] x0=%lf x1=%lf ? %lf\n", currchar, ((ch_line *)tail)->x0, ((ch_line *)tail)->x1, alpha[currchar].width);
            if(((ch_line *)tail)->x0 > alpha[currchar].width)
                alpha[currchar].width = ((ch_line *)tail)->x0;
            if(((ch_line *)tail)->x1 > alpha[currchar].width)
                alpha[currchar].width = ((ch_line *)tail)->x1;
            skip_to_eol(fh);
            break;
        case 'A' :
            ca = malloc(sizeof(ch_arc));
            ca->next = NULL;
            if(tail==NULL) {
                tail=(ch_part *)ca;
                head=(ch_part *)ca;
                alpha[currchar].head=head;
            }
            else {
                tail->next=(ch_part *)ca;
                tail=(ch_part *)ca;
            }
            tail->part_type='A';
            fscanf(fh, "%lf,%lf,%lf,%lf,%lf", &ca->x, &ca->y, &ca->r, &ca->a0, &ca->a1);
            //printf("%c A %lf %lf %lf %lf %lf\n", currchar, ca->x, ca->y, ca->r, ca->a0, ca->a1);
            skip_to_eol(fh);
            break;
        case 10 :
            continue;
        default:
            printf("unknown '%c' - going to eol\n", c);
            skip_to_eol(fh);
        }
    }
    return alpha;
}

            
                
