/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"

int dict_clear(dict *d) {
    d->n = 0;
    return 1;
}

int dict_add(dict *d, char *s, void *p) {
    if(strlen(s) < 1)
        return 0; 
    if(s[strlen(s)-1] == 13) /* chomp */
        s[strlen(s)-1] = 0;
    if(d->n >= DICT_SIZE) {
        fprintf(stderr, "Dictionary overflow adding '%s'\n", s);
        exit(1);
    }
    d->recs[d->n].p = p;
    strncpy(d->recs[d->n].name, s, MAX_STRING);
    d->n++;
    return 1;
}

void *dict_lookup(dict *d, char *s) {
    int i;

    //printf("lookup 1: got '%s'\n", s);
    if(strlen(s) < 1)
        return NULL; 
    if(s[strlen(s)-1] == 13)
        s[strlen(s)-1] = 0;
    //printf("lookup 2: got '%s'\n", s);
    for(i=0; i<d->n; i++) {
        //printf("lookup 2.5: got '%s' =? '%s', i=%d / %d \n", s, d->recs[i].name, i, d->n);
        if(!strncmp(s, d->recs[i].name, MAX_STRING)) {
            //printf("looked up '%s' : %d\n", s, d->recs[i].p);
            return d->recs[i].p;
        }
    }
    //printf("lookup 4: missed '%s'\n", s);
    return NULL;
}

void *dict_lookup_or_default(dict *d, char *s) {
    void *p;
    
    if(d->n == 0) {
        fprintf(stderr,
        "dict_lookup_or_default: empty dict looking up '%s'\n", s);
        exit(1);
    }
    p = dict_lookup(d, s);
    if(p == NULL)  /* not found, return first element */
        return(d->recs[0].p);
    return(p);
}

