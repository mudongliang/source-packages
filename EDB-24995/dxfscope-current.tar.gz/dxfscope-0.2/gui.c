/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"
static const char *help_text[] = {" MOVE AROUND", "oZOOM OUT", "iZOOM IN", "qQUIT", "tROTATE CCW", "yROTATE CW"};
#define NUM_HELP_LINES 6

void cls() {
    XFillRectangle(dis, win, black_gc, 0, 0, wwidth, wheight);
}

void progress_bar(long progress, long total) {
    int x, y, width, height, fillx;
    
    //printf("bar: progress=%d  total=%d\n", progress, total);
    if(progress > total) {
        //printf("bar: progress=%d  > total=%d\n", progress, total);
        progress = total;
    }
    width = wwidth / 2;
    x = wwidth / 4;
    height = 10;
    y = (wheight - height) / 2.0;
    fillx = width * progress/total;

    XDrawRectangle(dis, win, green_gc, x, y, width, height);
    XFillRectangle(dis, win, green_gc, x, y, fillx, height);
}
    
void help_draw_key(matrix *m, char key) {
    char ks[2];
    matrix m2;
    vv w;
    vv size;
    point a, b, c, d, ta, tb, tc, td;

    size = 8;
    m2 = *m;
    a.x=-10; a.y=-8;
    c.x=10; c.y=12;

    b.x=a.x; b.y=c.y;
    d.x=c.x; d.y=a.y;

    ks[1]=0;
    ks[0]=key;
    w = get_text_width(ks, dfont);
    transform(&a, &ta, &m2);
    transform(&b, &tb, &m2);
    transform(&c, &tc, &m2);
    transform(&d, &td, &m2);
    m2.c -= w/2;
    XDrawLine(dis, win, green_gc, ta.x, ta.y, tb.x, tb.y);
    XDrawLine(dis, win, green_gc, tb.x, tb.y, tc.x, tc.y);
    XDrawLine(dis, win, green_gc, tc.x, tc.y, td.x, td.y);
    XDrawLine(dis, win, green_gc, td.x, td.y, ta.x, ta.y);
    mdraw_text(dis, win, basic_gc[0], &m2, ks, dfont);
}

void help_print(matrix *m, char *s) {
    point a, ta;
    vv w;
    matrix m2;

    m2 = *m;
    transform(&a, &ta, m);
    w = get_text_width(s, dfont);
    m2.c -= w/2;
    mdraw_text(dis, win, basic_gc[2], &m2, s, dfont);
}
void draw_help_screen_old() {
    vv sf, dy;
    matrix m, m2, m3, m4;
    point a, b, ta, tb;
    int nl, i;
    char *cp;

    nl = NUM_HELP_LINES;
    printf("I am dhs \n");
    cls();
    sf = wheight/(25.0 * (nl + 2.0));
    matrix_scale(&identity_matrix, &m, sf, -sf);
    m.f += wheight;
    m.c += wwidth/2;
    dy = 25.0 * sf;
    a.x = -1;
    a.y = 0;
    b.x = 1;
    b.y = 0;
    m2 = m;
    m2.c -= wwidth/10;
    transform(&a, &ta, &m);
    transform(&b, &tb, &m);

    m.f -= dy/2; m2.f -= dy/2;
    help_print(&m2, "Press any key");
    m.f -= dy; m2.f -= dy;
    for(i = 0; i<4; i++) {
        matrix_scale(&identity_matrix, &m3, 25.0*sf, 25.0*sf);
        matrix_multiply(&m3, &m2, &m4);
        draw_arrowhead(green_gc, &m4, a, b, 0);
        m2.c -= dy;
        help_draw_key(&m2, ' ');
    }
    m2.c += 3.0 * dy;
    for(i = 0; i<nl; i++) {
        cp = (char *)help_text[i];
        cp++;
        help_draw_key(&m2, help_text[i][0]);
        mdraw_text(dis, win, basic_gc[2], &m, cp, dfont);
        m.f -= dy; m2.f -= dy;
    }
    help_print(&m2, "DXFscope");
      
    XFlush(dis);
}
void zoom_special_screen(d_ent_t *mylist) { /* should be refactored with other zooms (kindof is) */
    vv ysf, ds, margin, xmargin;
    point a, b, dc;
    matrix m2, m3, m4;

    set_extents(mylist, &a, &b);
    ds=wwidth/(b.x-a.x);
    ysf = wheight/(b.y-a.y);
    if(ysf < ds)
        ds = ysf;
    m2=identity_matrix;
    matrix_scale(&m2, &m3, ds, -ds);
    transform(&a, &dc, &m3);
    xmargin = (wwidth - ds*(b.x-a.x))/2.0;
    matrix_translate(&m3, &help_matrix, xmargin-dc.x, wheight-dc.y);
}

void draw_help_screen() {
    zoom_special_screen(help_list);
    //start_timer();
    XFillRectangle(dis, win, black_gc, 0, 0, wwidth, wheight);
    draw_all(&help_matrix, help_list);
    XFlush(dis);
    //finish_timer();
}

void draw_check_box(clickable *c, matrix *m, int state) {
    /* state = [10] clicked */
    int s = 8;
    point a, b, p0, p1, p2, p3;
    a.x=0;
    a.y=0;
    transform(&a, &p0, m);
    a.x=s;
    transform(&a, &p1, m);
    a.y=s;
    transform(&a, &p2, m);
    a.x=0;
    transform(&a, &p3, m);
    c->x = p0.x;
    c->y = p0.y;
    c->size = p1.x-p0.x;
    mXDrawLine(dis, win, green_gc, p0.x, p0.y, p1.x, p1.y);
    mXDrawLine(dis, win, green_gc, p1.x, p1.y, p2.x, p2.y);
    mXDrawLine(dis, win, green_gc, p2.x, p2.y, p3.x, p3.y);
    mXDrawLine(dis, win, green_gc, p3.x, p3.y, p0.x, p0.y);
    if(!state) return;
    mXDrawLine(dis, win, green_gc, p0.x, p0.y, p2.x, p2.y);
    mXDrawLine(dis, win, green_gc, p1.x, p1.y, p3.x, p3.y);
}
    
/* given x,y in screen, see if it matches a 'clickable' */
int find_click(int x, int y) {
    int i;
    for(i=0; i<NCLICKABLES; i++) {
        if(clickables[i].size < 1)
            return(-1);
        if(clickables[i].x <= x && clickables[i].x+clickables[i].size >= x &&
           clickables[i].y >= y && clickables[i].y-clickables[i].size <= y)
            return(i);
    }
    return(-1);
}

void draw_layers_screen(int rebuild_clicks) {
    matrix m, m2;
    dict *d;
    d_layer_t *layer;
    d_ltype_t *ltype;
    int i, j;
    char *ltype_name;
    vv sf;
    char buf[255];
    int tabstop[] = { 40, 170, 250, 340 };
    
    XFillRectangle(dis, win, black_gc, 0, 0, wwidth, wheight);
    d = &layer_dict;
    sf = wheight/(25.0 * (layer_chunk_size + 2.0));
    //sf *= 7.0;
    matrix_scale(&identity_matrix, &m, sf, -sf);

    /* draw title */
    matrix_translate(&m, &m2, 0, 25.0 * sf);
    m = m2;
    mdraw_text(dis, win, green_gc, &m, "LAYERS", dfont);

    /* draw heading */
    matrix_translate(&m, &m2, 0, 25.0 * sf);
    m = m2;
    j=0;
    matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
    mdraw_text(dis, win, green_gc, &m2, "NAME", dfont);
    matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
    mdraw_text(dis, win, green_gc, &m2, "LINETYPE", dfont);
    matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
    mdraw_text(dis, win, green_gc, &m2, "COLOR #", dfont);
    matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
    mdraw_text(dis, win, green_gc, &m2, "ON", dfont);

    for(i=layer_start_index; i<layer_end_index; i++) {
        layer = d->recs[i].p;
        ltype = layer->ltype;
        if(ltype) {
            ltype_name = ltype->name;
        }
        else {
            ltype_name = "NULL";
        }
        //fprintf(stderr, "Layer: %s  color=%d  ltype_name=%s  flag=%d\n", d->recs[i].name, layer->color, ltype_name, layer->flag);
        matrix_translate(&m, &m2, 0, 25.0 * sf);
        m = m2;
        j=0;
        matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
        mdraw_text(dis, win, green_gc, &m2, d->recs[i].name, dfont);
        matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
        mdraw_text(dis, win, green_gc, &m2, ltype_name, dfont);
        sprintf(buf, "%d", layer->color);
        matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
        mdraw_text(dis, win, green_gc, &m2, buf, dfont);
        matrix_translate(&m, &m2, tabstop[j++] * sf, 0);
        draw_check_box(&clickables[i], &m2, (layer->color >= 0) ? 1 : 0);
    }
    clickables[i].size=0; /* mark the end */
}


