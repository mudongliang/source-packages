/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"
static char *basic_color[] = {
    "#FFFFFF",
    "#FF0000",
    "#FFFF00",
    "#00FF00",
    "#8080FF",
    "#0000FF",
    "#FF00FF",
    "#00FF80",
    "#606060",
    "#A0A0A0"
};

void read_default_font() {
    FILE *fh;
    fh = fopen(DEFAULTFONT, "r");
    if(fh == NULL) {
        fprintf(stderr, "cannot open default font!\n");
        return;
    }
    dfont = read_font(fh);
}

void read_help_file() {
    dxfin(HELPFILE);
    help_list = ent_head;
}

void init_display() {
    dis = XOpenDisplay(NULL);
    win = XCreateSimpleWindow(dis, RootWindow(dis, 0), 1, 1,
                              wwidth, wheight, 0, BlackPixel
                              (dis, 0), BlackPixel(dis, 0));
    XMapWindow(dis, win);
    colormap = DefaultColormap(dis, 0);
}

void init_basic_gc() {
    int i;
    for(i=0; i<10; i++) {
        basic_gc[i] = XCreateGC(dis, win, 0, 0);
        XParseColor(dis, colormap, basic_color[i], &basic_clr[i]);
        XAllocColor(dis, colormap, &basic_clr[i]);
        XSetForeground(dis, basic_gc[i], basic_clr[i].pixel);
    }
}

void init_util_gc() { /* some utility GC's */
    green_gc = XCreateGC(dis, win, 0, 0);
    green="#00FF00";
    XParseColor(dis, colormap, green, &green_col);
    XAllocColor(dis, colormap, &green_col);
    XSetForeground(dis, green_gc, green_col.pixel);

    black_gc = XCreateGC(dis, win, 0, 0);
    black="#000000";
    XParseColor(dis, colormap, black, &black_col);
    XAllocColor(dis, colormap, &black_col);
    XSetForeground(dis, black_gc, black_col.pixel);
}

void init_layer0() {
    d_layer_t *e;

    e=(d_layer_t *)malloc(sizeof(d_layer_t));
    if(!e) {
        fprintf(stderr, "failed to malloc d_layer_t\n");
        exit(1);
    }
    e->color = 0;
    e->name[0] = '0';
    e->name[1] = 0;
    e->flag = 0;
    e->type = EN_LAYER;
    dict_add(&layer_dict, e->name, (void *)e);
}

void init_style0() {
    d_style_t *e;

    e=(d_style_t *)malloc(sizeof(d_style_t));
    if(!e) {
        fprintf(stderr, "failed to malloc d_style_t\n");
        exit(1);
    }
    e->name[0] = '0';
    e->name[1] = 0;
    e->type = EN_STYLE;
    dict_add(&style_dict, e->name, (void *)e);
}


void init_identity_matrix() {
    identity_matrix.a = 1.0;
    identity_matrix.b = 0.0;
    identity_matrix.c = 0.0;
    identity_matrix.d = 0.0;
    identity_matrix.e = 1.0;
    identity_matrix.f = 0.0;
}

void startup() {
    mode = 0;
    draw_mode_x();
    init_display();
    init_identity_matrix();
    init_basic_gc();
    init_util_gc();
    init_layer0();
    init_style0();
    read_default_font();
    read_help_file();
    layer_start_index = -1;
}


