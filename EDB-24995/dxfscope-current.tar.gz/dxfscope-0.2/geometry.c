/*
 This file is part of DXFscope.

 Copyright (c) 2003 Asher Blum <asher@wildspark.com>

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along
 with this program; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "d.h"
#include <errno.h>

vv dsin(vv ang) {
    return(sin(ang * M_PIl / 180.0));
}

vv dcos(vv ang) {
    return cos(ang * M_PIl / 180.0);
}

void print_matrix(matrix *m) {
    printf("  | %.2f  %.2f  0 |\n", m->a, m->d);
    printf("  | %.2f  %.2f  0 |\n", m->b, m->e);
    printf("  | %.2f  %.2f  1 |\n", m->c, m->f);
}
void matrix_multiply(matrix *a, matrix *b, matrix *c) {
    c->a = a->a * b->a + a->d * b->b;
    c->b = a->b * b->a + a->e * b->b;
    c->c = a->c * b->a + a->f * b->b + b->c;
    c->d = a->a * b->d + a->d * b->e;
    c->e = a->b * b->d + a->e * b->e;
    c->f = a->c * b->d + a->f * b->e + b->f;
    c->angle = a->angle + b->angle;
    if(c->angle > 360.0)
        c->angle -= 360.0;
    if(c->angle < 0.0)
        c->angle += 360.0;
}

void transform(point *src, point *dst, matrix *m) {
    dst->x = m->a * src->x + m->b * src->y + m->c;
    dst->y = m->d * src->x + m->e * src->y + m->f;
    dst->z = src->z; /* no translation, no 3d */
    //printf("transform: x=%.1lf y=%.1lf  angle=%.1lf\n", dst->x, dst->y, m->angle);
}
void matrix_rotate(matrix *src, matrix *dst, vv angle) {
    matrix m;
    vv ang;

    ang = M_PIl * angle / -180.0;
    m.a = cos(ang);
    m.b = sin(ang);
    m.c = 0;
    m.d = -m.b;
    m.e = m.a;
    m.f = 0;
    m.angle = angle;
    matrix_multiply(src, &m, dst);
}

void matrix_rotate_vec(matrix *src, matrix *dst, point p, point q, vv a) {
    /* rotate matrix based on slope of line given by 2 points, add angle */
    matrix m;
    vv ang;

    if(p.x == q.x && p.y < q.y) { /* vertical */
        ang = 0.0;
    }
    else if(p.x == q.x) {
        ang = -M_PIl;
    }
    else {
        ang = atan((q.y-p.y) / (q.x-p.x));
        if(q.y > p.y)
            ang += M_PIl;
    }

    ang = -line_angle(q, p);
    if(a != 0.0) {
        ang += a;
    }
    //printf("mrv: dx=%lf dy=%lf  ang=%lf\n", p.x-q.x, p.y-q.y, ang);

    m.a = cos(DEG2RAD(ang));
    m.b = sin(DEG2RAD(ang));
    m.c = 0;
    m.d = -m.b;
    m.e = m.a;
    m.f = 0;
    m.angle = ang;
    matrix_multiply(src, &m, dst);
}


void matrix_translate(matrix *src, matrix *dst, vv x, vv y) {
    /* I think this func can be replaced with simple add... */
    matrix m;
    m.a = 1;
    m.b = 0;
    m.c = x;
    m.d = 0;
    m.e = 1;
    m.f = y;
    m.angle = 0.0;
    matrix_multiply(src, &m, dst);
}

void matrix_scale(matrix *src, matrix *dst, vv x, vv y) {
    matrix m;
    m.a = x;
    m.b = 0;
    m.c = 0;
    m.d = 0;
    m.e = y;
    m.f = 0;
    m.angle = 0.0;
    matrix_multiply(src, &m, dst);
}

void extensify(point *p, point *a, point *b) { /* enlarge extents to include p */
    /* a-b is extents rectang */
    if(!have_first_point) {
        a->x = p->x;
        a->y = p->y;
        b->x = p->x;
        b->y = p->y;
        have_first_point = 1;
    }
    if(p->x < a->x)
        a->x = p->x;
    if(p->y < a->y)
        a->y = p->y;
    if(p->z < a->z)
        a->z = p->z;
    if(p->x > b->x)
        b->x = p->x;
    if(p->y > b->y)
        b->y = p->y;
    if(p->z > b->z)
        b->z = p->z;
}

vv distance(point a, point b) {
    vv x, y, l;
    x = a.x-b.x;
    y = a.y-b.y;
    l = hypot(x, y);
    return sqrt(x*x + y*y);
}

void offset_pt(point *a, point *b, vv m, vv dist, vv refx, int dir) {
    /* if dir=1, move closer to refx; if -1, move further */

    vv dx, dy;

    if(m == INF) {
        dx = 0.0;
        dy = dist;
    }
    else if(m == -INF) {
        dx = 0.0;
        dy = -dist;
    }
    else {
        dx = sqrt(dist*dist/(m*m+1));
        if(fabs(refx-(a->x+dx*dir)) > fabs(refx-(a->x)))
            dx *= -1;
        dy = m * dx;
    }
    b->x = a->x+dx;
    b->y = a->y+dy;
}

void get_midpoint(point *a, point *b, point *c) {
    c->x=(a->x+b->x)/2.0;
    c->y=(a->y+b->y)/2.0;
    c->z=0.0;
}

int get_int_ll(point *a, point *b, point *c, point *d, point *z) {
    /* set z = intersection of ab, cd */
    vv m0, m1, b0, b1;
    if(a->x == b->x) { /* vertical */
        if(c->x == d->x)
            return 0; /* no int */
        m0 = INF;
        z->x = a->x;
        z->y = c->y + (a->x - c->x) * (d->y - c->y) / (d->x - c->x);
        return 1;
    }
    else if(c->x == d->x) {
        return get_int_ll(c, d, a, b, z);
    }
    else {
        m0 = (b->y - a->y)/(b->x - a->x);
        m1 = (d->y - c->y)/(d->x - c->x);
        b0 = a->y - m0 * a->x;
        b1 = c->y - m1 * c->x;
        z->x = (b1 - b0)/(m0 - m1);
        z->y = m0 * z->x + b0;
        return 1;
    }
}
         
vv line_angle(point a, point b) {
    vv angle;
    if(a.x == b.x)
        return (b.y > a.y) ? 90.0 : 270.0;
    else if(a.y == b.y)
        return (b.x > a.x) ? 0.0 : 180.0;
    angle = (180.0 * atan((b.y-a.y)/(b.x-a.x)) / M_PIl);
    if(b.x-a.x < 0)
        angle += 180.0;
    if(angle < 0)
        angle += 360.0;
    //printf("la: dx=%.2lf  dy=%.2lf  a=%.1lf\n", (b.x-a.x), (b.y-a.y), angle);
    return angle;
}
