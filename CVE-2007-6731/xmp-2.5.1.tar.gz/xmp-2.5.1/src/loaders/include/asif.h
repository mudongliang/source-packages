
#ifndef __XMP_ASIF_H
#define __XMP_ASIF_H

#include <stdio.h>
#include "xmpi.h"

int asif_load(struct xmp_context *, FILE *, int);

#endif
