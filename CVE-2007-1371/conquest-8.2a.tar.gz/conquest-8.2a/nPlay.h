/* 
 * play node.  just for fun.
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NPLAY_H
#define _NPLAY_H

void nPlayInit(void);

#endif /* _NPLAY_H */
