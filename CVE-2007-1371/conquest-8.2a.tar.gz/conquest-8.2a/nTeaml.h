/* 
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NTEAML_H
#define _NTEAML_H

scrNode_t *nTeamlInit(int nodeid, int setnode, int tn);

#endif /* _NTEAML_H */
