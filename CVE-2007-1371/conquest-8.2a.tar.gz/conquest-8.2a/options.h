/* 
 * $Id$
 *
 * Copyright 2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _OPTIONS_H
#define _OPTIONS_H

/* options.c */
void SysOptsMenu(void);
void UserOptsMenu(int unum);

#endif /* _OPTIONS_H */
