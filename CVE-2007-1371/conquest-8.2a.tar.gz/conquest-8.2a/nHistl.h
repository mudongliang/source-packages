/* 
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NHISTL_H
#define _NHISTL_H

scrNode_t *nHistlInit(int nodeid, int setnode);

#endif /* _NHISTL_H */
