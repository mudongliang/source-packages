/* 
 * cockpit node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NCP_H
#define _NCP_H

void nCPInit(int istopnode);

#endif /* _NCP_H */
