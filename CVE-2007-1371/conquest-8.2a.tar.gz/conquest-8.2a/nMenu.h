/* 
 * The Menu node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NMENU_H
#define _NMENU_H

void nMenuInit(void);

#endif /* _NMENU_H */
