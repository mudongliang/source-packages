/* 
 * The Menu node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NPLAYBMENU_H
#define _NPLAYBMENU_H

void nPlayBMenuInit(void);

#endif /* _NPLAYBMENU_H */
