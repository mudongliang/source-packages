/* 
 * cockpit node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NPLAYB_H
#define _NPLAYB_H

void nPlayBInit(void);

#endif /* _NPLAYB_H */
