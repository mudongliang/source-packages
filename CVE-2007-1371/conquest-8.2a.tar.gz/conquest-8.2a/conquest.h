
/************************************************************************
 *
 * $Id$
 *
 * Copyright 2003 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 ***********************************************************************/

#ifndef CONQUEST_H
#define CONQUEST_H

#define CONQUESTGL_NAME "ConquestGL"

#endif
