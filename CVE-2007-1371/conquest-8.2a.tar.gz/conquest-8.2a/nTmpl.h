/* 
 * node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NCONSVR_H
#define _NCONSVR_H

void nConsvrInit(char *remotehost, Unsgn16 remoteport);

#endif /* _NCONSVR_H */
