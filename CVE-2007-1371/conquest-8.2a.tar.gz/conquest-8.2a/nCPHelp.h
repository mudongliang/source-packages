/* 
 * nCP help node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NCPHELP_H
#define _NCPHELP_H

scrNode_t *nCPHelpInit(int setnode);

#endif /* _NCPHELP_H */
