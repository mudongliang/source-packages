/* 
 * meta node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NMETA_H
#define _NMETA_H

#include "meta.h"

void nMetaInit(metaSRec_t *metaServerList, int numserv);

#endif /* _NMETA_H */
