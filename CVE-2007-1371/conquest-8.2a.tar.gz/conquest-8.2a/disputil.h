/************************************************************************
 *
 * $Id$
 *
 * Copyright 2003 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 ***********************************************************************/

/* shared prototypes for common display related things... */

#ifndef _DISPUTIL_H
#define _DISPUTIL_H

void displayFeedback(char *msg, int lin);

#endif /* _DISPUTIL_H */
