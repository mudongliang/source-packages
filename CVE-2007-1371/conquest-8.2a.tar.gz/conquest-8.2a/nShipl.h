/* 
 * nCP help node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NSHIPL_H
#define _NSHIPL_H

scrNode_t *nShiplInit(int nodeid, int setnode);

#endif /* _NSHIPL_H */
