/* 
 * auth node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NAUTH_H
#define _NAUTH_H

void nAuthInit(void);

#endif /* _NAUTH_H */
