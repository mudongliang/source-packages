/* 
 * -
 *
 * $Id$
 *
 * Copyright 2003 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef INC_H_INCLUDED
#define INC_H_INCLUDED


#endif /* INC_H_INCLUDED */
