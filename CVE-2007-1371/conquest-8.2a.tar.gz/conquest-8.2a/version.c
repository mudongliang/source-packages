/************************************************************************
 *
 * version.c - conquest's version number
 *
 * $Id$
 *
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 ***********************************************************************/

const char *ConquestId = "$Id$";
const char *ConquestVersion = "Version 8.2a";
const char *ConquestDate = "11/27/2006";

/* That's it! */
