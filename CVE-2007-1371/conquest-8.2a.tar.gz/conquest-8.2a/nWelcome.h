/* 
 * The Welcome node.  Hi!
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NWELCOME_H
#define _NWELCOME_H

void nWelcomeInit(void);

#endif /* _NWELCOME_H */
