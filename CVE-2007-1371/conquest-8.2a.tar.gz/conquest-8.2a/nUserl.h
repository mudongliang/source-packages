/* 
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NUSERL_H
#define _NUSERL_H

scrNode_t *nUserlInit(int nodeid, int setnode, int sn, int gl, int extra);

#endif /* _NUSERL_H */
