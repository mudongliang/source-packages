/* 
 * nCP help node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NPLANETL_H
#define _NPLANETL_H

scrNode_t *nPlanetlInit(int nodeid, int setnode, int sn, int tn);

#endif /* _NPLANETL_H */
