/* 
 * dead node
 *
 * $Id$
 *
 * Copyright 1999-2004 Jon Trulson under the ARTISTIC LICENSE. (See LICENSE).
 */

#ifndef _NDEAD_H
#define _NDEAD_H

void nDeadInit(void);

#endif /* _NDEAD_H */
