#!/usr/bin/perl -w
my $i;
print "<h1>Perl test page</h1>";
 for ($i = 0; $i < 30000; $i++) {print "Number <b>$i</b> coming at you!<br>";}
