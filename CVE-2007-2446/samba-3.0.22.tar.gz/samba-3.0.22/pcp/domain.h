/*
 * built from /var/pcp/pmns/stdpmid
 */
#define SAMBA 123
