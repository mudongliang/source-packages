#ifndef __WORLD_H
#define __WORLD_H

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <arpa/telnet.h>
#include <netdb.h>
#include <ctype.h>
#include <errno.h>

#ifdef __APPLE__
#define ACCEPT_SIGNED 1
#else
#define ACCEPT_SIGNED 0
#endif

#endif
