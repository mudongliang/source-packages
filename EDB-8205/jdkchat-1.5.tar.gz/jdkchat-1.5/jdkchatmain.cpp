/* 
  
  Copyright (C) 2003 Aditya Godbole (urwithaditya@gmx.net)

  jdkchat version 1.5 - Simple chat daemon usable via telnet.
  Copyright (C) 1995  J.D.Koftinoff Software, Ltd.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "world.h"
#include "jdkchat.h"


void print_hello()
{
    fprintf( stdout,
	     "   Copyright (C) 2003 Aditya Godbole (urwithaditya@gmx.net)\r\n"
	     "   jdkchat version 1.5,\r\n"
	     "   Copyright (C) 1995 J.D. Koftinoff Software Ltd.\r\n"
	     "   jdkchat comes with ABSOLUTELY NO WARRANTY.\r\n"
	     "   This is free software, and you are welcome to redistribute it\r\n"
	     "   under the terms of the Free Software Foundation's GNU Public\r\n"
	     "   License.\r\n"
	);

}

void manage_room( JDKChatRoom *room )
{
    int num=0;
    fd_set rd,wr,ex;
    struct timeval t;
    int i;
	
    t.tv_sec=2;
    t.tv_usec=0;
	
    FD_ZERO( &rd );
    FD_ZERO( &wr );
    FD_ZERO( &ex );
	

    room->Make_fdset( &rd, &wr, &ex );
	
    num=select( FD_SETSIZE, &rd, &wr, &ex, &t );
	
    if( num>0 )
    {
	room->ManageRoom( &rd, &wr, &ex );	
    }

}

int main( int argc, char **argv )
{
    FILE *log_file=0;
	
    signal(SIGPIPE, SIG_IGN);         

    if( argc<2 || (argc>1 && *argv[1]=='-' ) )
    {
	print_hello();
	fprintf( stderr, "usage:\n\tjdkchat [port] [log_file]\nPlease give desired port #\n" );
	exit(1);
    }

    int port=atoi(argv[1]);

    fprintf( stdout, "jdkchat: using port %d", port );
	
    if( argc>2 )
    {
	log_file = fopen( argv[2], "at" );
	if( log_file )
	{
	    fprintf( stdout, ", logging to '%s'", argv[2] );
	}
    }
	
    fprintf( stdout, "\n" );
	
    JDKChatRoom r(port,log_file);
	
    r.BindSocket();

    int f=fork();
	
    if( f==0 )
    {
	close( STDIN_FILENO );
	close( STDOUT_FILENO );
	close( STDERR_FILENO );
		
	// in child
	while(1)
	    manage_room( &r );
    }
    if( f==-1 )
    {
	perror( "error forking processes" );
	return 1;
    }
    return 0;	
}
