/*
    Copyright (C) 2003 Aditya Godbole (urwithaditya@gmx.net)

    jdkchat version 1.4 - Simple chat daemon usable via telnet.
    Copyright (C) 1995  J.D.Koftinoff Software, Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#ifndef __JDKCHAT_H
#define	__JDKCHAT_H

class JDKChatUser;
class JDKChatRoom;

#define MAX_CHAT_USERS 20

class JDKChatUser
{
public:
	JDKChatUser( JDKChatRoom *current_room);
	~JDKChatUser();

	int	IsUserAccepted();
	int	GetFD();	
	const char *GetName();

	int	ManageUser();		// -1 means connection ended.  
	int	Send( const char *from, const char *text );
protected:

	void 	ClearEntryLine();
	void 	RedisplayEntryLine();
	void 	ClearBuffer();

private:

	int	HandleNoConnection();
	int	HandleSendHello();
	int	HandleGetName();
	int	HandleGetLine();

	enum State
	{
		STATE_NO_CONNECTION,
		STATE_GET_NAME,
		STATE_GET_LINE
	} state;

	int	ManageInputBuffer();

	int	HandleUserCommand();

	char 	buffer[256];
	int 	cur_pos;
	char 	name[256];
	char	prompt[256];
	int	local_mode;

  	struct 	sockaddr_in user_address;	
	int	user_fd;
	int	user_accepted;
	
	JDKChatRoom *room;
	
        static const char *welcome;	
};


class JDKChatRoom
{
public:
	JDKChatRoom( int port, FILE *log_file_=0  );
	~JDKChatRoom();

	void	BindSocket();
	
	int	Make_fdset( fd_set *r, fd_set *w, fd_set *e );	
	int	ManageRoom( fd_set *r, fd_set *w, fd_set *e );
	void	LookForNewUsers();
	
	void	BroadCast( const char *from, const char *c );
	void	Announce( const char *c );
	void	ListUsers( JDKChatUser *u );

	int	GetServerFD();
	struct	sockaddr_in *GetServerAddress();
	JDKChatUser *GetUser(int which);
	
private:
	int	port;
	int 	server_fd;
  	struct 	sockaddr_in server_address;
	
	JDKChatUser *user[MAX_CHAT_USERS];
	FILE    *log_file;


};



#endif
