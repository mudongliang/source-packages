#undef PACKAGE

#undef VERSION

#undef _GNU_SOURCE
