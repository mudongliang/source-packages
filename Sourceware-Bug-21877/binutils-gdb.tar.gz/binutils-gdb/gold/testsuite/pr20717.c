void unused(void);
void unused(void) {}
int main(void) {return 0;}
