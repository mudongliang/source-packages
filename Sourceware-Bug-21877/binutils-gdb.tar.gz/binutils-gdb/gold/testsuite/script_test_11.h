extern int ptr_equal(char *, char *);
