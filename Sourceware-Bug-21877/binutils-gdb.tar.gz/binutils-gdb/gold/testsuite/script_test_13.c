extern int a;
int* pa = &a;
