template<typename C>
void
bar(C*)
{
}

template
void
bar<int>(int*);
