void mk_cheetah_loop_stdin();
void mk_cheetah_loop_server();
