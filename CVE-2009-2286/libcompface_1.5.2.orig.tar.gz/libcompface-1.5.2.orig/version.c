char version[] = "compface, version 1.4";
